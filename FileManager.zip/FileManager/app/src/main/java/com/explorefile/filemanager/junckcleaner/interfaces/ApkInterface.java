package com.explorefile.filemanager.junckcleaner.interfaces;

public interface ApkInterface {
    void done(boolean flag);
}

