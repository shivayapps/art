package com.explorefile.filemanager;

import android.app.Activity;
import android.content.Context;

import androidx.annotation.NonNull;
import com.example.app.ads.helper.VasuAdsConfig;
import com.example.app.ads.helper.openad.AppOpenApplication;
import com.example.app.ads.helper.openad.OpenAdHelper;
import com.explorefile.filemanager.db.DbHelper;
import com.explorefile.filemanager.utils.OpenFile;

import kotlin.Unit;
import kotlin.jvm.functions.Function0;


public class MyApplication extends AppOpenApplication implements AppOpenApplication.AppLifecycleListener {

    private static MyApplication application;


    @Override
    public void onCreate() {
        super.onCreate();
        application = this;

        DbHelper.getInstance(this);
        OpenFile.init(this);

        VasuAdsConfig.with(this)
                .isEnableOpenAd(true) // Pass false if you don't need to show open ad in your project
                .needToTakeAllTestAdID(false) // Pass true if you need to show Ads with Test Ad ID in your project
                .needToBlockInterstitialAd(false) // Pass true if you check fullScreenNativeAds when Interstitial Ads Failed to Load
                .setAdmobAppId(getString(R.string.APP_ID))
                .setAdmobBannerAdId(getString(R.string.G_BANNER_ID))
                .setAdmobInterstitialAdId(getString(R.string.G_INTERSTITIAL_ID))
                .setAdmobNativeAdvancedAdId(getString(R.string.G_NATIVE_ID))
                .setAdmobOpenAdId(getString(R.string.G_APPOPEN_ID))
//                .setAdmobRewardVideoAdId(getString(R.string.rewarded_video_ad_unit_id))
//                .setAdmobInterstitialAdRewardId(getString(R.string.rewarded_interstitial_ad_unit_id))
                .initialize();

//        initMobileAds("138C82055F352E2F7B6148F0AAA7895F");
        OpenAdHelper.INSTANCE.loadOpenAd(this, new Function0<Unit>() {
            @Override
            public Unit invoke() {
                return null;
            }
        });
        setAppLifecycleListener(this);

    }

    public static Context getAppContext() {
        if (application == null) {
            application = new MyApplication();
        }
        return application;
    }

    @Override
    public boolean onResumeApp(@NonNull Activity fCurrentActivity) {

        if(fCurrentActivity instanceof SplashActivity){
            return false;
        }
//        else if(!new AdsManager(fCurrentActivity).isNeedToShowAds()) {
//            return false;
//        }
        return true;
    }
}
