package com.explorefile.filemanager.junckcleaner.interfaces;

public interface SysInterface {
        void sysDone(boolean flag);
    }
