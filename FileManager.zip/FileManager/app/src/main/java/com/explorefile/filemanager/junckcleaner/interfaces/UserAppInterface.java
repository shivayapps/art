package com.explorefile.filemanager.junckcleaner.interfaces;

public interface UserAppInterface {
        void userDone(boolean flag);
    }