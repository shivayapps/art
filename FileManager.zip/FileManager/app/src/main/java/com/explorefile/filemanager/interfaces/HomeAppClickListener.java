package com.explorefile.filemanager.interfaces;

public interface HomeAppClickListener {
    void onHomeAppClick(String name);
}
