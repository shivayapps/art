package com.explorefile.filemanager.fragment;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ImageView;

import com.explorefile.filemanager.R;
import com.explorefile.filemanager.adapter.AppsAdapter;
import com.explorefile.filemanager.databinding.FragmentAppsBinding;
import com.explorefile.filemanager.interfaces.ActionModeListener;
import com.explorefile.filemanager.interfaces.FileSelectedListener;
import com.explorefile.filemanager.model.MediaModel;
import com.explorefile.filemanager.utils.OpenFile;
import com.explorefile.filemanager.utils.Utils;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.concurrent.Executors;

public class AppsFragment extends AppCompatActivity implements FileSelectedListener, ActionModeListener {

    private FragmentAppsBinding binding;
    private String arg;
    private String mParam2;
    private ArrayList<File> appList = new ArrayList<>();
    private String[] apps = {"Images", "Audio", "Videos", "Zips", "Apps", "Document", "Download", "More"};
    private ArrayList<File> selectedList = new ArrayList<>();
    public static ActionModeListener actionModeListener;
    private AppsAdapter appsAdapter;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = FragmentAppsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
//        if (getArguments() != null) {
//            arg = getArguments().getString("APPS");
//        }
        onCreateView();
    }

    public View onCreateView() {
        Utils.setStatusBarColor(R.color.white,AppsFragment.this,true);

        binding.rv.setLayoutManager(new LinearLayoutManager(AppsFragment.this));
        appsAdapter = new AppsAdapter(AppsFragment.this, this);
        binding.rv.setAdapter(appsAdapter);

        binding.loader.setVisibility(View.VISIBLE);
        setData();

        actionModeListener = this;

        binding.ivBack.setOnClickListener(v -> AppsFragment.this.onBackPressed());

        return binding.getRoot();
    }

    @Override
    public void onResume() {
        super.onResume();
        binding.et.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                appsAdapter.getFilter().filter(s);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    @Override
    public void onPause() {
        super.onPause();
        binding.et.addTextChangedListener(null);
    }

    private void setData() {

        appList.clear();

        Executors.newSingleThreadExecutor().execute(() -> {


            if (Utils.EXTERNAL_FILE != null) {
                appList.addAll(getApps(Utils.EXTERNAL_FILE));
            }
            if (Utils.SD_CARD_FILE != null) {
                appList.addAll(getApps(Utils.SD_CARD_FILE));
            }

            appsAdapter.addAll(appList,null,binding.loader,binding.noData);


//            AppsFragment.this.runOnUiThread(() -> binding.loader.setVisibility(View.GONE));
        });

    }

    ArrayList<File> getApps(File file) {
        ArrayList<File> fileArrayList = new ArrayList<>();
        File[] files = file.listFiles();
        if (files != null) {
            for (File singleFile : files) {
                if (singleFile.isDirectory() && !singleFile.isHidden()) {
                    fileArrayList.addAll(getApps(singleFile));
                } else {
                    if (!singleFile.isHidden() && singleFile.getName().endsWith(".apk")) {
                        fileArrayList.add(singleFile);
                    }
                }
            }

        }

        return fileArrayList;
    }


    @Override
    public void onFileSelect(ImageView imageView, File file) {
        OpenFile.open(file);
    }

    @Override
    public void onBind(ImageView imageView, File file) {
        /*if (isAvailable(file)){
            imageView.setImageResource(R.drawable.ic_selected);
        } else {
            imageView.setImageResource(R.drawable.no_select);
        }*/

    }

    @Override
    public void onIvSelectClick(ArrayList<File> files, int position, ImageView imageView) {

        Bundle bundle = new Bundle();
        bundle.putSerializable("List", (Serializable) files);
        bundle.putInt("Position", position);
        bundle.putString("From", "Apps");
//        SelectAppsFragment selectAppsFragment = new SelectAppsFragment();
//        selectAppsFragment.setArguments(bundle);
//        AppsFragment.this.getSupportFragmentManager().beginTransaction().add(MainActivity.MAIN_CONTAINER, selectAppsFragment).addToBackStack(null).commit();

        Intent intent = new Intent(AppsFragment.this,SelectAppsFragment.class);
        intent.putExtra("data",bundle);
        startActivity(intent);

          /*  if (!isActionModeOn){
                isActionModeOn = true;
                binding.lyToolbar.setVisibility(View.GONE);
                binding.lyActionMode.setVisibility(View.VISIBLE);
            }
        if (imageView.getDrawable().getConstantState().equals(getResources().getDrawable(R.drawable.ic_selected).getConstantState())) {
            selectedList.remove(file);
            imageView.setImageResource(R.drawable.no_select);
        } else {
            selectedList.add(file);
            imageView.setImageResource(R.drawable.ic_selected);
        }
        binding.tvSelect.setText(String.format("%d Selected", selectedList.size()));*/

    }

    @Override
    public void onIvMediaSelectClick(ArrayList<MediaModel> files, int position, ImageView imageView) {

    }

    @Override
    public void onEventListener(int event) {
        switch (event) {
            case Utils.EVENT_ADD_TO_FAV:

            case Utils.EVENT_CLOSE:
                AppsFragment.this.onBackPressed();
                break;

            case Utils.EVENT_DELETE:
                setData();
                AppsFragment.this.onBackPressed();
                break;

            case Utils.EVENT_COPY:
            case Utils.EVENT_MOVE:
                setData();
                new Handler(Looper.getMainLooper()).post(() -> {
                    AppsFragment.this.onBackPressed();
                });
                break;
        }
    }
}