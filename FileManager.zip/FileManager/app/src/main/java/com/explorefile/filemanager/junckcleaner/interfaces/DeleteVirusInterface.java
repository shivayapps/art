package com.explorefile.filemanager.junckcleaner.interfaces;

public interface DeleteVirusInterface {

    void listener(boolean call);

 }
