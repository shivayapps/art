package com.explorefile.filemanager.junckcleaner.interfaces;

public interface SendData {
    public void data(String data);
}
