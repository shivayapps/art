package com.explorefile.filemanager.fragment;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ImageView;

import com.explorefile.filemanager.R;
import com.explorefile.filemanager.adapter.DownloadAdapter;
import com.explorefile.filemanager.databinding.FragmentDocumentBinding;
import com.explorefile.filemanager.databinding.FragmentDownloadBinding;
import com.explorefile.filemanager.interfaces.ActionModeListener;
import com.explorefile.filemanager.interfaces.FileSelectedListener;
import com.explorefile.filemanager.model.MediaModel;
import com.explorefile.filemanager.utils.OpenFile;
import com.explorefile.filemanager.utils.Utils;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;

public class DownloadFragment extends AppCompatActivity implements FileSelectedListener, ActionModeListener {

    private FragmentDownloadBinding binding;
    private ArrayList<File> download = new ArrayList<>();
    public static ActionModeListener actionModeListener;
    private DownloadAdapter downloadAdapter;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = FragmentDownloadBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
//        if (getArguments() != null) {
//            arg = getArguments().getString("APPS");
//        }
        onCreateView();
    }
    
    public View onCreateView() {
        Utils.setStatusBarColor(R.color.white,DownloadFragment.this,true);

        actionModeListener = this;
        binding.rv.setLayoutManager(new LinearLayoutManager(DownloadFragment.this));
        downloadAdapter = new DownloadAdapter(DownloadFragment.this, this);
        binding.rv.setAdapter(downloadAdapter);

        binding.loader.setVisibility(View.VISIBLE);
        setData();

        binding.ivBack.setOnClickListener(v -> DownloadFragment.this.onBackPressed());

        return binding.getRoot();
    }

    @Override
    public void onResume() {
        super.onResume();
        binding.et.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                downloadAdapter.getFilter().filter(s);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    @Override
    public void onPause() {
        super.onPause();
        binding.et.addTextChangedListener(null);
    }

    private void setData() {
        download.clear();
        download.addAll(dow(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)));
//        DownloadFragment.this.runOnUiThread(() -> binding.loader.setVisibility(View.GONE));
//        if (download.size() > 0) {
            downloadAdapter.addAll(download,null,binding.loader,binding.noData);
//        }

    }

    ArrayList<File> dow(File file) {

        ArrayList<File> fileArrayList = new ArrayList<>();
        File[] files = file.listFiles();
        if (files != null) {
            for (File singleFile : files) {
                if (singleFile.isDirectory() && !singleFile.isHidden()) {
                    fileArrayList.addAll(dow(singleFile));
                } else {
                    fileArrayList.add(singleFile);
                }
            }
        }

        return fileArrayList;
    }


    @Override
    public void onFileSelect(ImageView imageView, File file) {
        OpenFile.open(file);
    }

    @Override
    public void onBind(ImageView imageView, File file) {

    }

    @Override
    public void onIvSelectClick(ArrayList<File> files, int position, ImageView imageView) {
        Bundle bundle = new Bundle();
        bundle.putSerializable("List", (Serializable) files);
        bundle.putInt("Position", position);
        bundle.putString("From", "Large");
//        SelectAppsFragment selectAppsFragment = new SelectAppsFragment();
//        selectAppsFragment.setArguments(bundle);
//        DownloadFragment.this.getSupportFragmentManager().beginTransaction().add(MainActivity.MAIN_CONTAINER, selectAppsFragment).addToBackStack(null).commit();
        Intent intent = new Intent(DownloadFragment.this,SelectAppsFragment.class);
        intent.putExtra("data",bundle);
        startActivity(intent);
    }

    @Override
    public void onIvMediaSelectClick(ArrayList<MediaModel> files, int position, ImageView imageView) {

    }

    @Override
    public void onEventListener(int event) {
        switch (event) {
            case Utils.EVENT_ADD_TO_FAV:
                DownloadFragment.this.onBackPressed();
            case Utils.EVENT_CLOSE:
                DownloadFragment.this.onBackPressed();
                break;
            case Utils.EVENT_DELETE:
                setData();
                DownloadFragment.this.onBackPressed();
                break;
            case Utils.EVENT_COPY:
            case Utils.EVENT_MOVE:
                setData();
                new Handler(Looper.getMainLooper()).post(() -> DownloadFragment.this.onBackPressed());
                break;
        }
    }
}