package com.explorefile.filemanager.fragment.recent;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.explorefile.filemanager.R;
import com.explorefile.filemanager.databinding.FragmentRecentBinding;
import com.explorefile.filemanager.utils.Utils;

import java.util.ArrayList;

public class RecentFragment extends Fragment {

    private FragmentRecentBinding binding;
    private String argPath = "Images";
    ////public static int CON;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            argPath = getArguments().getString("FILE");
        }
        Utils.setStatusBarColor(R.color.white, getActivity(), true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentRecentBinding.inflate(inflater);
        //CON = binding.container.getId();
        ImagePagerAdapter pagerAdapter = new ImagePagerAdapter(getChildFragmentManager());
        pagerAdapter.addFragment(new RecentAllFragment(), "Image");
        //pagerAdapter.addFragment(new ImageFolderFragment(), "Album");
        binding.viewPager.setAdapter(pagerAdapter);
        binding.tabLayout.setupWithViewPager(binding.viewPager);


        return binding.getRoot();
    }

    private class ImagePagerAdapter extends FragmentPagerAdapter {

        ArrayList<Fragment> fragmentList = new ArrayList<>();
        ArrayList<String> stringList = new ArrayList<>();

        public ImagePagerAdapter(@NonNull FragmentManager fm) {
            super(fm);
        }

        public void addFragment(Fragment fragment, String title) {
            fragmentList.add(fragment);
            stringList.add(title);
        }

        @NonNull
        @Override
        public Fragment getItem(int position) {
            return fragmentList.get(position);
        }

        @Override
        public int getCount() {
            return fragmentList.size();
        }

        @Nullable
        @Override
        public CharSequence getPageTitle(int position) {
            return stringList.get(position);
        }
    }
}