package com.explorefile.filemanager.interfaces;

public interface StorageClickListener {
    void onStorageClicked(int i);
}
