package com.explorefile.filemanager.fragment;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ImageView;

import com.explorefile.filemanager.R;
import com.explorefile.filemanager.adapter.ZipAdapter;
import com.explorefile.filemanager.databinding.FragmentImageBinding;
import com.explorefile.filemanager.databinding.FragmentZipBinding;
import com.explorefile.filemanager.interfaces.ActionModeListener;
import com.explorefile.filemanager.interfaces.FileSelectedListener;
import com.explorefile.filemanager.model.MediaModel;
import com.explorefile.filemanager.utils.OpenFile;
import com.explorefile.filemanager.utils.Utils;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.concurrent.Executors;


public class ZipFragment extends AppCompatActivity implements FileSelectedListener, ActionModeListener {

    private FragmentZipBinding binding;
    private ArrayList<File> zipList = new ArrayList<>();
    private ZipAdapter adapter;
    public static ActionModeListener actionModeListener;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = FragmentZipBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        Utils.setStatusBarColor(R.color.white,ZipFragment.this,true);
        onCreateView();
    }

    public View onCreateView() {
        Utils.setStatusBarColor(R.color.white,ZipFragment.this,true);

        binding.rv.setLayoutManager(new LinearLayoutManager(ZipFragment.this));
        adapter = new ZipAdapter(ZipFragment.this, this);
        binding.rv.setAdapter(adapter);

        binding.loader.setVisibility(View.VISIBLE);
        setData();

        actionModeListener = this;

        binding.ivBack.setOnClickListener(v -> ZipFragment.this.onBackPressed());

        return binding.getRoot();
    }

    @Override
    public void onResume() {
        super.onResume();
        binding.et.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                adapter.getFilter().filter(s);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    @Override
    public void onPause() {
        super.onPause();
        binding.et.addTextChangedListener(null);
    }

    private void setData() {
        zipList.clear();
        Executors.newSingleThreadExecutor().execute(() -> {
        if (Utils.EXTERNAL_FILE != null) {
            zipList.addAll(zip(Utils.EXTERNAL_FILE));
        }
        if (Utils.SD_CARD_FILE != null) {
            zipList.addAll(zip(Utils.SD_CARD_FILE));
        }
//        ZipFragment.this.runOnUiThread(()->binding.loader.setVisibility(View.GONE));

//        if (zipList.size() > 0) {
            adapter.addAll(zipList,null,binding.loader,binding.noData);
//        }
        });
    }

    ArrayList<File> zip(File file) {

        ArrayList<File> fileArrayList = new ArrayList<>();
        File[] files = file.listFiles();
        if (files != null) {
            for (File singleFile : files) {
                if (singleFile.isDirectory() && !singleFile.isHidden()) {
                    fileArrayList.addAll(zip(singleFile));
                } else {
                    if (!singleFile.isHidden() && singleFile.getName().toLowerCase().endsWith(".zip") || singleFile.getName().toLowerCase().endsWith(".zipx")) {
                        fileArrayList.add(singleFile);
                    }
                }
            }

        }

        return fileArrayList;
    }


    @Override
    public void onFileSelect(ImageView imageView, File file) {
        OpenFile.open(file);
    }

    @Override
    public void onBind(ImageView imageView, File file) {

    }

    @Override
    public void onIvSelectClick(ArrayList<File> files, int position, ImageView imageView) {
        Bundle bundle = new Bundle();
        bundle.putSerializable("List", (Serializable) files);
        bundle.putInt("Position", position);
        bundle.putString("From", "Zip");
//        SelectAppsFragment selectAppsFragment = new SelectAppsFragment();
//        selectAppsFragment.setArguments(bundle);
//        ZipFragment.this.getSupportFragmentManager().beginTransaction().add(MainActivity.MAIN_CONTAINER, selectAppsFragment).addToBackStack(null).commit();
        Intent intent = new Intent(ZipFragment.this,SelectAppsFragment.class);
        intent.putExtra("data",bundle);
        startActivity(intent);


    }

    @Override
    public void onIvMediaSelectClick(ArrayList<MediaModel> files, int position, ImageView imageView) {

    }

    @Override
    public void onEventListener(int event) {
        switch (event) {
            case Utils.EVENT_ADD_TO_FAV:

            case Utils.EVENT_CLOSE:
                ZipFragment.this.onBackPressed();
                break;

            case Utils.EVENT_DELETE:
                setData();
                ZipFragment.this.onBackPressed();
                break;

            case Utils.EVENT_COPY:
            case Utils.EVENT_MOVE:
                setData();
                new Handler(Looper.getMainLooper()).post(() -> ZipFragment.this.onBackPressed());
                break;
        }
    }
}