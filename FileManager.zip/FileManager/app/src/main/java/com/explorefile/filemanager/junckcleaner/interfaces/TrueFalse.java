package com.explorefile.filemanager.junckcleaner.interfaces;

public interface TrueFalse {
    void isTrue(boolean isTrue);
}
