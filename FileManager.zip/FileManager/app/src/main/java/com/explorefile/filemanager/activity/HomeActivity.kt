package com.explorefile.filemanager.activity

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import androidx.viewpager.widget.ViewPager
import com.example.app.ads.helper.NativeAdsSize
import com.example.app.ads.helper.NativeAdvancedModelHelper
import com.explorefile.filemanager.R
import com.explorefile.filemanager.databinding.ActivityHomeBinding
import com.explorefile.filemanager.fragment.MainFragment
import com.explorefile.filemanager.fragment.SearchFragment
import com.explorefile.filemanager.fragment.recent.RecentFragment
import com.explorefile.filemanager.utils.Utils

class HomeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHomeBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        Utils.setStatusBarColor(R.color.white, this@HomeActivity, true)

        setupViewPager(binding.viewpager)
        binding.tabLayout.setupWithViewPager(binding.viewpager)

        binding.ivSearch.setOnClickListener {
            val intent = Intent(this@HomeActivity, SearchFragment::class.java)
            startActivity(intent)
        }

//        binding.tablayout.setOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
//            override fun onTabSelected(tab: TabLayout.Tab) {
//                binding.viewpager.currentItem = tab.position
//            }
//
//            override fun onTabUnselected(tab: TabLayout.Tab) {
//                //tab.setIcon(tabIcons.get(tab.position))
//            }
//
//            override fun onTabReselected(tab: TabLayout.Tab) {}
//        })

        NativeAdvancedModelHelper(this@HomeActivity).loadNativeAdvancedAd(NativeAdsSize.Medium,binding.adViewHolder)
    }

    private fun setupViewPager(viewPager: ViewPager) {
        val adapter = ViewPagerAdapter(supportFragmentManager,0)
//        adapter.addFragment(RecentFragment())
        adapter.addFragment(MainFragment())
        viewPager.adapter = adapter
        viewPager.currentItem = adapter.count-1
    }

    class ViewPagerAdapter(fm: FragmentManager, behavior: Int) :
        FragmentPagerAdapter(fm, behavior) {
        private val mFragmentList: MutableList<Fragment> = ArrayList()
        override fun getItem(position: Int): Fragment {
            return mFragmentList[position]
        }

        override fun getCount(): Int {
            return mFragmentList.size
        }

        fun addFragment(fragment: Fragment) {
            mFragmentList.add(fragment)
        }

        override fun getPageTitle(position: Int): CharSequence? {
            when(position) {
                0->{
                    return "Recent"
                }
                1->{
                    return "Category"
                }
            }
            return "File Manager"
            //return super.getPageTitle(position)
        }

    }
}