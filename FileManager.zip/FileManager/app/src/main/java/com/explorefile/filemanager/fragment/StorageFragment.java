package com.explorefile.filemanager.fragment;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.example.app.ads.helper.NativeAdsSize;
import com.example.app.ads.helper.NativeAdvancedModelHelper;
import com.explorefile.filemanager.R;
import com.explorefile.filemanager.adapter.StorageAdapter;
import com.explorefile.filemanager.databinding.DialogCreateFolderBinding;
import com.explorefile.filemanager.databinding.FragmentStorageBinding;
import com.explorefile.filemanager.interfaces.ActionModeListener;
import com.explorefile.filemanager.interfaces.FileSelectedListener;
import com.explorefile.filemanager.model.MediaModel;
import com.explorefile.filemanager.utils.OpenFile;
import com.explorefile.filemanager.utils.Utils;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;

import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;


public class StorageFragment extends AppCompatActivity implements FileSelectedListener, ActionModeListener {

    private FragmentStorageBinding binding;
    private String path;
    private StorageAdapter storageAdapter;
    public static ActionModeListener actionModeListener;
    Activity activity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = FragmentStorageBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        if (getIntent() != null) {
            path = getIntent().getStringExtra("path");
        }
        Utils.setStatusBarColor(R.color.white,StorageFragment.this,true);
        onCreateView();

        new NativeAdvancedModelHelper(StorageFragment.this).loadNativeAdvancedAd(NativeAdsSize.Medium, binding.adViewHolder,
                null, true, true, new Function1<Boolean, Unit>() {
                    @Override
                    public Unit invoke(Boolean aBoolean) {
                        return null;
                    }
                }, new Function0<Unit>() {
                    @Override
                    public Unit invoke() {
                        return null;
                    }
                });
    }

    public View onCreateView() {
//        binding = FragmentStorageBinding.inflate(inflater);
        activity = StorageFragment.this;
        binding.rv.setLayoutManager(new LinearLayoutManager(StorageFragment.this));
        storageAdapter = new StorageAdapter(StorageFragment.this, this,"storage");
        binding.rv.setAdapter(storageAdapter);

        setFile();

        binding.createFolder.setOnClickListener(v -> createFolderDialog());

        actionModeListener = this;

        binding.ivBack.setOnClickListener(v -> StorageFragment.this.onBackPressed());

        return binding.getRoot();
    }

    @Override
    public void onResume() {
        super.onResume();
        binding.et.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                storageAdapter.getFilter().filter(s);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    @Override
    public void onStop() {
        super.onStop();
        binding.et.addTextChangedListener(null);
    }

    private void setFile() {
        if (path != null) {
            ArrayList<File> files = shortFile(getFile(new File(path)));

            storageAdapter.addAll(files,null,null,null);
        } else {
            if (Utils.EXTERNAL_FILE != null) {
                ArrayList<File> file = getFile(Utils.EXTERNAL_FILE);
                storageAdapter.addAll(file,null,null,null);
            }
        }
    }

    private void createFolderDialog() {

        Dialog dialog = new Dialog(StorageFragment.this);
        DialogCreateFolderBinding binding = DataBindingUtil.inflate(LayoutInflater.from(StorageFragment.this), R.layout.dialog_create_folder, null, false);
        dialog.setContentView(binding.getRoot());
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.show();

        binding.btnOk.setOnClickListener(v -> createFolder(binding.editText.getText().toString().trim(), dialog));
        binding.btnCancel.setOnClickListener(v -> dialog.cancel());

    }

    private void createFolder(String text, Dialog dialog) {
        if (text != null && text.length() > 0) {
            File file = new File(new File(path), text);
            boolean mkdirs = file.mkdirs();
            if (mkdirs) {
                setFile();
                dialog.dismiss();
            }
        }
    }

    ArrayList<File> shortFile(ArrayList<File> files) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            files.sort(Comparator.comparing(File::getName));
        }
        return files;
    }

    ArrayList<File> getFile(File file) {
        ArrayList<File> fileArrayList = new ArrayList<>();
        File[] files = file.listFiles();

        if (files != null) {
            for (File singleFile : files) {
                if (!singleFile.isHidden()) {
                    fileArrayList.add(singleFile);
                }
            }
        }
        return fileArrayList;
    }

    @Override
    public void onFileSelect(ImageView imageView, File file) {
        if (file.isDirectory()) {
//            Bundle bundle = new Bundle();
//            bundle.putString("path", file.getAbsolutePath());

            Intent storageFragment = new Intent(StorageFragment.this,StorageFragment.class);
            storageFragment.putExtra("path",file.getAbsolutePath());
//            startActivity(storageFragment);
            path=file.getAbsolutePath();
            setFile();

            //StorageFragment.this.getSupportFragmentManager().beginTransaction().replace(MainActivity.MAIN_CONTAINER, storageFragment).addToBackStack(null).commit();

        }else {
            OpenFile.open(file);
        }
    }

    @Override
    public void onBind(ImageView imageView, File file) {

    }

    @Override
    public void onIvSelectClick(ArrayList<File> files, int position, ImageView imageView) {
        Bundle bundle = new Bundle();
        bundle.putSerializable("path", (Serializable) files);
        bundle.putInt("position", position);
        SelectStorageFragment selectStorageFragment = new SelectStorageFragment();
        selectStorageFragment.setArguments(bundle);
        StorageFragment.this.getSupportFragmentManager().beginTransaction().add(binding.container.getId(), selectStorageFragment).addToBackStack(null).commit();
    }

    @Override
    public void onIvMediaSelectClick(ArrayList<MediaModel> files, int position, ImageView imageView) {

    }

    @Override
    public void onBackPressed() {
        String parent=new File(path).getParent();
        Log.e("onBackPressed",parent);
        if(parent!=null) {
//            if(new File(parent).isDirectory()) {
            if(parent.equals(Utils.EXTERNAL_FILE.getParent())) {
                super.onBackPressed();
            } else {
                path=parent;
                setFile();
            }
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public void onEventListener(int event) {
        if (event == Utils.EVENT_DELETE) {
            setFile();
            activity.onBackPressed();
        } else if (event == Utils.EVENT_COPY) {
            setFile();
            new Handler(Looper.getMainLooper()).post(() -> {
                activity.onBackPressed();
            });

        } else if (event == Utils.EVENT_MOVE) {
            setFile();
            activity.onBackPressed();
        }
    }
}