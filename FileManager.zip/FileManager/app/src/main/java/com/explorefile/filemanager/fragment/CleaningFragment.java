package com.explorefile.filemanager.fragment;

import android.os.Build;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.text.format.Formatter;
import android.view.View;
import android.view.WindowManager;

import com.explorefile.filemanager.R;
import com.explorefile.filemanager.databinding.FragmentCleanningBinding;
import com.explorefile.filemanager.databinding.FragmentSelectFavouriteBinding;

import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.Executors;

import pl.droidsonroids.gif.GifDrawable;


public class CleaningFragment extends AppCompatActivity {

    private FragmentCleanningBinding binding;
    private ArrayList<File> files;
    private long filesSize = 0;
    private String file;
    private GifDrawable gifDrawable;

    @Override
    public void onCreate(@Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = FragmentCleanningBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        if (getIntent() != null) {
            Bundle bundle=getIntent().getBundleExtra("data");
            files = (ArrayList<File>) bundle.getSerializable("list");
            filesSize = bundle.getLong("size");
            file = bundle.getString("file");
        }
        onCreateView();
    }

    public View onCreateView() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        }

        binding.tvFileName.setText(file);
        binding.tvSize.setText(Formatter.formatFileSize(CleaningFragment.this, filesSize));
        binding.tvFileSize.setText(Formatter.formatFileSize(CleaningFragment.this, filesSize));
        binding.btnStartClean.setText(String.format("Clean Up %s", Formatter.formatFileSize(CleaningFragment.this, filesSize)));

        binding.imageView11.setOnClickListener(v -> CleaningFragment.this.onBackPressed());

        binding.btnStartClean.setOnClickListener(v -> {
            binding.btnStartClean.setVisibility(View.GONE);
            binding.tvSize.setVisibility(View.GONE);
            binding.ivGif.setVisibility(View.VISIBLE);
            if (filesSize > 0) {
                try {
                    gifDrawable = null;
                    gifDrawable = new GifDrawable(getResources(), R.drawable.clean_gif);
                    binding.ivGif.setImageDrawable(gifDrawable);
                    gifDrawable.start();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            Executors.newSingleThreadExecutor().execute(() -> {
                clean(files);
                CleaningFragment.this.runOnUiThread(() -> {
                    try {
                        gifDrawable = null;
                        gifDrawable = new GifDrawable(getResources(), R.drawable.cleaned_gif);
                        binding.ivGif.setImageDrawable(gifDrawable);
                        gifDrawable.setLoopCount(1);
                        gifDrawable.start();
                        gifDrawable.addAnimationListener(i -> {
                            binding.tvCleaned.setText(String.format("%s Cleaned.", Formatter.formatFileSize(CleaningFragment.this, filesSize)));
                            binding.tvCleaned.setVisibility(View.VISIBLE);
                        });

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                });
            });
        });
        return binding.getRoot();
    }

    private void clean(ArrayList<File> files) {
        for (File file : files) {
            if (file.isDirectory()) {
                try {
                    FileUtils.deleteDirectory(file);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else {
                file.delete();
            }
        }
    }


   /* public static void main(String[] args) {
        *//*for (int i = 1; i <= 5; i++) {
            for (int a = i;a<=5-1; a++){
                System.out.print(" ");
            }
            for (int j = 1;j<=i;j++){  //1 <=2
                System.out.print(" *");
            }
            System.out.println();
        }*//*
    }*/
}