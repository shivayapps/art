package com.explorefile.filemanager.fragment;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.view.View;
import android.widget.ImageView;

import com.explorefile.filemanager.R;
import com.explorefile.filemanager.adapter.StorageAdapter;
import com.explorefile.filemanager.databinding.FragmentFavouriteBinding;
import com.explorefile.filemanager.databinding.FragmentLargeFileBinding;
import com.explorefile.filemanager.db.DbHelper;
import com.explorefile.filemanager.interfaces.ActionModeListener;
import com.explorefile.filemanager.interfaces.FileSelectedListener;
import com.explorefile.filemanager.model.MediaModel;
import com.explorefile.filemanager.utils.OpenFile;
import com.explorefile.filemanager.utils.Utils;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.concurrent.Executors;


public class FavouriteFragment extends AppCompatActivity implements FileSelectedListener, ActionModeListener {

    private FragmentFavouriteBinding binding;
    private ArrayList<File> files = new ArrayList<>();
    private StorageAdapter adapter;
    public static ActionModeListener actionModeListener;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = FragmentFavouriteBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        onCreateView();
    }
    
    public View onCreateView() {
        Utils.setStatusBarColor(R.color.white,FavouriteFragment.this,true);

        actionModeListener = this;

        binding.rv.setLayoutManager(new LinearLayoutManager(FavouriteFragment.this));
        adapter = new StorageAdapter(FavouriteFragment.this, this,"storage");
        binding.rv.setAdapter(adapter);

        setData();

        binding.ivBack.setOnClickListener(v -> FavouriteFragment.this.onBackPressed());

        return binding.getRoot();
    }

    private void setData() {
        files.clear();
        Executors.newSingleThreadExecutor().execute(() -> {
            files.addAll(DbHelper.getFavFile());
            adapter.addAll(files,null,null,binding.noData);
        });
    }

    @Override
    public void onFileSelect(ImageView imageView, File file) {
        if (file.isDirectory()){
//            Bundle bundle = new Bundle();
//            bundle.putString("path", file.getAbsolutePath());
//            StorageFragment storageFragment = new StorageFragment();
//            storageFragment.setArguments(bundle);
//            FavouriteFragment.this.getSupportFragmentManager().beginTransaction().add(MainActivity.MAIN_CONTAINER, storageFragment).addToBackStack(null).commit();
            Intent storageFragment = new Intent(FavouriteFragment.this,StorageFragment.class);
            storageFragment.putExtra("path",file.getAbsolutePath());
            startActivity(storageFragment);
        }else {
            OpenFile.open(file);
        }
    }

    @Override
    public void onBind(ImageView imageView, File file) {

    }

    @Override
    public void onIvSelectClick(ArrayList<File> files, int position, ImageView imageView) {
        Bundle bundle = new Bundle();
        bundle.putSerializable("file", (Serializable) files);
        bundle.putInt("position", position);
//        SelectFavouriteFragment selectFavouriteFragment = new SelectFavouriteFragment();
//        selectFavouriteFragment.setArguments(bundle);

//        FavouriteFragment.this.getSupportFragmentManager().beginTransaction().add(MainActivity.MAIN_CONTAINER, selectFavouriteFragment).addToBackStack(null).commit();
        Intent intent = new Intent(FavouriteFragment.this,SelectFavouriteFragment.class);
        intent.putExtra("data",bundle);
        startActivity(intent);

    }

    @Override
    public void onIvMediaSelectClick(ArrayList<MediaModel> files, int position, ImageView imageView) {

    }

    @Override
    public void onEventListener(int event) {
        if (event == Utils.EVENT_DELETE) {
            setData();
        }
    }
}