package com.explorefile.filemanager.interfaces;

public interface ActionModeListener {
    void onEventListener(int event);
}
