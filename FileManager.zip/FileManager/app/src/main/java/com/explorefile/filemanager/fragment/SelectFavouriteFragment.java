package com.explorefile.filemanager.fragment;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.view.View;
import android.widget.ImageView;

import com.explorefile.filemanager.R;
import com.explorefile.filemanager.adapter.StorageAdapter;
import com.explorefile.filemanager.databinding.FragmentSearchBinding;
import com.explorefile.filemanager.databinding.FragmentSelectFavouriteBinding;
import com.explorefile.filemanager.db.DbHelper;
import com.explorefile.filemanager.interfaces.FileSelectedListener;
import com.explorefile.filemanager.model.MediaModel;
import com.explorefile.filemanager.utils.Utils;

import java.io.File;
import java.util.ArrayList;


public class SelectFavouriteFragment extends AppCompatActivity implements FileSelectedListener {

    private FragmentSelectFavouriteBinding binding;
    private ArrayList<File> files;
    int position;
    private ArrayList<File> selectedList = new ArrayList<>();

    @Override
    public void onCreate(@Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = FragmentSelectFavouriteBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        if (getIntent() != null){
            Bundle bundle=getIntent().getBundleExtra("data");
            files = (ArrayList<File>) bundle.getSerializable("file");
            position = bundle.getInt("position");
        }
        onCreateView();
    }

    public View onCreateView() {
        selectedList.add(files.get(position));
        binding.rv.setLayoutManager(new LinearLayoutManager(SelectFavouriteFragment.this));
        StorageAdapter storageAdapter = new StorageAdapter(SelectFavouriteFragment.this,this,"storage");
        binding.rv.setAdapter(storageAdapter);
        storageAdapter.addAll(files,null,null,null);
        binding.rv.scrollToPosition(position);

        binding.lyCancel.setOnClickListener(v -> SelectFavouriteFragment.this.onBackPressed());

        binding.lyAction.setOnClickListener(v -> {
            for (File file : selectedList){
                DbHelper.removeFavourite(file.getAbsolutePath());
            }
            FavouriteFragment.actionModeListener.onEventListener(Utils.EVENT_DELETE);
            SelectFavouriteFragment.this.onBackPressed();
        });

        return binding.getRoot();
    }

    @Override
    public void onFileSelect(ImageView imageView, File file) {

    }

    @Override
    public void onBind(ImageView imageView, File file) {
        if (isAvailable(file)) {
            imageView.setImageResource(R.drawable.ic_selected);
        } else {
            imageView.setImageResource(R.drawable.no_select);
        }
    }

    @Override
    public void onIvSelectClick(ArrayList<File> files, int position, ImageView imageView) {
        if (imageView.getDrawable().getConstantState().equals(getResources().getDrawable(R.drawable.ic_selected).getConstantState())) {
            selectedList.remove(files.get(position));
            imageView.setImageResource(R.drawable.no_select);
        } else {
            selectedList.add(files.get(position));
            imageView.setImageResource(R.drawable.ic_selected);
        }
        binding.tvCounter.setText(String.format("%d Selected", selectedList.size()));
    }

    @Override
    public void onIvMediaSelectClick(ArrayList<MediaModel> files, int position, ImageView imageView) {

    }

    private boolean isAvailable(File file) {
        for (int i = 0; i < selectedList.size(); i++) {
            if (file.equals(selectedList.get(i))) {
                return true;
            }
        }
        return false;
    }
}