package com.explorefile.filemanager.junckcleaner.interfaces;

public interface AdClosed {
    void addDismissed(boolean closed);

    void addFailed(boolean closed);
}
