package com.explorefile.filemanager.fragment;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;

import android.view.View;

import com.explorefile.filemanager.R;
import com.explorefile.filemanager.adapter.HomeAppAdapter;
import com.explorefile.filemanager.databinding.FragmentDownloadBinding;
import com.explorefile.filemanager.databinding.FragmentMoreBinding;
import com.explorefile.filemanager.interfaces.HomeAppClickListener;
import com.explorefile.filemanager.utils.Utils;


public class MoreFragment extends AppCompatActivity implements HomeAppClickListener {

    private FragmentMoreBinding binding;
    private String[] apps = {"Images", "Audio", "Videos", "Zips", "Apps", "Document", "Download"};

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = FragmentMoreBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
//        if (getArguments() != null) {
//            arg = getArguments().getString("APPS");
//        }
        onCreateView();
    }

    public View onCreateView() {
        Utils.setStatusBarColor(R.color.white, MoreFragment.this, true);

        binding.rv.setLayoutManager(new GridLayoutManager(MoreFragment.this, 4));
        HomeAppAdapter homeAppAdapter = new HomeAppAdapter(MoreFragment.this, apps, this);
        binding.rv.setAdapter(homeAppAdapter);
        binding.ivBack.setOnClickListener(v -> MoreFragment.this.onBackPressed());


        binding.icFavourite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MoreFragment.this,FavouriteFragment.class);
                startActivity(intent);
            }
        }); binding.icLargeFiles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MoreFragment.this,LargeFileFragment.class);
                startActivity(intent);
            }
        });

        return binding.getRoot();
    }

    @Override
    public void onHomeAppClick(String name) {
        if (apps[0].equals(name) || apps[1].equals(name) || apps[2].equals(name)) {
//            Bundle bundle = new Bundle();
//            bundle.putString("FILE", name);
//            ImageFragment imageFragment = new ImageFragment();
//            imageFragment.setArguments(bundle);
//            MoreFragment.this.getSupportFragmentManager().beginTransaction().replace(MainActivity.MAIN_CONTAINER, imageFragment).addToBackStack(null).commit();

            Intent storageFragment = new Intent(MoreFragment.this, ImageFragment.class);
            storageFragment.putExtra("FILE", name);
            startActivity(storageFragment);
        } else if (apps[3].equals(name)) {
//            MoreFragment.this.getSupportFragmentManager().beginTransaction().replace(MainActivity.MAIN_CONTAINER,new ZipFragment()).addToBackStack(null).commit();
            Intent zipFragment = new Intent(MoreFragment.this, ZipFragment.class);
            startActivity(zipFragment);
        } else if (apps[4].equals(name)) {

            /*Bundle bundle = new Bundle();
            bundle.putString("APPS",name);
            AppsFragment appsFragment = new AppsFragment();
            appsFragment.setArguments(bundle);*/
//            MoreFragment.this.getSupportFragmentManager().beginTransaction().replace(MainActivity.MAIN_CONTAINER,new AppsFragment()).addToBackStack(null).commit();
            Intent appsFragment = new Intent(MoreFragment.this, AppsFragment.class);
            startActivity(appsFragment);
        } else if (apps[5].equals(name)) {
//            MoreFragment.this.getSupportFragmentManager().beginTransaction().replace(MainActivity.MAIN_CONTAINER,new DocumentFragment()).addToBackStack(null).commit();
            Intent documentFragment = new Intent(MoreFragment.this, DocumentFragment.class);
            startActivity(documentFragment);
        } else if (apps[6].equals(name)) {
//            MoreFragment.this.getSupportFragmentManager().beginTransaction().replace(MainActivity.MAIN_CONTAINER,new DownloadFragment()).addToBackStack(null).commit();
            Intent intent = new Intent(MoreFragment.this, DownloadFragment.class);
            startActivity(intent);
        }
    }


}