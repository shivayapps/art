package com.explorefile.filemanager.fragment;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import android.view.View;

import com.explorefile.filemanager.R;
import com.explorefile.filemanager.databinding.FragmentImageBinding;
import com.explorefile.filemanager.utils.Utils;

import java.util.ArrayList;

public class ImageFragment extends AppCompatActivity {

    private FragmentImageBinding binding;
    private String argPath="Images";
    private String[] apps = {"Images", "Audio", "Videos", "Zips", "Apps", "Document", "Download", "More"};
    public static int CON;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = FragmentImageBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        if (getIntent() != null) {
            argPath = getIntent().getStringExtra("FILE");
        }
        Utils.setStatusBarColor(R.color.white,ImageFragment.this,true);
        onCreateView();
    }

    public View onCreateView() {
        CON = binding.container.getId();
        ImagePagerAdapter pagerAdapter = new ImagePagerAdapter(getSupportFragmentManager());

        if (argPath.equals(apps[0])){
            binding.tvTitle.setText(apps[0]);
            pagerAdapter.addFragment(new AllImageFragment(),"Image");
            pagerAdapter.addFragment(new ImageFolderFragment(),"Album");
        }else if (argPath.equals(apps[1])){
            binding.tvTitle.setText(apps[1]);
            pagerAdapter.addFragment(new SongFragment(),"Song");
            pagerAdapter.addFragment(new SongFolderFragment(),"Albums");
        }else if (argPath.equals(apps[2])){
            binding.tvTitle.setText(apps[2]);
            pagerAdapter.addFragment(new VideoFragment(),"Video");
            pagerAdapter.addFragment(new VideoFolderFragment(),"Folders");
        }else if (argPath.equals(apps[3])){
            binding.tvTitle.setText(apps[3]);

        }else if (argPath.equals(apps[4])){
            binding.tvTitle.setText(apps[4]);

        }else if (argPath.equals(apps[5])){
            binding.tvTitle.setText(apps[5]);

        }else if (argPath.equals(apps[6])){
            binding.tvTitle.setText(apps[6]);

        }else if (argPath.equals(apps[7])){
            binding.tvTitle.setText(apps[7]);
        }

        binding.viewPager.setAdapter(pagerAdapter);
        binding.tabLayout.setupWithViewPager(binding.viewPager);

        binding.ivBack.setOnClickListener(v -> ImageFragment.this.onBackPressed());

        return binding.getRoot();
    }

    private class ImagePagerAdapter extends FragmentPagerAdapter{

        ArrayList<Fragment> fragmentList = new ArrayList<>();
        ArrayList<String> stringList = new ArrayList<>();

        public ImagePagerAdapter(@NonNull FragmentManager fm) {
            super(fm);
        }

        public void addFragment(Fragment fragment, String title){
            fragmentList.add(fragment);
            stringList.add(title);
        }

        @NonNull
        @Override
        public Fragment getItem(int position) {
            return fragmentList.get(position);
        }

        @Override
        public int getCount() {
            return fragmentList.size();
        }

        @Nullable
        @Override
        public CharSequence getPageTitle(int position) {
            return stringList.get(position);
        }
    }
}