package com.photo.effect.motion.editor.model

class StickerData(
    var stickerId: Int,
    var stickerName: String,
    var stickerFolderNameFPath: String,
    var isSelected: Boolean,
    var stickerThumb: Int
)