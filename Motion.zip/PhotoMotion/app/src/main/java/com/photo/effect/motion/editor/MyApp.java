package com.photo.effect.motion.editor;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.StrictMode;
import android.os.StrictMode.VmPolicy.Builder;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;

import com.example.app.ads.helper.VasuAdsConfig;
import com.example.app.ads.helper.openad.AppOpenApplication;
import com.example.app.ads.helper.openad.OpenAdHelper;
import com.photo.effect.motion.editor.activity.SavingActivity;
import com.photo.effect.motion.editor.activity.SplashActivity;
import com.photo.effect.motion.editor.callback.ProgressUpdateListener;
import com.photo.effect.motion.editor.utils.AppHelper;
import com.photo.effect.motion.editor.utils.TypefaceUtil;


import java.io.File;

import kotlin.Unit;
import kotlin.jvm.functions.Function0;

public class MyApp extends AppOpenApplication implements AppOpenApplication.AppLifecycleListener {
    public static boolean isDialogOpen=false;
    public static Context context;
    private static MyApp myApplication;
    private static ProgressUpdateListener onProgressReceiver;
//    public InterstitialAd mInterstitialAd;
    Intent intent;
    boolean isFinished;

    public static MyApp getApplication() {
        return myApplication;
    }

    public static void setApplication(MyApp application) {
        myApplication = application;
    }

    public static Context getContext() {
        return context;
    }

    public static void setContext(Context context) {
        MyApp.context = context;
    }

    public void onCreate() {
        super.onCreate();
        setApplication(this);

        StrictMode.setVmPolicy(new Builder().build());
        TypefaceUtil.overrideFont(getApplicationContext(), "serif", "fonts/OpenSans-Regular.ttf");
        setContext(getApplicationContext());

        VasuAdsConfig.with(this)
                .isEnableOpenAd(true)
                .needToTakeAllTestAdID(false)
                .setAdmobAppId(getString(R.string.ad_mob_app_id_live))
                .setAdmobBannerAdId(getString(R.string.ad_mob_banner_id_live))
                .setAdmobInterstitialAdId(getString(R.string.ad_mob_interstitial_id_live))
                .setAdmobNativeAdvancedAdId(getString(R.string.ad_mob_native_id_live))
                .setAdmobOpenAdId(getString(R.string.ad_mob_app_open_id_live))
                .initialize();

        OpenAdHelper.INSTANCE.loadOpenAd(this, new Function0<Unit>() {
            @Override
            public Unit invoke() {
                return null;
            }
        });
        setAppLifecycleListener(this);

    }

    public static boolean checkForStoragePermission(Activity activity) {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            if (ActivityCompat.checkSelfPermission(activity, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                return false;
            } else {
                return true;
            }
        }else {
            if (ActivityCompat.checkSelfPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                return false;
            } else {
                return true;
            }

        }
    }

    public static void deleteTemp() {
        ContextWrapper cw = new ContextWrapper(context);
        File localStore = cw.getDir("localStore", Context.MODE_PRIVATE);
        File files = cw.getDir("files", Context.MODE_PRIVATE);
        if (localStore.exists()) {
            deleteDir(localStore);
        }
        if (files.exists()) {
            deleteDir(files);
        }
    }

    public static boolean deleteDir(File dir) {
        if (dir.isDirectory()) {
            String[] children = dir.list();
            for (int i=0; i<children.length; i++) {
                boolean success = deleteDir(new File(dir, children[i]));
                if (!success) {
                    return false;
                }
            }
        }

        // The directory is now empty so delete it
        return dir.delete();
    }



    public ProgressUpdateListener getOnProgressReceiver() {
        return this.onProgressReceiver;
    }

    public void setOnProgressReceiver(ProgressUpdateListener onProgressReceiver) {
        this.onProgressReceiver = onProgressReceiver;
    }



    public boolean needToShowAd() {
        return true;

//        int ads_per_click = 2;
//        int getCount = AppHelper.getClickCount();
//        int newCount = getCount + 1;
//        AppHelper.setClickCount(newCount);
//        if (getCount != 0 && getCount % ads_per_click == 0) {
//            return true;
//        }
//        return false;
    }




    @Override
    public boolean onResumeApp(@NonNull Activity fCurrentActivity) {
//        if(new AdsManager(fCurrentActivity).isNeedToShowAds()) {
//            return false;
//        }
        Log.d("onResumeApp", "onResumeApp:"+fCurrentActivity.getLocalClassName());
        if(fCurrentActivity instanceof SplashActivity) {
            Log.d("onResumeApp", "onResumeApp:SplashActivity");
            return false;
        } else if(fCurrentActivity instanceof SavingActivity) {
            Log.d("onResumeApp", "onResumeApp:SavingActivity");
            return false;
        } else if(MyApp.isDialogOpen) {
            Log.d("onResumeApp", "onResumeApp:isDialogOpen:"+MyApp.isDialogOpen);
            return false;
        }
        Log.d("onResumeApp", "onResumeApp:resume true");
        return true;
    }
}