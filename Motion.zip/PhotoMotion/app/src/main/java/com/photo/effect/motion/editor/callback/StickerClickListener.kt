package com.photo.effect.motion.editor.callback

import com.photo.effect.motion.editor.model.StickerData

interface StickerClickListener {
    fun onClick(stickerData: StickerData, i: Int)
}