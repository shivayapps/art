package com.photo.effect.motion.editor.permission;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Bundle;

import androidx.core.app.ActivityCompat;

import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;

import com.photo.effect.motion.editor.MyApp;

/**
 * read and check contect access permission.
 */
public class ReadContact_Permission extends Activity {
    private AlertDialog update;
    String[] permissionsRequired = new String[]{Manifest.permission.READ_CONTACTS};
    private static final int PERMISSION_CALLBACK_CONSTANT = 100;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        PermissionManager.doPermissionTask(ReadContact_Permission.this, new PermissionManager.callBackWithDismiss() {
            @Override
            public void doNext() {
                MyApp.isDialogOpen=false;
                finish();
            }

            @Override
            public void noPermission(boolean hasAndroidPermissions) {
                MyApp.isDialogOpen=false;
            }

            @Override
            public void onDismiss() {
                MyApp.isDialogOpen=false;
                finish();
            }
        }, new String[]{Manifest.permission.READ_CONTACTS});

//         if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//             checkpermission();
//         } else {
//             finish();
//         }
    }

    private void checkpermission() {
        if (ActivityCompat.checkSelfPermission(ReadContact_Permission.this, permissionsRequired[0]) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(ReadContact_Permission.this, permissionsRequired, PERMISSION_CALLBACK_CONSTANT);
        } else {
            proceedAfterPermission();
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_CALLBACK_CONSTANT) {
            boolean allgranted = false;
            allgranted = ActivityCompat.checkSelfPermission(ReadContact_Permission.this, permissionsRequired[0]) == PackageManager.PERMISSION_GRANTED;
            if (allgranted) {
                proceedAfterPermission();
            } else if (ActivityCompat.shouldShowRequestPermissionRationale(ReadContact_Permission.this, permissionsRequired[0])) {
                proceedAfterPermission();
                Toast.makeText(getBaseContext(), "Unable to get Permission", Toast.LENGTH_LONG).show();
            } else {
                proceedAfterPermission();
                Toast.makeText(getBaseContext(), "Unable to get Permission", Toast.LENGTH_LONG).show();
            }
        }
    }


    private void proceedAfterPermission() {
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (update != null) {
            update.dismiss();
        }
    }

}

