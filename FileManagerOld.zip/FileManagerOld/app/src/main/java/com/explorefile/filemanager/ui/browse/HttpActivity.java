package com.explorefile.filemanager.ui.browse;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.appcompat.widget.Toolbar;
import androidx.preference.PreferenceManager;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.explorefile.filemanager.R;
import com.explorefile.filemanager.Util;
import com.explorefile.filemanager.http.MainService;
import com.explorefile.filemanager.http.Session;
import com.explorefile.filemanager.http.Utils;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.encoder.QRCode;

import java.util.Hashtable;

public class HttpActivity extends AppCompatActivity {

    public boolean waiting;
    SwitchCompat switch_ss;
    private MyConnection conn;
    private TextView ip_tv;
    Toolbar toolbar;
    TextView title;
    ImageView icon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_http);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        title = findViewById(R.id.title);
        icon = findViewById(R.id.icon);

        conn = new MyConnection();

        ip_tv = findViewById(R.id.fragment_main_ip_textview);
        icon.setOnClickListener((View view) -> {
            onBackPressed();
        });
        //QRCode = rootview.findViewById(R.id.fragment_main_qrcode_imageview);
        ip_tv.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View p1)
            {
                refreshQR();
            }
        });
        switch_ss = findViewById(R.id.fragment_status_switch);
        update_status();
        switch_ss.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

            @Override
            public void onCheckedChanged(CompoundButton p1, boolean p2)
            {
                if (!p1.isPressed())
                {
                    return;
                }
                Intent intent = new Intent(HttpActivity.this, MainService.class);
                if (p2)
                {
                    startService(intent);
                    waiting = true;
                    //lv.setEnabled(false);
                    //pb.setVisibility(View.VISIBLE);
                    switch_ss.setEnabled(false);
                }
                else
                {
                    unbindService(conn);
                    stopService(intent);
                }
                update_status();
                refreshQR();
            }
        });

        SettingFragment fragment = new SettingFragment();
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.preference_fragment_container, fragment)
                .commit();

    }

    @Override
    public void onResume()
    {
        super.onResume();
        update_status();
        refreshQR();
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK) {
            Toast.makeText(this, "The home directory has been updated", Toast.LENGTH_SHORT).show();
            if (getContentResolver().getPersistedUriPermissions().size() > 0) {
                getContentResolver().releasePersistableUriPermission(getContentResolver().getPersistedUriPermissions().get(0).getUri(), Intent.FLAG_GRANT_READ_URI_PERMISSION |
                        Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            }
            getContentResolver().takePersistableUriPermission(data.getData(),
                    Intent.FLAG_GRANT_READ_URI_PERMISSION |
                            Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            //PreferenceManager.getDefaultSharedPreferences(this).edit().putString("uriPath", data.getData().toString()).apply();
            Session.sessions.clear();
        }
    }

    private void update_status()
    {
        if (Utils.isMainServiceRunning(HttpActivity.this))
        {
            switch_ss.setChecked(true);
            bindService(new Intent(HttpActivity.this, MainService.class), conn, Context.BIND_AUTO_CREATE);
        }
        else
        {
            switch_ss.setChecked(false);
        }
    }
    private void refreshQR()
    {
        new Handler().postDelayed(new Runnable(){

            @Override
            public void run()
            {
                if (Utils.isMainServiceRunning(HttpActivity.this))
                {
                    String ip=Utils.getLocalIpAddress();
                    if (ip.equals("0"))
                    {
                        ip_tv.setText(getString(R.string.no_internet));
                        //QRCode.setVisibility(View.GONE);
                    }
                    else
                    {
                        String url="http://" + ip + ":" + PreferenceManager.getDefaultSharedPreferences(HttpActivity.this.getApplicationContext()).getString("serverPort", "-1");
                        ip_tv.setText(String.format(getString(R.string.server_started),url));
                        Hashtable<EncodeHintType, String> hints = new Hashtable<EncodeHintType, String>();
                        hints.put(EncodeHintType.CHARACTER_SET, "utf-8");
                        /*try
                        {
                            BitMatrix bitMatrix = new QRCodeWriter().encode(url, BarcodeFormat.QR_CODE, QRCode.getWidth(), QRCode.getHeight(), hints);
                            int[] pixels = new int[QRCode.getWidth() * QRCode.getHeight()];
                            for (int y = 0; y < QRCode.getHeight(); y++)
                            {
                                for (int x = 0; x < QRCode.getWidth(); x++)
                                {
                                    if (bitMatrix.get(x, y))
                                    {
                                        pixels[y * QRCode.getWidth() + x] = 0xff000000;
                                    }
                                    else
                                    {
                                        pixels[y * QRCode.getWidth() + x] = 0xffffffff;
                                    }
                                }
                            }
                            //生成二维码图片的格式，使用ARGB_8888
                            Bitmap bitmap = Bitmap.createBitmap(QRCode.getWidth(), QRCode.getHeight(), Bitmap.Config.ARGB_8888);
                            bitmap.setPixels(pixels, 0, QRCode.getWidth(), 0, 0, QRCode.getWidth(), QRCode.getHeight());
                            QRCode.setImageBitmap(bitmap);
                            QRCode.setVisibility(View.VISIBLE);
                        }
                        catch (Exception e)
                        {
                            e.printStackTrace();
                            ip_tv.setText(String.format(getString(R.string.genqr_fail),url));
                        }*/
                    }
                }
                else
                {
                    ip_tv.setText(getText(R.string.server_stopped));
                    //QRCode.setVisibility(View.GONE);
                }
            }
        }, 100);

    }

    private class MyConnection implements ServiceConnection
    {

        @Override
        public void onServiceConnected(ComponentName name, IBinder binder)
        {
            final MainService.mBinder service = (MainService.mBinder) binder;
            if (!service.service.started)
            {
                new Handler().postDelayed(new Runnable(){

                    @Override
                    public void run()
                    {
                        String err=service.service.getError();
                        if (!err.equals(""))
                        {
                            if (Utils.isMainServiceRunning(HttpActivity.this))
                            {
                                unbindService(conn);
                                Intent intent = new Intent(HttpActivity.this, MainService.class);
                                stopService(intent);
                                new AlertDialog.Builder(HttpActivity.this).setTitle("Server failed to start").setMessage(err).setPositiveButton("determine", null).setCancelable(false).show();
                            }
                            //Toast.makeText(HttpActivity.this,err,Toast.LENGTH_SHORT).show();
                        }
                        (HttpActivity.this).waiting = false;
                        //(HttpActivity.this).pb.setVisibility(View.GONE);
                        //(HttpActivity.this).lv.setEnabled(true);
                        switch_ss.setEnabled(true);
                        update_status();
                    }
                }, 500);
                service.service.started = true;
            }

        }

        @Override
        public void onServiceDisconnected(ComponentName name)
        {

        }
    }

    @Override
    public void onDestroy()
    {
        super.onDestroy();
        if (Utils.isMainServiceRunning(HttpActivity.this))
        {
            unbindService(conn);
        }
    }
}