package com.explorefile.filemanager.adapter.viewHolder;

import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.explorefile.filemanager.R;


public class FileViewHolder extends RecyclerView.ViewHolder{

    public TextView name,info,size;
    public ImageView icon;
    public RelativeLayout mainView;
    public FileViewHolder(View v){
        super(v);
        name=v.findViewById(R.id.name);
        icon=v.findViewById(R.id.icon);
        info=v.findViewById(R.id.info);
        size=v.findViewById(R.id.size);
        mainView=v.findViewById(R.id.main_view);
    }

}
