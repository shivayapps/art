package com.explorefile.filemanager;


public interface BreadCrumbsListener {
    void onCrumbSelected(String requiredPath);
}
