package com.explorefile.filemanager;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.Date;


public class MyPreferenceManager {

    public static final String PREF_SETTINGS_HIDE_SYSTEM_APPS = "hide_system_apps";
    public static final String PREF_SETTINGS_HIDE_UNINSTALL_APPS = "hide_uninstall_apps";
    public static final String PREF_SETTINGS_UPDATE_APPS = "update_notification_apps";
    public static final String PREF_SETTINGS_PHONE_USAGE_ALERT = "phone_usage_alert";
    public static final String PREF_SETTINGS_PHONE_USAGE_HOUR = "phone_usage_hour";
    public static final String PREF_LIST_SORT = "sort_list";
    public static final String PREF_LIST_DURATION = "duration_list";
    public static final String FCM_ID = "fcm_id";
    private static final String PREF_NAME = "preference_application";
    public static final String STORED_INTERSTITIAL_TIME = "stored_interstitial_time";
    public static final String ITIME_INTERVAL = "ITimeInterval";

    private static MyPreferenceManager mManager;
    private static SharedPreferences mShare;

    private MyPreferenceManager() { }

    public static void init(Context context) {
        mManager = new MyPreferenceManager();
        mShare = context.getApplicationContext().getSharedPreferences(PREF_NAME, 0);
    }

    public static MyPreferenceManager getInstance() {
        return mManager;
    }

    public void putBoolean(String key, boolean value) {
        mShare.edit().putBoolean(key, value).apply();
    }
    public boolean getBoolean(String key) {
        return mShare.getBoolean(key, false);
    }
    public boolean getBoolean(String key,boolean b) {
        return mShare.getBoolean(key, b);
    }

    public void putInt(String key, int value) {
        mShare.edit().putInt(key, value).apply();
    }
    public int getInt(String key) {
        return mShare.getInt(key, 0);
    }

    public void putLong(String key, long value) {
        mShare.edit().putLong(key, value).apply();
    }
    public long getLong(String key) {
        return mShare.getLong(key, 0);
    }


    public void putString(String key, String value) {
        mShare.edit().putString(key, value).apply();
    }

    public String getString(String key) {
        return mShare.getString(key, "");
    }

    public static float getCurrentTime() {
        final SimpleDateFormat dateFormat = new SimpleDateFormat("mm:ss");
        String currentTime = dateFormat.format(new Date());
        return Float.parseFloat(currentTime.replace(":", ".")) * 1000;
    }

    public void setShowedInterstitialTime() {
        final SimpleDateFormat dateFormat = new SimpleDateFormat("mm:ss");
        String currentTime = dateFormat.format(new Date());
        float currentTimeToStore = (Float.parseFloat(currentTime.replace(":", ".")) * 1000);
        mShare.edit().putString(STORED_INTERSTITIAL_TIME, String.valueOf(currentTimeToStore)).apply();
    }

    public float getShowedInterstitialTime() {
        String showedTime = mShare.getString(STORED_INTERSTITIAL_TIME,"300");
        return Float.parseFloat(showedTime);
    }

    public float getITimeInterval() {
        String iTimeInterval = mShare.getString(ITIME_INTERVAL,"300");
        return Float.parseFloat(iTimeInterval);
    }

    public void setITimeInterval(String iTimeInterval) {
        float iTimeIntervalToStore = Float.parseFloat(iTimeInterval) * 1000;
        mShare.edit().putString(ITIME_INTERVAL, String.valueOf(iTimeIntervalToStore)).apply();
    }

    public boolean isTimeToShowInterstitial() {
        Log.e("getCurrentTimeTo----->", "isTimeToShowAd: " + getCurrentTime());
        Log.e("getShowedTime----->", "isTimeToShowAd: " + getShowedInterstitialTime());
        Log.e("getITimeInterval----->", "isTimeToShowAd: " + getITimeInterval());
        if ((getCurrentTime() - getShowedInterstitialTime()) >= getITimeInterval()) {
            return true;
        } else {
            return false;
        }
    }

}
