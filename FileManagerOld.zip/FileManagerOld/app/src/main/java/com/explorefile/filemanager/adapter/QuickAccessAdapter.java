package com.explorefile.filemanager.adapter;

import androidx.recyclerview.widget.RecyclerView;

import android.content.res.ColorStateList;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.explorefile.filemanager.OnRecyclerItemClickListener;
import com.explorefile.filemanager.R;
import com.explorefile.filemanager.adapter.viewHolder.QuickAccessViewHolder;
import com.explorefile.filemanager.ui.browse.HomeActivity;

import java.util.ArrayList;
import java.util.List;


public class QuickAccessAdapter extends RecyclerView.Adapter<QuickAccessViewHolder> {

    List<String> quickAccessList = new ArrayList<>();
    OnRecyclerItemClickListener onRecyclerItemClickListener;
    int[] backgroundColor;

    public QuickAccessAdapter(List<String> quickAccessList, int[] backgroundColor) {
        this.quickAccessList = quickAccessList;
        this.backgroundColor = backgroundColor;

    }


    @Override
    public QuickAccessViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.quick_access_view, parent, false);
        return new QuickAccessViewHolder(v);
    }

    public void setOnRecyclerItemClickListener(OnRecyclerItemClickListener onRecyclerItemClickListener) {
        this.onRecyclerItemClickListener = onRecyclerItemClickListener;
    }

    @Override
    public void onBindViewHolder(QuickAccessViewHolder holder, int position) {
        holder.label.setText(quickAccessList.get(position));

        switch (quickAccessList.get(position)) {
            case HomeActivity.IMAGES:
                holder.icon.setImageResource(R.drawable.main_image);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    holder.icon.setBackgroundTintList(ColorStateList.valueOf(backgroundColor[position]));
                } else {
                    holder.icon.setBackgroundColor(backgroundColor[position]);
                }
                //holder.iconCard.setCardBackgroundColor(backgroundColor[position]);
                break;
            case HomeActivity.VIDEO:
                holder.icon.setImageResource(R.drawable.main_video);
                //holder.icon.setBackgroundColor(backgroundColor[position]);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    holder.icon.setBackgroundTintList(new ColorStateList(new int[][]{
                            new int[]{android.R.attr.state_pressed},
                            new int[]{}
                    },
                            new int[] {
                                    backgroundColor[position],
                                    backgroundColor[position]
                            }));
                }
                //holder.iconCard.setCardBackgroundColor(backgroundColor[position]);
                break;
            case HomeActivity.AUDIO:
                holder.icon.setImageResource(R.drawable.main_music);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    holder.icon.setBackgroundTintList(ColorStateList.valueOf(backgroundColor[position]));
                } else {
                    holder.icon.setBackgroundColor(backgroundColor[position]);
                }
                //holder.iconCard.setCardBackgroundColor(backgroundColor[position]);
                break;
            case HomeActivity.DOCUMENTS:
                holder.icon.setImageResource(R.drawable.main_files);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    holder.icon.setBackgroundTintList(ColorStateList.valueOf(backgroundColor[position]));
                } else {
                    holder.icon.setBackgroundColor(backgroundColor[position]);
                }
                //holder.iconCard.setCardBackgroundColor(backgroundColor[position]);
                break;
            case HomeActivity.APK:
                holder.icon.setImageResource(R.drawable.main_package);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    holder.icon.setBackgroundTintList(ColorStateList.valueOf(backgroundColor[position]));
                } else {
                    holder.icon.setBackgroundColor(backgroundColor[position]);
                }
                //holder.iconCard.setCardBackgroundColor(backgroundColor[position]);
                break;
            case HomeActivity.ARCHIVE:
                holder.icon.setImageResource(R.drawable.main_zip);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    holder.icon.setBackgroundTintList(ColorStateList.valueOf(backgroundColor[position]));
                } else {
                    holder.icon.setBackgroundColor(backgroundColor[position]);
                }
                //holder.iconCard.setCardBackgroundColor(backgroundColor[position]);
                break;
        }

        holder.constraintLayout.setOnClickListener(view -> {
            if (onRecyclerItemClickListener != null) {
                onRecyclerItemClickListener.onClick(holder.constraintLayout, position);
            }
        });

        holder.constraintLayout.setOnLongClickListener(view -> {

            if (onRecyclerItemClickListener != null)
                onRecyclerItemClickListener.onLongClick(holder.constraintLayout, position);
            return true;
        });

    }

    @Override
    public int getItemCount() {
        return quickAccessList.size();
    }
}
