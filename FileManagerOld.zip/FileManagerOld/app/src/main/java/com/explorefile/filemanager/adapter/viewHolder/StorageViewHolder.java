package com.explorefile.filemanager.adapter.viewHolder;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.explorefile.filemanager.R;
import com.explorefile.filemanager.ui.ProgressPieView;


public class StorageViewHolder extends RecyclerView.ViewHolder{

    public TextView used,total,free,percentage,label;
    public TextView storageSpace;
    public ProgressBar progressBar;
    public ProgressPieView progressBarPie;
    public CardView rootView;

    public StorageViewHolder(View v){
        super(v);
        storageSpace=v.findViewById(R.id.storageSpace);
        used=v.findViewById(R.id.used);
        total=v.findViewById(R.id.total);
        free=v.findViewById(R.id.free);
        label=v.findViewById(R.id.label);
        percentage=v.findViewById(R.id.percentage);
        progressBarPie=v.findViewById(R.id.progressBarPie);
        progressBar=v.findViewById(R.id.progressBar);
        rootView=(CardView) v;
    }

}
