package com.explorefile.filemanager.fileEx;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.util.Log;
import android.webkit.MimeTypeMap;

import com.explorefile.filemanager.Util;
import com.explorefile.filemanager.fileEx.model.FileDirectory;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.FlowableEmitter;
import io.reactivex.FlowableOnSubscribe;

public class FileEx {

    private Map<String, String> directoryPathMap = new LinkedHashMap<>();
    private Map<String, String> filesPathMap = new LinkedHashMap<>();
    private static final String TAG = FileEx.class.getSimpleName();
    private List<String> completeList = new ArrayList<>();
    private List<String> tempList = new ArrayList<>();
    private static String currentDir = "";
    private static String previousDir = "";
    public static final String DOC_SELECTOR = "___^";
    private static String defaultDir = "";
    private File file = null;
    private File[] files;
    public static final int INTERNAL = 7;
    public static final int EXTERNAL = 8;
    private static final int DIRECTORY_CREATED = 11;
    private static final int DIRECTORY_ALREADY_EXISTS = 12;
    private static final int DIRECTORY_ERROR = 13;
    private static List<String> fileList = new ArrayList<>();
    public static final String SD_CARD = "sdCard";
    public static final int COPY = 11;
    public static final int MOVE = 13;
    public static final String EXTERNAL_SD_CARD = "externalSdCard";
    private static final String ENV_SECONDARY_STORAGE = "SECONDARY_STORAGE";
    private String tempDir = null;
    static Context context;
    public static boolean showHiddenFile=false;
    private SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
    private static List<FileDirectory> searchResultList = new ArrayList<>();
    private static FileEx fileEx = null;
    private static String excludedDir[] = {".app_icon_back"};
    private static SharedPreferences sharedPreferences;



    /**
     * Method to create FileEx Instance
     *
     * @param dir
     * @return FileEx
     */

    public static synchronized FileEx newFileManager(String dir, Context c) {

        if (fileEx == null) {
            fileEx = new FileEx(dir);
            currentDir = dir;
            previousDir = null;
            context = c;
            sharedPreferences = c.getSharedPreferences(Util.DIR_DATA, Context.MODE_PRIVATE);
            showHiddenFile=sharedPreferences.getBoolean(Util.SHOW_HIDDEN,false);
        }
        return fileEx;
    }

    private FileEx(String dir) {
        try {
            file = new File(dir);
            currentDir = dir;
            defaultDir = dir;
            previousDir = null;

        } catch (NullPointerException e) {
            e.printStackTrace();
        }
    }

    public static ArrayList<StorageType> getStorages(Context context) {
        ArrayList<StorageType> storages = new ArrayList<>();
        Map<String, File> storageLocations = new HashMap<>(10);

        // Internal storage
        storages.add(new StorageType(Environment.getExternalStorageDirectory().getPath(), "Internal Storage", StorageType.INTERNAL_STORAGE));

        File internalStorage = Environment.getExternalStorageDirectory();
        storageLocations.put("Internal Storage",internalStorage);

        // SD Cards
        ArrayList<File> extStorages = new ArrayList<>();
        extStorages.addAll(Arrays.asList(context.getExternalFilesDirs(null)));
        extStorages.remove(0); // Remove internal storage
        String secondaryStoragePath = System.getenv("SECONDARY_STORAGE");
        for (int i = 0; i < extStorages.size(); i++) {
            String path = extStorages.get(i).getPath().split("/Android")[0];
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                if (Environment.isExternalStorageRemovable(extStorages.get(i)) || secondaryStoragePath != null && secondaryStoragePath.contains(path)) {
                    String name = "SD Card" + (i == 0 ? "" : " " + String.valueOf(i + 1));
                    storages.add(new StorageType(path, name, StorageType.SD_CARD));

                    File externalStorage = new File(path);
                    storageLocations.put(name,externalStorage);
                }
            }
        }

        // USB Drives
        ArrayList<String> drives = new ArrayList<>();
        String reg = "(?i).*vold.*(vfat|ntfs|exfat|fat32|ext3|ext4).*rw.*";
        String s = "";
        try {
            final Process process = new ProcessBuilder().command("mount")
                    .redirectErrorStream(true).start();
            process.waitFor();
            final InputStream is = process.getInputStream();
            final byte[] buffer = new byte[1024];
            while (is.read(buffer) != -1) {
                s += new String(buffer);
            }
            is.close();
        } catch (final Exception e) {
            e.printStackTrace();
        }
        final String[] lines = s.split("\n");
        for (String line : lines) {
            if (!line.toLowerCase(Locale.US).contains("asec") && line.matches(reg)) {
                String[] parts = line.split(" ");
                for (String path : parts) {
                    if (path.startsWith(File.separator) && !path.toLowerCase(Locale.US).contains("vold")) {
                        drives.add(path);
                    }
                }
            }
        }

        // Remove SD Cards from found drives (already found)
        ArrayList<String> ids = new ArrayList<>();
        for (StorageType st : storages) {
            String[] parts = st.path.split(File.separator);
//            String[] parts = st.getPath().split(File.separator);
            ids.add(parts[parts.length - 1]);
        }
        for (int i = drives.size() - 1; i >= 0; i--) {
            String[] parts = drives.get(i).split(File.separator);
            String id = parts[parts.length - 1];
            if (ids.contains(id)) drives.remove(i);
        }

        // Get USB Drive name
        UsbManager usbManager = (UsbManager) context.getSystemService(Context.USB_SERVICE);
        Collection<UsbDevice> dList = usbManager.getDeviceList().values();
        ArrayList<UsbDevice> deviceList = new ArrayList<>();
        deviceList.addAll(dList);
        for (int i = 0; i < deviceList.size(); i++) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                storages.add(new StorageType(drives.get(i), deviceList.get(i).getProductName(), StorageType.USB_DRIVE));

                File externalStorage = new File(drives.get(i));
                storageLocations.put(deviceList.get(i).getProductName(),externalStorage);
            }
        }

        return storages;
    }

    public static Map<String, File> getAllStorageLocations() {
        Map<String, File> storageLocations = new HashMap<>(10);
        File storage = Environment.getExternalStorageDirectory();
        storageLocations.put("Internal Storage", storage);
        storage = storage.getParentFile().getParentFile();
        int i = 1;
        Log.e("AllStorageLocations", "storage01:" + storage.getPath());
        Log.e("AllStorageLocations", "storage02:" + storage.getAbsolutePath());
        if (storage.listFiles() != null) {
            Log.e("AllStorageLocations", "listFiles:" + storage.listFiles().length);
            for (File media : storage.listFiles()) {
                if (!media.getName().equals("self") && !media.getName().equals("emulated")) {
                    storageLocations.put("External Storage " + i, media);
                    i++;
                }
            }
        }
        return storageLocations;
    }

    static String[] extensions = new String[]{"jpg", "png", "mp4", "mp3", "gif", "xlsx", "docx"};

    static boolean isValidFile(String ext) {
        for (String extension : extensions) {
            if (extension.equals(ext))
                return true;
        }
        return false;
    }

    void searchUtil(File dir, List<FileDirectory> resultList, String query) {
        if (dir.listFiles() != null) {
            for (File fileItem : dir.listFiles()) {


                String ext = MimeTypeMap.getFileExtensionFromUrl(fileItem.getName().replace(" ", ""));
                //Log.e(TAG,"Extension: "+ext);
                if (fileItem.isDirectory()) {
                    if (FileEx.containsIgnoreCase(fileItem.getName(), query))
                        searchResultList.add(new FileDirectory(fileItem.getName(), FileDirectory.FILE,
                                getAbsoluteFileSize(fileItem.getAbsolutePath()), simpleDateFormat.format(file.lastModified()),
                                fileItem.getAbsolutePath()));

                    searchUtil(fileItem, resultList, query);
                } else if (query.equals(DOC_SELECTOR) && !FileEx.containsIgnoreCase(ext, "jpg")
                        && (FileEx.containsIgnoreCase(ext, "pdf")
                        || FileEx.containsIgnoreCase(ext, "doc")
                        || FileEx.containsIgnoreCase(ext, "docx")
                        || FileEx.containsIgnoreCase(ext, "ppt")
                        || FileEx.containsIgnoreCase(ext, "pptx")
                        || FileEx.containsIgnoreCase(ext, "xls")
                        || FileEx.containsIgnoreCase(ext, "xlsx")
                        || FileEx.containsIgnoreCase(ext, "txt"))) {
                        //|| FileEx.containsIgnoreCase(ext, "htm")
                        //|| FileEx.containsIgnoreCase(ext, "db")

                    searchResultList.add(new FileDirectory(fileItem.getName(), FileDirectory.FILE,
                            getAbsoluteFileSize(fileItem.getAbsolutePath()), simpleDateFormat.format(file.lastModified()),
                            fileItem.getAbsolutePath()));

                } else if (FileEx.containsIgnoreCase(fileItem.getName(), query)) {

                    searchResultList.add(new FileDirectory(fileItem.getName(), FileDirectory.FILE,
                            getAbsoluteFileSize(fileItem.getAbsolutePath()), simpleDateFormat.format(file.lastModified()),
                            fileItem.getAbsolutePath()));
                }

            }
        }
    }

    void searchApk(File dir, List<FileDirectory> resultList, String query) {
        if (dir.listFiles() != null) {
            for (File fileItem : dir.listFiles()) {
                String ext = MimeTypeMap.getFileExtensionFromUrl(fileItem.getName().replace(" ", ""));
                //Log.e(TAG,"Extension: "+ext);
                if (fileItem.isDirectory()) {
                    if (FileEx.containsIgnoreCase(fileItem.getName(), query))
                        searchResultList.add(new FileDirectory(fileItem.getName(), FileDirectory.FILE,
                                getAbsoluteFileSize(fileItem.getAbsolutePath()), simpleDateFormat.format(file.lastModified()),
                                fileItem.getAbsolutePath()));

                    searchApk(fileItem, resultList, query);
                } else if (query.equals(DOC_SELECTOR) &&
                        (FileEx.containsIgnoreCase(ext, "apk"))) {

                    searchResultList.add(new FileDirectory(fileItem.getName(), FileDirectory.FILE,
                            getAbsoluteFileSize(fileItem.getAbsolutePath()), simpleDateFormat.format(file.lastModified()),
                            fileItem.getAbsolutePath()));
                } else if (FileEx.containsIgnoreCase(fileItem.getName(), query)) {

                    searchResultList.add(new FileDirectory(fileItem.getName(), FileDirectory.FILE,
                            getAbsoluteFileSize(fileItem.getAbsolutePath()), simpleDateFormat.format(file.lastModified()),
                            fileItem.getAbsolutePath()));
                }

            }
        }
    }

    void searchZip(File dir, List<FileDirectory> resultList, String query) {
        if (dir.listFiles() != null) {
            for (File fileItem : dir.listFiles()) {
                String ext = MimeTypeMap.getFileExtensionFromUrl(fileItem.getName().replace(" ", ""));
                //Log.e(TAG,"Extension: "+ext);
                if (fileItem.isDirectory()) {
                    if (FileEx.containsIgnoreCase(fileItem.getName(), query))
                        searchResultList.add(new FileDirectory(fileItem.getName(), FileDirectory.FILE,
                                getAbsoluteFileSize(fileItem.getAbsolutePath()), simpleDateFormat.format(file.lastModified()),
                                fileItem.getAbsolutePath()));

                    searchZip(fileItem, resultList, query);

				} else if (query.equals(DOC_SELECTOR)
						&& (FileEx.containsIgnoreCase(ext, "zip")
						|| FileEx.containsIgnoreCase(ext, "rar"))) {
                /*} else if (query.equals(DOC_SELECTOR) &&
                        (FileEx.containsIgnoreCase(ext, "zip")
                                || FileEx.containsIgnoreCase(ext, "rar"))) {*/

                    searchResultList.add(new FileDirectory(fileItem.getName(), FileDirectory.FILE,
                            getAbsoluteFileSize(fileItem.getAbsolutePath()), simpleDateFormat.format(file.lastModified()),
                            fileItem.getAbsolutePath()));

                } else if (FileEx.containsIgnoreCase(fileItem.getName(), query)) {

                    searchResultList.add(new FileDirectory(fileItem.getName(), FileDirectory.FILE,
                            getAbsoluteFileSize(fileItem.getAbsolutePath()), simpleDateFormat.format(file.lastModified()),
                            fileItem.getAbsolutePath()));
                }

            }
        }
    }

    // Method to check for excluded dir.
    boolean isDirToExclude(String dir) {
        for (String directory : excludedDir) {
            if (directory.equalsIgnoreCase(dir))
                return true;
        }
        return false;
    }

    private void searchUtilDate(File dir, List<FileDirectory> resultList, Date date) {
        try {
            if (dir.listFiles() != null) {
                for (File fileItem : dir.listFiles()) {
                    if (fileItem.isDirectory() && fileItem.getName().length() < 15
                            && !isDirToExclude(fileItem.getName())) {
                        searchUtilDate(fileItem, resultList, date);
                    } else {
                        Date tmp = simpleDateFormat.parse(simpleDateFormat.format(fileItem.lastModified()));
                        String name = fileItem.getName();
                        String ext = MimeTypeMap.getFileExtensionFromUrl(name);

                        if (date.compareTo(tmp) <= 0 && isValidFile(ext)) {
                            searchResultList.add(new FileDirectory(fileItem.getName(), FileDirectory.FILE,
                                    getAbsoluteFileSize(fileItem.getAbsolutePath()),
                                    simpleDateFormat.format(fileItem.lastModified()),
                                    fileItem.getAbsolutePath()));
                        }
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void delete(String completePath) {
        try {
            File f = new File(completePath);
            File[] files = f.listFiles();
            if (files != null) {
                for (File file : files) {
                    delete(file.toString());
                }
            }
            f.delete();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static boolean containsIgnoreCase(String src, String what) {
        final int length = what.length();
        if (length == 0)
            return true; // Empty string is contained

        final char firstLo = Character.toLowerCase(what.charAt(0));
        final char firstUp = Character.toUpperCase(what.charAt(0));

        for (int i = src.length() - length; i >= 0; i--) {
            // Quick check before calling the more expensive regionMatches() method:
            final char ch = src.charAt(i);
            if (ch != firstLo && ch != firstUp)
                continue;

            if (src.regionMatches(true, i, what, 0, length))
                return true;
        }

        return false;
    }

    public Flowable<List<FileDirectory>> findwithDate(final String directory, final Date date) {
        return Flowable.create(new FlowableOnSubscribe<List<FileDirectory>>() {
            @Override
            public void subscribe(FlowableEmitter<List<FileDirectory>> e) {
                File file = new File(directory);
                searchResultList.clear();
                searchUtilDate(file, searchResultList, date);
                e.onNext(searchResultList);
                e.onComplete();
            }
        }, BackpressureStrategy.BUFFER);
    }

    /**
     * Method to search files for the given query
     *
     * @param directory directory to be searched.
     * @param query     text to be searched.
     * @return
     */

    public Flowable<List<FileDirectory>> find(final String directory, final String query) {

        return Flowable.create(new FlowableOnSubscribe<List<FileDirectory>>() {

            @Override
            public void subscribe(FlowableEmitter<List<FileDirectory>> e) {
                File file = new File(directory);
                searchResultList.clear();
                searchUtil(file, searchResultList, query);
                e.onNext(searchResultList);
                e.onComplete();
            }
        }, BackpressureStrategy.BUFFER);
    }

    public Flowable<List<FileDirectory>> findApk(final String directory, final String query) {

        return Flowable.create(new FlowableOnSubscribe<List<FileDirectory>>() {

            @Override
            public void subscribe(FlowableEmitter<List<FileDirectory>> e) {
                File file = new File(directory);
                searchResultList.clear();
                searchApk(file, searchResultList, query);
                e.onNext(searchResultList);
                e.onComplete();
            }
        }, BackpressureStrategy.BUFFER);
    }

    public Flowable<List<FileDirectory>> findArchive(final String directory, final String query) {

        return Flowable.create(new FlowableOnSubscribe<List<FileDirectory>>() {

            @Override
            public void subscribe(FlowableEmitter<List<FileDirectory>> e) {
                File file = new File(directory);
                searchResultList.clear();
                searchZip(file, searchResultList, query);
                e.onNext(searchResultList);
                e.onComplete();
            }
        }, BackpressureStrategy.BUFFER);
    }

    /**
     * Method to go up from current directory
     *
     * @return
     */

    public boolean goUp() {
        if (previousDir == null)
            return false;
        if (currentDir.equals(defaultDir))
            return false;
        currentDir = previousDir;

        try {
            tempDir = new File(previousDir).getParent();

        } catch (NullPointerException e) {
            Log.d(TAG, "You are already at root directory.");
            return false;
        }

        if (isExists(tempDir)) {
            previousDir = tempDir;
        } else
            previousDir = null;

        return true;
    }

    /**
     * Method to rename the file for given path.
     *
     * @param path    path of file to be renamed.
     * @param newName new name for file.
     * @return
     */

    public boolean renameTo(String path, String newName) {
        File parent = new File(path).getParentFile();
        File newFile = new File(parent.getAbsolutePath() + "/" + newName);
        return new File(path).renameTo(newFile);
    }

    /**
     * Method to get used space for the root directory set at object creation time
     *
     * @return
     */
    public String getUsedRootSpace() {
        double total, used, free;
        total = Double.parseDouble(getTotalRootSpace().split(" ")[0]);
        free = Double.parseDouble(getFreeRootSpace().split(" ")[0]);
        if (free > total) {
            free /= 1000;
        }
        return String.format(Locale.US, "%.2f", (total - free)) + " GB";
    }

    /**
     * Method get free space in Root directory set at object creation time
     *
     * @return
     */

    public String getFreeRootSpace() {
        try {
            file = new File(defaultDir);
            double size = 0;
            size = file.getFreeSpace();
            StringBuilder unit = new StringBuilder("");
            if (isExists(defaultDir)) {
                unit.append("B");
                if (size > 1024) {
                    size /= 1024;
                    unit.delete(0, unit.length());
                    unit.append("KB");
                }

                if (size > 1024) {
                    size /= 1024;
                    unit.delete(0, unit.length());
                    unit.append("MB");

                }

                if (size > 1024) {
                    size /= 1024;
                    unit.delete(0, unit.length());
                    unit.append("GB");

                }

            }

            return String.format("%.2f", size) + " " + unit;

        } catch (NullPointerException e) {
            return null;
        }
    }

    /**
     * Method get total space in Root directory set at object creation time
     *
     * @return String
     */
    public String getTotalRootSpace() {
        try {
            file = new File(defaultDir);
            double size = 0;
            size = file.getTotalSpace();
            StringBuilder unit = new StringBuilder("");
            if (isExists(defaultDir)) {
                unit.append("B");
                if (size > 1024) {
                    size /= 1024;
                    unit.delete(0, unit.length());
                    unit.append("KB");
                }

                if (size > 1024) {
                    size /= 1024;
                    unit.delete(0, unit.length());
                    unit.append("MB");

                }

                if (size > 1024) {
                    size /= 1024;
                    unit.delete(0, unit.length());
                    unit.append("GB");

                }

            }
            //Log.e("SIZE",""+size);
            return String.format("%.2f", size) + " " + unit;

        } catch (NullPointerException e) {
            return null;
        }
    }

    /**
     * Method to change root directory.
     *
     * @param dir
     * @return
     */
    public boolean changeRootDirectory(String dir) {
        if (!isExists(dir))
            return false;
        defaultDir = dir;
        currentDir = dir;
        return true;
    }

    /**
     * Method to set current directory
     *
     * @param dir
     * @return
     */

    public boolean setCurrentDir(String dir) {
        if (isExists(dir)) {
            currentDir = dir;

            try {
                previousDir = new File(dir).getParent();
            } catch (NullPointerException e) {
                Log.e(TAG, "There is no parent for current directory.");
                return false;
            }
            return true;
        }
        return false;
    }


    /**
     * Method to list all contents in current directory
     *
     * @return
     */
    public List<String> listFiles() {
        file = new File(currentDir);
        if (file.listFiles() != null) {
            files = file.listFiles();
            directoryPathMap.clear();
            filesPathMap.clear();
            completeList.clear();
            tempList.clear();
            try {
                for (int i = 0; i < files.length; i++) {
                    if(!files[i].getName().startsWith(".")) {
                        if (files[i].isDirectory()) {
                            directoryPathMap.put(files[i].getName(), files[i].getAbsolutePath());
                        } else {
                            filesPathMap.put(files[i].getName(), files[i].getAbsolutePath());
                        }
                    } else if(showHiddenFile) {
                        if (files[i].isDirectory()) {
                            directoryPathMap.put(files[i].getName(), files[i].getAbsolutePath());
                        } else {
                            filesPathMap.put(files[i].getName(), files[i].getAbsolutePath());
                        }
                    }
                }
            } catch (NullPointerException e) {
                return completeList;
            }

            for (String directory : directoryPathMap.keySet())
                completeList.add(directory);

            Collections.sort(completeList);

            for (String file : filesPathMap.keySet())
                tempList.add(file);

            Collections.sort(tempList);

            completeList.addAll(tempList);
        }

        return completeList;
    }

    /**
     * Method to check whether the given path exist or not
     *
     * @param dir
     * @return
     */

    public boolean isExists(String dir) {

        if (dir == null)
            return false;
        try {
            return new File(dir).exists();
        } catch (NullPointerException e) {
            return false;
        }

    }


    /**
     * Method to get Current directory
     *
     * @return
     */

    public String getCurrentDir() {
        return currentDir;
    }

    /**
     * Method to get complete path of given file name
     *
     * @param file
     * @return
     */

    public String getFilePath(String file) {

        try {

            return filesPathMap.get(file) != null
                    ? filesPathMap.get(file)
                    : directoryPathMap.get(file);
        } catch (Exception e) {
            return "File not found!!! ,check files in current diretory by listFiles()";
        }

    }

    /**
     * Method to open given dir
     *
     * @param dir
     * @return
     */
    public List<String> openDir(String dir) {
        if (isExists(currentDir + "/" + dir)) {
            previousDir = currentDir;
            currentDir = currentDir + "/" + dir;
            return listFiles();
        } else
            return null;
    }


    public boolean setShowHiddenFile(boolean showHiddenFile) {
        return this.showHiddenFile=showHiddenFile;
    }

    public boolean isShowHiddenFile() {
        return showHiddenFile;
    }

    /**
     * Method to check whether the given path is file or dir
     *
     * @param name
     * @return
     */
    public boolean isFile(String name) {
        if (new File(currentDir + "/" + name).isFile())
            return true;
        return false;
    }

    /**
     * Method that return openable intent according to the file type
     *
     * @param file
     * @return
     */

    public Intent getOpenableIntent(String file) {
        return getAbsoluteOpenableIntent(currentDir + "/" + file);
    }

    public Intent getAbsoluteOpenableIntent(String file) {
        if (isExists(file) && new File(file)
                .isFile()) {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            Uri uri = Uri.fromFile(new File(file));

            String type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(MimeTypeMap
                    .getFileExtensionFromUrl(uri.toString()));
            intent.setDataAndType(uri, type);
            if (intent.resolveActivity(context.getPackageManager()) == null)
                return null;
            return intent;
        } else {

            return null;
        }
    }

    /**
     * @param file
     * @return
     */
    public String getInfo(String file) {
        return getAbsoluteInfo(currentDir + "/" + file);
    }

    public String getAbsoluteInfo(String file) {
        if (isExists(file)) {

            return simpleDateFormat.format(new File(file)
                    .lastModified());
        }
        return null;
    }

    /**
     * @param file
     * @return
     */
    public String getFileSize(String file) {
        String completePath = currentDir + "/" + file;
        return getAbsoluteFileSize(completePath);
    }

    public String getAbsoluteFileSize(String file) {
        double size = 0;
        StringBuilder unit = new StringBuilder("");
        if (isExists(file)) {
            size = ((double) new File(file).length());
            unit.append("B");
            if (size > 1024) {
                size /= 1024;
                unit.delete(0, unit.length());
                unit.append("KB");
            }

            if (size > 1024) {
                size /= 1024;
                unit.delete(0, unit.length());
                unit.append("MB");

            }

            if (size > 1024) {
                size /= 1024;
                unit.delete(0, unit.length());
                unit.append("GB");

            }

        }
        return String.format("%.2f", size) + " " + unit;
    }

    public int createDirectory(String dir) {
        if (isFile(dir))
            return DIRECTORY_ERROR;
        try {
            file = new File(dir);
            if (!file.exists()) {
                file.mkdir();
                return DIRECTORY_CREATED;
            } else
                return DIRECTORY_ALREADY_EXISTS;
        } catch (Exception e) {
            return DIRECTORY_ERROR;
        }
    }

    /**
     * Method to search files in specified directory
     *
     * @param dir
     * @param text
     * @return
     */
    public List<String> find(File dir, String text) {
        if (!dir.isDirectory())
            return null;
        for (File temp : file.listFiles()) {
            if (file.isDirectory()) {
                find(temp, text);
            } else if (temp.getName().contains(text)) {
                fileList.add(temp.getName());
            }
        }
        return fileList;
    }

    private void fileUtility(final String sourcePath, final FileInputStream source, final FileOutputStream destination,
                             FlowableEmitter<Integer> e) throws IOException {

        DataInputStream fileInputStream = new DataInputStream
                (source);
        DataOutputStream fileOutputStream = new DataOutputStream
                (destination);
        byte[] buffer = new byte[2048];
        int i;
        long size = new File(sourcePath).length();
        size /= 1024;
        long total = 0;

        while ((i = fileInputStream.read(buffer)) != -1) {
            total += i / 1024;
            if (e != null)
                e.onNext((int) ((total / (double) size) * 100));
            fileOutputStream.write(buffer, 0, i);
            //Log.e(TAG,"Writing data");
        }

        fileInputStream.close();
        fileOutputStream.close();

    }


    public Flowable<Integer> copyOrMoveFile(final String source, final FileInputStream sourceStream,
                                            final FileOutputStream destinationStream, final int selection) {
        try {
            final File f = new File(source);
            return Flowable.create(new FlowableOnSubscribe<Integer>() {
                @Override
                public void subscribe(FlowableEmitter<Integer> e) throws Exception {

                    if (!f.isDirectory()) {
                        fileUtility(f.getAbsolutePath(), sourceStream, destinationStream, e);
                        if (selection == MOVE)
                            f.delete();

                        e.onComplete();
                    } else {
                        int n = f.listFiles().length, i = 0;
                        for (File file : f.listFiles()) {
                            fileUtility(file.getAbsolutePath(), sourceStream, destinationStream, e);
                            i++;
                            if (selection == MOVE)
                                file.delete();
                            e.onNext((int) ((float) i / n * 100));
                        }
                        e.onComplete();
                    }
                }
            }, BackpressureStrategy.BUFFER);
        } catch (Exception e) {
            Log.e(TAG, "Exception: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }


}
