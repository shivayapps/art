package com.explorefile.filemanager.ui.browse;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Environment;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;

import android.os.Handler;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.explorefile.filemanager.MyPreferenceManager;
import com.explorefile.filemanager.ads.AdsProviders.AdmobAdManager;
import com.explorefile.filemanager.ads.AdsProviders.FacebookAdsManager;
import com.explorefile.filemanager.ads.Events.AdEventListener;
import com.explorefile.filemanager.fileEx.FileEx;
import com.explorefile.filemanager.fileEx.StorageType;
import com.explorefile.filemanager.fileEx.model.FileDirectory;
import com.explorefile.filemanager.OnDataLoadListener;
import com.explorefile.filemanager.OnRecyclerItemClickListener;
import com.explorefile.filemanager.R;
import com.explorefile.filemanager.Util;
import com.explorefile.filemanager.adapter.QuickAccessAdapter;
import com.explorefile.filemanager.adapter.RecentFilesAdapter;
import com.explorefile.filemanager.adapter.StorageAdapter;
import com.explorefile.filemanager.model.Storage;

import com.explorefile.filemanager.ui.SettingActivity;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.material.snackbar.Snackbar;

import org.json.JSONException;
import org.json.JSONObject;
import org.reactivestreams.Subscriber;
import org.reactivestreams.Subscription;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.FlowableEmitter;
import io.reactivex.FlowableOnSubscribe;
import io.reactivex.FlowableSubscriber;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

import static com.facebook.ads.CacheFlag.ALL;

public class HomeActivity extends AppCompatActivity implements OnRecyclerItemClickListener {

    Intent intent;
    TextView recents;
    public static FileEx fileEx;
    public static Storage storage;
    RecyclerView storageDevices, quickAccess;

    List<Storage> storageList = new ArrayList<>();
    StorageAdapter storageAdapter;

    //Map<String,File> mountedDevices=null;
    ArrayList<Storage> mountedDevices = new ArrayList<>();
    double total, used;

    List<String> quickAccessList = new ArrayList<>();
    QuickAccessAdapter quickAccessAdapter;

    Map<String, List<FileDirectory>> recentItemsMap = new LinkedHashMap<>();
    ProgressBar recentsProgressBar;

    RecyclerView recentFilesView;
    List<FileDirectory> recentList = new ArrayList<>();
    LinearLayoutManager recentListLayoutManager;

    public static final String IMAGES = "Images";
    public static final String AUDIO = "Audio";
    public static final String VIDEO = "Videos";
    private SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss", Locale.US);
    public static final String DOCUMENTS = "Documents";
    public static final String APK = "Apk";
    public static final String ARCHIVE = "Archive";
    Subscription mediaSubscription, documentSubscription;
    RecentFilesAdapter recentFilesAdapter;
    Toolbar toolbar;
    public boolean showHiddenFile=false;
    SharedPreferences sharedPreferences;
    MyPreferenceManager myPreferenceManager;
    FrameLayout fl_adplaceholder;
    RequestQueue queue;

    //CollapsingToolbarLayout collapsingToolbarLayout;
    private static final String TAG = HomeActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        myPreferenceManager = MyPreferenceManager.getInstance();
        sharedPreferences = getSharedPreferences(Util.DIR_DATA, Context.MODE_PRIVATE);

        //collapsingToolbarLayout=findViewById(R.id.collapsing_toolbar);
        //collapsingToolbarLayout.setExpandedTitleGravity(Gravity.CENTER_VERTICAL|Gravity.CENTER_HORIZONTAL);
        //collapsingToolbarLayout.setTitle(getResources().getString(R.string.app_name));
        //collapsingToolbarLayout.setExpandedTitleMarginBottom(20);
        //collapsingToolbarLayout.setExpandedTitleMargin(20,20,0,20);
        //collapsingToolbarLayout.setExpandedTitleTextAppearance(R.style.ExpandedQuick);
        //collapsingToolbarLayout.setExpandedTitleTypeface(AppController.getTypeface());

        // checking permissions
        storageDevices = findViewById(R.id.storageRV);

        recents = findViewById(R.id.recents);
        recentFilesView = findViewById(R.id.recentList);
        recentListLayoutManager = new LinearLayoutManager(this);
        recentFilesView.setHasFixedSize(true);
        recentFilesView.setLayoutManager(recentListLayoutManager);
        recentsProgressBar = findViewById(R.id.progressBar);

        //storageDevices.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        storageDevices.setLayoutManager(new GridLayoutManager(this, 2));
        fileEx = FileEx.newFileManager(Environment.getExternalStorageDirectory().toString(), this);

        quickAccess = findViewById(R.id.quick);
        quickAccess.setLayoutManager(new GridLayoutManager(this, 3));

        //setRecentList();

        mountStorage();
        setQuickAccessList();


        //handleQuery(QuickAccess.DOCUMENTS);
        //handleQuery(QuickAccess.APK);
        //handleQuery(QuickAccess.ARCHIVE);
        //handleQuery(QuickAccess.MORE);
        //handleQuery(QuickAccess.AUDIO);
        //handleQuery(QuickAccess.IMAGES);
        //handleQuery(QuickAccess.VIDEO);
        //handleQuery(QuickAccess.DOWNLOAD);

        fl_adplaceholder=findViewById(R.id.fl_adplaceholder);
        setAdMobData();

        if (myPreferenceManager.getString(Util.LIVE_AD).equalsIgnoreCase("admob")) {
            setAppId(myPreferenceManager.getString(Util.G_APP_ID));
            showGNativeAd(fl_adplaceholder, myPreferenceManager.getString(Util.G_NATIVE_ID));
        } else {
            showFNativeAd(fl_adplaceholder, myPreferenceManager.getString(Util.F_NATIVE_ID));
        }

    }

    private void setAdMobData() {

        queue = Volley.newRequestQueue(this);
        StringRequest request = new StringRequest(Request.Method.GET, Util.AD_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //Log.e("setAdMobData","response:"+response);
                        //textView.setText(response.toString());
                        //Toast.makeText(MainActivity.this, response.toString(), Toast.LENGTH_LONG).show();
                        try {
                            JSONObject jsonObject=new JSONObject(response);
                            String liveAd=jsonObject.getString("live_ad");

                            myPreferenceManager.putString(Util.LIVE_AD,liveAd.trim());
                            //JSONArray jsonAdmob=jsonObject.getJSONArray("admob");
                            //JSONArray jsonFacebook=jsonObject.getJSONArray("facebook");

                            JSONObject jsonAdmob=jsonObject.getJSONObject("admob");
                            String g_AppId=jsonAdmob.getString("app_id");
                            String g_NativeId=jsonAdmob.getString("native_advance");
                            String g_InterstitialId=jsonAdmob.getString("interstitial");
                            String g_BannerId=jsonAdmob.getString("banner");
                            String g_AppOpen=jsonAdmob.getString("app_open");

                            Log.e("setAdMobData","g_AppId:"+g_AppId);
                            Log.e("setAdMobData","g_NativeId:"+g_NativeId);
                            Log.e("setAdMobData","g_InterstitialId:"+g_InterstitialId);
                            Log.e("setAdMobData","g_BannerId:"+g_BannerId);
                            Log.e("setAdMobData","g_AppOpen:"+g_AppOpen);

                            myPreferenceManager.putString(Util.G_APP_ID,g_AppId.trim());
                            myPreferenceManager.putString(Util.G_NATIVE_ID,g_NativeId.trim());
                            myPreferenceManager.putString(Util.G_INTERSTITIAL_ID,g_InterstitialId.trim());
                            myPreferenceManager.putString(Util.G_APPOPEN_ID,g_AppOpen.trim());
                            myPreferenceManager.putString(Util.G_BANNER_ID,g_BannerId.trim());


                            JSONObject jsonFacebook=jsonObject.getJSONObject("facebook");
                            String f_NativeId=jsonFacebook.getString("native_advance");
                            String f_InterstitialId=jsonFacebook.getString("interstitial");
                            String f_BannerId=jsonFacebook.getString("banner");
                            String f_NativeBannerId=jsonFacebook.getString("native_banner");

                            Log.e("setAdMobData","f_NativeId:"+f_NativeId);
                            Log.e("setAdMobData","f_InterstitialId:"+f_InterstitialId);
                            Log.e("setAdMobData","f_BannerId:"+f_BannerId);
                            Log.e("setAdMobData","f_NativeBannerId:"+f_NativeBannerId);

                            myPreferenceManager.putString(Util.F_NATIVE_ID,f_NativeId.trim());
                            myPreferenceManager.putString(Util.F_INTERSTITIAL_ID,f_InterstitialId.trim());
                            myPreferenceManager.putString(Util.F_NATIVE_ID,f_NativeBannerId.trim());
                            myPreferenceManager.putString(Util.F_BANNER_ID,f_BannerId.trim());


                            //preferenceManager.setITimeInterval("3");

                            if (myPreferenceManager.getString(Util.LIVE_AD).equalsIgnoreCase("admob")) {
                                setAppId(g_AppId);
                            }
                        } catch (JSONException e) {
                            Log.e("setAdMobData","JSONException:"+e);
                            e.printStackTrace();
                        }


                        if (myPreferenceManager.getString(Util.LIVE_AD).equalsIgnoreCase("admob")) {
                            showGNativeAd(fl_adplaceholder, myPreferenceManager.getString(Util.G_NATIVE_ID));
                        } else {
                            showFNativeAd(fl_adplaceholder, myPreferenceManager.getString(Util.F_NATIVE_ID));
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("setAdMobData","onErrorResponse:"+error.networkResponse.statusCode);
                        Log.e("setAdMobData","onErrorResponse:"+error.getMessage());

                    }
                });
        queue.add(request);
    }

    private void setAppId(String appId) {
        try {
            ApplicationInfo ai = getPackageManager().getApplicationInfo(getPackageName(), PackageManager.GET_META_DATA);
            Bundle bundle = ai.metaData;
            String myApiKey = bundle.getString("com.google.android.gms.ads.APPLICATION_ID");
            Log.d(TAG, "Name Found: " + myApiKey);
            ai.metaData.putString("com.google.android.gms.ads.APPLICATION_ID", appId);//you can replace your key APPLICATION_ID here
            String ApiKey = bundle.getString("com.google.android.gms.ads.APPLICATION_ID");
            Log.d(TAG, "ReNamed Found: " + ApiKey);
        } catch (PackageManager.NameNotFoundException e) {
            Log.e(TAG, "Failed to load meta-data, NameNotFound: " + e.getMessage());
        } catch (NullPointerException e) {
            Log.e(TAG, "Failed to load meta-data, NullPointer: " + e.getMessage());
        }
    }

    boolean doubleBackToExitPressedOnce = false;
    @Override
    public void onBackPressed() {
        if(!sharedPreferences.getBoolean("rating_shown",false)) {
            showRateDialog(true);
        } else {

            if (doubleBackToExitPressedOnce) {
                super.onBackPressed();
                return;
            }

            doubleBackToExitPressedOnce = true;
            Toast.makeText(this, "Press BACK again to exit", Toast.LENGTH_SHORT).show();

            new Handler().postDelayed(new Runnable() {

                @Override
                public void run() {
                    doubleBackToExitPressedOnce = false;
                }
            }, 2000);
            //super.onBackPressed();
        }
    }

    boolean bug=true;
    String feedback="";
    private void showRateDialog(final boolean isFinish) {
        final View dialogView = View.inflate(HomeActivity.this, R.layout.dialog_say_thanks, null);
        final AlertDialog.Builder mAlertDialog = new AlertDialog.Builder(HomeActivity.this)
                .setView(dialogView)
                .setCancelable(true);

        final AlertDialog mAlertDialog1 = mAlertDialog.create();
        mAlertDialog1.setCancelable(true);
        mAlertDialog1.setCanceledOnTouchOutside(true);
        mAlertDialog1.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        TextView buttonPositive = (TextView) dialogView.findViewById(R.id.btn_rate_now);
        TextView buttonNegative = (TextView) dialogView.findViewById(R.id.btn_later);
        final RatingBar rating_bar = (RatingBar) dialogView.findViewById(R.id.rating_bar);
        final LinearLayout lay_feedback = (LinearLayout) dialogView.findViewById(R.id.lay_feedback);
        final EditText txtfeedback = (EditText) dialogView.findViewById(R.id.txtfeedback);

        rating_bar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                if(rating<=3) {
                    bug=true;
                    lay_feedback.setVisibility(View.VISIBLE);
                } else {
                    bug=false;
                    lay_feedback.setVisibility(View.GONE);
                }
            }
        });

        buttonPositive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(bug) {
                    feedback=txtfeedback.getText().toString().trim();
                    Util.reportBug(HomeActivity.this,"Feedback/Suggestion",feedback,rating_bar.getRating());
                    mAlertDialog1.dismiss();
                } else {
                    if (rating_bar.getRating() >= 1 && rating_bar.getRating() < 4) {
                        bug=true;
                        lay_feedback.setVisibility(View.VISIBLE);
                        txtfeedback.requestFocus();
                        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                        imm.showSoftInput(txtfeedback, InputMethodManager.SHOW_IMPLICIT);
                    } else if (rating_bar.getRating() >= 4 && rating_bar.getRating() <= 5) {
                        bug=false;
                        sharedPreferences.edit().putBoolean("rating_shown",true).apply();
                        Util.rateOnPlayStore(HomeActivity.this);
                        mAlertDialog1.dismiss();
                    } else if (rating_bar.getRating() == 0.0f) {
                        Snackbar.make(dialogView, "Select stars.", Snackbar.LENGTH_SHORT).show();
                    } else {
                        bug=false;
                        sharedPreferences.edit().putBoolean("rating_shown",true).apply();
                        Util.rateOnPlayStore(HomeActivity.this);
                        mAlertDialog1.dismiss();
                    }
                }
            }
        });
        buttonNegative.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isFinish){
                    Intent startMain = new Intent(Intent.ACTION_MAIN);
                    startMain.addCategory(Intent.CATEGORY_HOME);
                    startMain.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(startMain);
                    finish();
                }
                mAlertDialog1.dismiss();
            }
        });
        mAlertDialog1.show();


    }

    private void showFNativeAd(final FrameLayout frameNativeAdContainer, String adId) {
        Log.e("showNativeAd", "showNativeAd: OK");
        FacebookAdsManager facebookAdsManager = new FacebookAdsManager(this);
        facebookAdsManager.loadNativeAd(this, adId, frameNativeAdContainer, false, new AdEventListener() {
            @Override
            public void onAdLoaded() {
                Log.e("showNativeAd", "onAdLoaded");
                frameNativeAdContainer.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdClosed() {
                Log.e("showNativeAd", "onAdClosed");

            }

            @Override
            public void onLoadError(String errorCode) {
                Log.e("showNativeAd", "onLoadError: " + errorCode);
                frameNativeAdContainer.setVisibility(View.GONE);
                if (myPreferenceManager.getString(Util.LIVE_AD).equalsIgnoreCase("facebook")) {
                    showGNativeAd(frameNativeAdContainer,myPreferenceManager.getString(Util.G_NATIVE_ID));
                }
            }
        });
    }

    private void showGNativeAd(final FrameLayout frameNativeAdContainer, String adId) {
        Log.e("showNativeAd", "showNativeAd: OK");
        AdmobAdManager admobAdManager = new AdmobAdManager(this);
        admobAdManager.loadNativeAd(this, adId, frameNativeAdContainer, false, new AdEventListener() {
            @Override
            public void onAdLoaded() {
                Log.e("showNativeAd", "onAdLoaded");
                frameNativeAdContainer.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdClosed() {
                Log.e("showNativeAd", "onAdClosed");

            }

            @Override
            public void onLoadError(String errorCode) {
                Log.e("showNativeAd", "onLoadError: " + errorCode);
                frameNativeAdContainer.setVisibility(View.GONE);

                if (myPreferenceManager.getString(Util.LIVE_AD).equalsIgnoreCase("admob")) {
                    showFNativeAd(frameNativeAdContainer,myPreferenceManager.getString(Util.F_NATIVE_ID));
                }
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_home, menu);

        // Get the SearchView and set the searchable configuration
        SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        SearchView searchView = (SearchView) menu.findItem(R.id.search).getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                Toast.makeText(getApplicationContext(), "" + query, Toast.LENGTH_SHORT).show();
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });
        searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
        searchView.setIconifiedByDefault(false);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_settings:
                Util.click_count++;
                if(Util.click_count%4==0) {
                    Util.click_count=1;
                    startActivityForResult(new Intent(HomeActivity.this, SettingActivity.class),555);
                } else {
                    //showInterstitialAd(new Intent(HomeActivity.this, SettingActivity.class));
                    Intent intent=new Intent(HomeActivity.this, SettingActivity.class);

                    if (myPreferenceManager.getString(Util.LIVE_AD).equalsIgnoreCase("admob")) {
                        showGInterstitialAd(myPreferenceManager.getString(Util.G_INTERSTITIAL_ID),intent);
                    } else {
                        showFInterstitialAd(myPreferenceManager.getString(Util.F_INTERSTITIAL_ID),intent);
                    }
                }
                break;
            case R.id.action_http:
                Util.click_count++;
                if(Util.click_count%4==0) {
                    Util.click_count=1;
                    startActivityForResult(new Intent(HomeActivity.this, HttpActivity.class),555);
                } else {
                    //showInterstitialAd(new Intent(HomeActivity.this, HttpActivity.class));
                    Intent intent=new Intent(HomeActivity.this, HttpActivity.class);

                    if (myPreferenceManager.getString(Util.LIVE_AD).equalsIgnoreCase("admob")) {
                        showGInterstitialAd(myPreferenceManager.getString(Util.G_INTERSTITIAL_ID),intent);
                    } else {
                        showFInterstitialAd(myPreferenceManager.getString(Util.F_INTERSTITIAL_ID),intent);
                    }
                }
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    public void setRecentList() {
        try {
            Calendar calendar = Calendar.getInstance();
            calendar.add(Calendar.DAY_OF_MONTH, -7);
            // Log.d(TAG,simpleDateFormat.format(calendar.getTime())+"");
            fileEx.findwithDate(Environment.getExternalStorageDirectory().toString(), simpleDateFormat.parse(simpleDateFormat
                    .format(calendar.getTime())))
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribeOn(Schedulers.io())
                    .subscribe(new Subscriber<List<FileDirectory>>() {
                        @Override
                        public void onSubscribe(Subscription s) {
                            s.request(Long.MAX_VALUE);
                        }

                        @Override
                        public void onNext(List<FileDirectory> fileDirectoryList) {
                            recentList = fileDirectoryList;

                            Log.e(TAG, "name: " + recentList.size());
                        }

                        @Override
                        public void onError(Throwable t) {
                            Log.e(TAG, t.getMessage());
                        }

                        @Override
                        public void onComplete() {
                            setOrRefreshRecentItems(recentList);
                        }
                    });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void setOrRefreshRecentItems(List<FileDirectory> recentItemList) {
        Util.getRecentlyAddedFiles(recentItemList)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new FlowableSubscriber<Map<String, List<FileDirectory>>>() {
                    @Override
                    public void onSubscribe(Subscription s) {
                        s.request(Long.MAX_VALUE);
                    }

                    @Override
                    public void onNext(Map<String, List<FileDirectory>> fileDirectoryMap) {
                        recentItemsMap = fileDirectoryMap;
                    }

                    @Override
                    public void onError(Throwable t) {
                        Log.e(TAG, "Recent List Error: " + t.getMessage());
                    }

                    @Override
                    public void onComplete() {
                        List<String> keyList = Util.getRecentItemKeys();
                        recentFilesAdapter = new RecentFilesAdapter(HomeActivity.this, recentItemsMap, keyList, Glide.with(HomeActivity.this));
                        setRecentItemListener();
                        recentFilesAdapter.setOnDataLoadListener(new OnDataLoadListener() {
                            @Override
                            public void onDataLoaded(boolean loaded) {
                                if (recentsProgressBar.getVisibility() == View.VISIBLE)
                                    recentsProgressBar.setVisibility(View.GONE);
                            }
                        });
                        recentFilesView.setAdapter(recentFilesAdapter);
                    }
                });
    }

    void setRecentItemListener() {
        recentFilesAdapter.setOnRecyclerItemClickListener(new OnRecyclerItemClickListener() {
            @Override
            public void onClick(View view, int position) {
                Intent i = fileEx.getAbsoluteOpenableIntent(recentFilesAdapter.getTotalList()
                        .get(position).getPath());
                startActivity(i);
            }

            @Override
            public void onLongClick(View view, int position) {

                AlertDialog.Builder menuDialog = new AlertDialog.Builder(HomeActivity.this);

                View v = LayoutInflater.from(HomeActivity.this).inflate(R.layout.options_layout, null);
                menuDialog.setView(v);
                menuDialog.setCancelable(true);


                final Dialog dialog = menuDialog.create();
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

                TextView open = v.findViewById(R.id.open);
                TextView share = v.findViewById(R.id.share);
                TextView delete = v.findViewById(R.id.delete);

                open.setOnClickListener(view1 -> {
                    String parent_dir = new File(recentFilesAdapter.getTotalList().get(position).getPath()).getParent();
                    Intent i = new Intent(HomeActivity.this, BrowseActivity.class);
                    //  Log.e(TAG,"parent dir: "+parent_dir);
                    i.putExtra(getResources().getString(R.string.dir_reference), parent_dir);
                    dialog.dismiss();
                    startActivity(i);
                    //menuDialog.dismiss();
                });

                share.setOnClickListener(view1 -> {
                    String path = recentFilesAdapter.getTotalList().get(position).getPath();

                    ArrayList<Uri> uris = new ArrayList<>(1);
                    uris.add(Uri.fromFile(new File(path)));

                    final Intent intent = new Intent(Intent.ACTION_SEND_MULTIPLE);
                    intent.setType("*/*");
                    intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
                    dialog.dismiss();
                    startActivity(Intent.createChooser(intent, "Send"));

                });
                dialog.show();
            }
        });
    }

    void setQuickAccessList() {
        quickAccessList.add(IMAGES);
        quickAccessList.add(AUDIO);
        quickAccessList.add(VIDEO);
        quickAccessList.add(DOCUMENTS);
        quickAccessList.add(APK);
        quickAccessList.add(ARCHIVE);

        int[] backgroundColor = getResources().getIntArray(R.array.colorArrayMain);

        quickAccessAdapter = new QuickAccessAdapter(quickAccessList,backgroundColor);
        quickAccess.setAdapter(quickAccessAdapter);

        Intent i = new Intent(this, QuickAccessActivity.class);
        quickAccessAdapter.setOnRecyclerItemClickListener(new OnRecyclerItemClickListener() {
            @Override
            public void onClick(View view, int position) {
                Util.click_count++;
                int selection = 0;
                switch (quickAccessList.get(position)) {
                    case IMAGES:
                        selection = QuickAccessActivity.IMAGES;
                        //fileList=imageList;
                        break;
                    case AUDIO:
                        selection = QuickAccessActivity.AUDIO;
                        //fileList=audioList;
                        break;
                    case VIDEO:
                        selection = QuickAccessActivity.VIDEO;
                        //fileList=videoList;
                        break;
                    case DOCUMENTS:
                        selection = QuickAccessActivity.DOCUMENTS;
                        //fileList=documentList;
                        break;
                    case APK:
                        selection = QuickAccessActivity.APK;
                        //fileList=apkList;
                        break;
                    case ARCHIVE:
                        selection = QuickAccessActivity.ARCHIVE;
                        //fileList=archiveList;
                        break;
                    default:
                        selection = QuickAccessActivity.IMAGES;
                        //fileList=imageList;
                        break;
                }

                i.putExtra("select_data", selection);
                if(Util.click_count%4==0) {
                    Util.click_count=1;
                    //showInterstitialAd(i);
                    if (myPreferenceManager.getString(Util.LIVE_AD).equalsIgnoreCase("admob")) {
                        showGInterstitialAd(MyPreferenceManager.getInstance().getString(Util.G_INTERSTITIAL_ID),i);
                    } else {
                        showFInterstitialAd(MyPreferenceManager.getInstance().getString(Util.F_INTERSTITIAL_ID),i);
                    }
                } else {
                    startActivity(i);
                }
            }

            @Override
            public void onLongClick(View view, int position) {

            }
        });

    }


    private void showFInterstitialAd(String adId,Intent intent) {
        final FacebookAdsManager facebookAdsManager = new FacebookAdsManager(this);
        if (facebookAdsManager.getInterstitialAd() != null) {
            facebookAdsManager.showProgress();

            facebookAdsManager.loadInterstitialAd(HomeActivity.this, adId, new AdEventListener() {

                @Override
                public void onAdLoaded() {
                    if (facebookAdsManager.getInterstitialAd().isAdLoaded()) {
                        MyPreferenceManager.getInstance().setShowedInterstitialTime();
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                facebookAdsManager.dismissProgress();
                                facebookAdsManager.getInterstitialAd().show();
                            }
                        }, 1000);
                        facebookAdsManager.dismissProgress();
                    }
                }

                @Override
                public void onAdClosed() {

                    facebookAdsManager.dismissProgress();
                    if(intent!=null) {
                        startActivity(intent);
                    }

                }

                @Override
                public void onLoadError(String errorCode) {
                    Log.e("AdsManager", "loadInterstitialAd:001");
                    facebookAdsManager.dismissProgress();
                    facebookAdsManager.loadInterstitialAd(HomeActivity.this,adId);
                    if (MyPreferenceManager.getInstance().getString(Util.LIVE_AD).equalsIgnoreCase("facebook")) {
                        showGInterstitialAd(MyPreferenceManager.getInstance().getString(Util.G_INTERSTITIAL_ID),intent);
                    } else {
                        if(intent!=null) {
                            startActivity(intent);
                        }
                    }
                }
            });

        } else {
            Log.e("AdsManager", "loadInterstitialAd:002");
            facebookAdsManager.dismissProgress();
            facebookAdsManager.loadInterstitialAd(HomeActivity.this, adId);
            if (MyPreferenceManager.getInstance().getString(Util.LIVE_AD).equalsIgnoreCase("facebook")) {
                showGInterstitialAd(MyPreferenceManager.getInstance().getString(Util.G_INTERSTITIAL_ID),intent);
            } else {
                if(intent!=null) {
                    startActivity(intent);
                }
            }
        }
    }

    private void showGInterstitialAd(String adId,Intent intent) {
        Log.e("AdsManager", "showInterstitialAd");
        try {

            AdmobAdManager admobAdManager = new AdmobAdManager(HomeActivity.this);
            if (admobAdManager.getInterstitialAd() != null) {
                if (admobAdManager.getInterstitialAd().isLoaded()) {

                    admobAdManager.showProgress();
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            MyPreferenceManager.getInstance().setShowedInterstitialTime();
                            admobAdManager.dismissProgress();
                            admobAdManager.getInterstitialAd().show();
                        }
                    }, 1000);

                    admobAdManager.getInterstitialAd().setAdListener(new AdListener() {
                        @Override
                        public void onAdClosed() {
                            super.onAdClosed();
                            admobAdManager.dismissProgress();
                            admobAdManager.loadInterstitialAd(HomeActivity.this,adId);

                            if(intent!=null) {
                                startActivity(intent);
                            }


                        }

                        @Override
                        public void onAdFailedToLoad(LoadAdError loadAdError) {
                            super.onAdFailedToLoad(loadAdError);
                            Log.e("AdsManager", "LoadAdError:"+loadAdError.getMessage());
                            admobAdManager.dismissProgress();
                            //start();
                            if (MyPreferenceManager.getInstance().getString(Util.LIVE_AD).equalsIgnoreCase("admob")) {
                                showFInterstitialAd(MyPreferenceManager.getInstance().getString(Util.F_INTERSTITIAL_ID),intent);
                            } else {
                                if(intent!=null) {
                                    startActivity(intent);
                                }
                            }
                        }
                    });

                } else {

                    Log.e("AdsManager", "loadInterstitialAd:001");
                    admobAdManager.dismissProgress();
                    admobAdManager.loadInterstitialAd(HomeActivity.this,adId);
                    //start();
                    if (MyPreferenceManager.getInstance().getString(Util.LIVE_AD).equalsIgnoreCase("admob")) {
                        showFInterstitialAd(MyPreferenceManager.getInstance().getString(Util.F_INTERSTITIAL_ID),intent);
                    } else {
                        if(intent!=null) {
                            startActivity(intent);
                        }
                    }
                }

            } else {
                Log.e("AdsManager", "loadInterstitialAd:002");
                admobAdManager.dismissProgress();
                admobAdManager.loadInterstitialAd(HomeActivity.this,adId);
                //start();
                if (MyPreferenceManager.getInstance().getString(Util.LIVE_AD).equalsIgnoreCase("admob")) {
                    showFInterstitialAd(MyPreferenceManager.getInstance().getString(Util.F_INTERSTITIAL_ID),intent);
                } else {
                    if(intent!=null) {
                        startActivity(intent);
                    }
                }
            }
        } catch (Exception e) {
            Log.e("InterstitialAdException", "showNativeAd: " + e.toString());
            e.printStackTrace();
            //start();
            if (MyPreferenceManager.getInstance().getString(Util.LIVE_AD).equalsIgnoreCase("admob")) {
                showFInterstitialAd(MyPreferenceManager.getInstance().getString(Util.F_INTERSTITIAL_ID),intent);
            } else {
                if(intent!=null) {
                    startActivity(intent);
                }
            }
        }
    }

    List<FileDirectory> imageList = new ArrayList<>();
    List<FileDirectory> audioList = new ArrayList<>();
    List<FileDirectory> videoList = new ArrayList<>();
    List<FileDirectory> documentList = new ArrayList<>();
    List<FileDirectory> apkList = new ArrayList<>();
    List<FileDirectory> archiveList = new ArrayList<>();

    public static List<FileDirectory> fileList = new ArrayList<>();

    private void handleQuery(int selectData) {

        Log.e(TAG, "selectData: " + selectData);

        if (selectData == QuickAccessActivity.DOCUMENTS) {
            loadDocuments();
        } else if (selectData == QuickAccessActivity.APK) {
            loadApk();
        } else if (selectData == QuickAccessActivity.ARCHIVE) {
            loadArchive();
        } else {
            loadMedia(selectData)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(new Subscriber<List<FileDirectory>>() {
                        @Override
                        public void onSubscribe(Subscription s) {
                            mediaSubscription = s;
                            s.request(Long.MAX_VALUE);
                        }
                        @Override
                        public void onNext(List<FileDirectory> fileDirectoryList) { }
                        @Override
                        public void onError(Throwable t) {
                            Log.e(TAG, "onError: " + t.getMessage());
                        }

                        @Override
                        public void onComplete() {
                            /*if(fileList.size()!=0) {
                                fileList = Util.sortBy(fileList, Util.NAME,Util.ASC);
                            }*/
                        }
                    });
        }

    }

    Flowable<List<FileDirectory>> loadMedia(final int select) {
        return Flowable.create(new FlowableOnSubscribe<List<FileDirectory>>() {
            @Override
            public void subscribe(FlowableEmitter<List<FileDirectory>> e) {

                if (select == QuickAccessActivity.AUDIO) {
                    audioList = getAllMediaPath(HomeActivity.this, e, QuickAccessActivity.AUDIO);
                } else if (select == QuickAccessActivity.IMAGES) {
                    imageList = getAllMediaPath(HomeActivity.this, e, QuickAccessActivity.IMAGES);
                } else if (select == QuickAccessActivity.VIDEO) {
                    videoList = getAllMediaPath(HomeActivity.this, e, QuickAccessActivity.VIDEO);
                } /*else if (select == QuickAccess.DOCUMENTS) {
                    documentList = getAllMediaPath(Home.this, e, QuickAccess.DOCUMENTS);
                } else if (select == QuickAccess.APK) {
                    apkList = getAllMediaPath(Home.this, e, QuickAccess.APK);
                } else if (select == QuickAccess.ARCHIVE) {
                    archiveList = getAllMediaPath(Home.this, e, QuickAccess.ARCHIVE);
                } else if (select == QuickAccess.MORE) {
                    moreList = getAllMediaPath(Home.this, e, QuickAccess.MORE);
                }*/
                //doc apk archiv more
                e.onComplete();
            }

        }, BackpressureStrategy.BUFFER);
    }

    void loadDocuments() {
        fileEx.find(Environment.getExternalStorageDirectory().toString(), FileEx.DOC_SELECTOR)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<List<FileDirectory>>() {

                    @Override
                    public void onSubscribe(Subscription s) {
                        documentSubscription = s;
                        s.request(Long.MAX_VALUE);
                    }

                    @Override
                    public void onNext(List<FileDirectory> fileDirectories) {
                        documentList = fileDirectories;
                        //Toast.makeText(getApplicationContext(),"search list size: "+fileDirectories.size(),Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onError(Throwable t) {
                        Log.e("QuickAccess", "Error message01: " + t.getMessage());
                    }

                    @Override
                    public void onComplete() {
                        if (documentList.size() != 0) {
                            documentList = Util.sortBy(documentList, Util.NAME, Util.ASC);
                        }
                        //mediaAdapter = new MediaAdapter(fileList, QuickAccess.this, QuickAccess.DOCUMENTS, Glide.with(QuickAccess.this));
                        //mediaAdapter.setOnItemSelectedListener(QuickAccess.this);
                        //mediaAdapter.setOnRecyclerItemClickListener(QuickAccess.this);
                        //mediaRV.setAdapter(mediaAdapter);
                        //progressBar.setVisibility(View.GONE);
                        //sort.setVisibility(View.VISIBLE);
                    }
                });
    }

    void loadApk() {
        fileEx.findApk(Environment.getExternalStorageDirectory().toString(), FileEx.DOC_SELECTOR)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<List<FileDirectory>>() {

                    @Override
                    public void onSubscribe(Subscription s) {
                        documentSubscription = s;
                        s.request(Long.MAX_VALUE);
                    }

                    @Override
                    public void onNext(List<FileDirectory> fileDirectories) {
                        apkList = fileDirectories;
                        //Toast.makeText(getApplicationContext(),"search list size: "+fileDirectories.size(),Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onError(Throwable t) {
                        Log.e("QuickAccess", "Error message02: " + t.getMessage());
                    }

                    @Override
                    public void onComplete() {
                        if (apkList.size() != 0) {
                            apkList = Util.sortBy(apkList, Util.NAME, Util.ASC);
                        }
                        //mediaAdapter = new MediaAdapter(fileList, QuickAccess.this, QuickAccess.DOCUMENTS, Glide.with(QuickAccess.this));
                        //mediaAdapter.setOnItemSelectedListener(QuickAccess.this);
                        //mediaAdapter.setOnRecyclerItemClickListener(QuickAccess.this);
                        //mediaRV.setAdapter(mediaAdapter);
                        //progressBar.setVisibility(View.GONE);
                        //sort.setVisibility(View.VISIBLE);
                    }
                });
    }

    void loadArchive() {
        fileEx.findArchive(Environment.getExternalStorageDirectory().toString(), FileEx.DOC_SELECTOR)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<List<FileDirectory>>() {

                    @Override
                    public void onSubscribe(Subscription s) {
                        documentSubscription = s;
                        s.request(Long.MAX_VALUE);
                    }

                    @Override
                    public void onNext(List<FileDirectory> fileDirectories) {
                        archiveList = fileDirectories;
                        //Toast.makeText(getApplicationContext(),"search list size: "+fileDirectories.size(),Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onError(Throwable t) {
                        Log.e("QuickAccess", "Error message03: " + t.getMessage());
                    }

                    @Override
                    public void onComplete() {
                        if (archiveList.size() != 0) {
                            archiveList = Util.sortBy(archiveList, Util.NAME, Util.ASC);
                        }
                        //mediaAdapter = new MediaAdapter(fileList, QuickAccess.this, QuickAccess.DOCUMENTS, Glide.with(QuickAccess.this));
                        //mediaAdapter.setOnItemSelectedListener(QuickAccess.this);
                        //mediaAdapter.setOnRecyclerItemClickListener(QuickAccess.this);
                        //mediaRV.setAdapter(mediaAdapter);
                        //progressBar.setVisibility(View.GONE);
                        //sort.setVisibility(View.VISIBLE);
                    }
                });
    }

    private List<FileDirectory> getAllMediaPath(Activity activity, FlowableEmitter<List<FileDirectory>> e, int selection) {
        Uri uri = null;
        Cursor cursor;
        int column_index_data, column_index_folder_name;
        List<FileDirectory> list = new ArrayList<>();
        String absolutePathOfImage, fileName;
        String[] projection = {};
        if (selection == QuickAccessActivity.AUDIO) {
            uri = android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
            projection = new String[]{MediaStore.MediaColumns.DATA,
                    MediaStore.Audio.Media.DISPLAY_NAME};
            Log.e("Test", "Audio");
        } else if (selection == QuickAccessActivity.IMAGES) {
            uri = android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
            projection = new String[]{MediaStore.MediaColumns.DATA,
                    MediaStore.Images.Media.BUCKET_DISPLAY_NAME};
            Log.e("Test", "Images");
        } else if (selection == QuickAccessActivity.VIDEO) {
            uri = android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
            projection = new String[]{MediaStore.Video.VideoColumns.DATA,
                    MediaStore.Video.Media.DISPLAY_NAME};
            Log.e("Test", "Video");
        }

        cursor = activity.getContentResolver().query(uri, projection, null,
                null, null);

        column_index_data = cursor.getColumnIndexOrThrow(projection[0]);
        column_index_folder_name = cursor.getColumnIndexOrThrow(projection[1]);
        cursor.moveToFirst();

        do {
            absolutePathOfImage = cursor.getString(column_index_data);
            fileName = cursor.getString(column_index_folder_name);
            if (!new File(absolutePathOfImage).exists())
                continue;
            list.add(new FileDirectory(fileName, FileDirectory.FILE,
                    fileEx.getAbsoluteFileSize(absolutePathOfImage),
                    fileEx.getAbsoluteInfo(absolutePathOfImage), absolutePathOfImage));

            e.onNext(list);
        } while (cursor.moveToNext());

        if (list.size() != 0) {
            list = Util.sortBy(list, Util.NAME, Util.ASC);
        }
        return list;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }


    void mountStorage() {
        //mountedDevices=com.explorefile.filemanager.fileEx.Storage.getStorages(Home.this);
        ArrayList<StorageType> device = new ArrayList<>();
        device = FileEx.getStorages(HomeActivity.this);

        for (StorageType storageType : device) {

            fileEx.changeRootDirectory(storageType.path);
            total = Double.parseDouble(fileEx.getTotalRootSpace().split(" ")[0]);
            used = Double.parseDouble(fileEx.getUsedRootSpace().split(" ")[0]);
            storageList.add(new Storage(storageType.name,
                    fileEx.getTotalRootSpace(),
                    fileEx.getFreeRootSpace(),
                    fileEx.getUsedRootSpace(),
                    getPercentage(total, used),
                    storageType.path));
        }

        /*
        Iterator iterator=mountedDevices.keySet().iterator();
        String key="";
        while(iterator.hasNext()){
            key=""+iterator.next();
            fileEx.changeRootDirectory(mountedDevices.get(key).getAbsolutePath());
            total=Double.parseDouble(fileEx.getTotalRootSpace().split(" ")[0]);
            used=Double.parseDouble(fileEx.getUsedRootSpace().split(" ")[0]);

            storageList.add(new Storage(key,
                    fileEx.getTotalRootSpace(),
                    fileEx.getFreeRootSpace(),
                    fileEx.getUsedRootSpace(),
                    getPercentage(total,used),
                    mountedDevices.get(key).getAbsolutePath()));
        }
        */

        int[] progressColor = getResources().getIntArray(R.array.colorArray1);
        int[] backgroundColor = getResources().getIntArray(R.array.colorArray2);

        storageAdapter = new StorageAdapter(storageList, this, progressColor, backgroundColor);
        storageDevices.setAdapter(storageAdapter);
    }

    @Override
    protected void onStart() {
        super.onStart();
        storageList.clear();
        mountStorage();

    }

    @Override
    protected void onResume() {
        super.onResume();

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                showHiddenFile=sharedPreferences.getBoolean(Util.SHOW_HIDDEN,false);
                if(fileEx!=null) fileEx.setShowHiddenFile(showHiddenFile);

            }
        },1000);

        storageList.clear();
        mountStorage();

    }

    public int getPercentage(double total, double used) {
        return (int) ((used / total) * 100);
    }


    @Override
    public void onClick(View view, int position) {
        intent = new Intent(this, BrowseActivity.class);
        storage = storageList.get(position);
        fileEx.changeRootDirectory(storageList.get(position).getPath());
        fileEx.setCurrentDir(storageList.get(position).getPath());
        intent.putExtra(getResources().getString(R.string.dir_reference), storageList.get(position).getPath());
        startActivity(intent);
    }

    @Override
    public void onLongClick(View view, int position) {

    }
}
