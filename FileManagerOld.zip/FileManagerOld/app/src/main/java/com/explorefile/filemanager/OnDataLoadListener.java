package com.explorefile.filemanager;


public interface OnDataLoadListener {
    void onDataLoaded(boolean loaded);
}
