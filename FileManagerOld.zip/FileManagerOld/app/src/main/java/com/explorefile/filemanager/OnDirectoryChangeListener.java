package com.explorefile.filemanager;

import java.util.List;

public interface OnDirectoryChangeListener {
    public void onDirectoryChange(List<?> newList);
}
