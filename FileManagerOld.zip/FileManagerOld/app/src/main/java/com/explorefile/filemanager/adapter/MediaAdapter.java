package com.explorefile.filemanager.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.GenericTransitionOptions;
import com.bumptech.glide.RequestManager;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.explorefile.filemanager.fileEx.model.FileDirectory;
import com.explorefile.filemanager.AppController;
import com.explorefile.filemanager.OnItemSelectedListener;
import com.explorefile.filemanager.OnRecyclerItemClickListener;
import com.explorefile.filemanager.R;
import com.explorefile.filemanager.Util;
import com.explorefile.filemanager.adapter.viewHolder.MediaViewHolder;
import com.explorefile.filemanager.ui.browse.QuickAccessActivity;

import org.reactivestreams.Subscription;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import io.reactivex.FlowableSubscriber;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

public class MediaAdapter extends RecyclerView.Adapter<MediaViewHolder> {

    List<FileDirectory> fileDirectoryList = new ArrayList<>();
    Context context;
    OnRecyclerItemClickListener onRecyclerItemClickListener;
    static final String TAG = MediaAdapter.class.getSimpleName();
    int type = 0;
    int selectedColor = Color.parseColor("#73007DD6");
    Subscription subscription;
    private RequestManager glide;
    int laytype = 1;
    GridLayoutManager gridLayoutManager;
    private final float SELECTED_ROTATION = 45;
    OnItemSelectedListener onItemSelectedListener;
    List<FileDirectory> selectedList = new ArrayList<>();

    public MediaAdapter(List<FileDirectory> fileDirectoryList, Context context, int type, RequestManager glide,GridLayoutManager gridLayoutManager) {
        this.fileDirectoryList = fileDirectoryList;
        this.context = context;
        this.type = type;
        this.glide = glide;
        this.gridLayoutManager = gridLayoutManager;
    }

    public void refreshData() {
        notifyDataSetChanged();
    }

    public void setFileDirectoryList(List<FileDirectory> fileDirectoryList) {
        this.fileDirectoryList = fileDirectoryList;
        notifyDataSetChanged();
    }

    public void setOnItemSelectedListener(OnItemSelectedListener onItemSelectedListener) {
        this.onItemSelectedListener = onItemSelectedListener;
    }

    @Override
    public int getItemViewType(int position) {
        int spanCount = gridLayoutManager.getSpanCount();
        laytype=spanCount;
        return spanCount;
    }
    @Override
    public MediaViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.media_view, parent, false);
        View v;
        if(laytype==1) v = LayoutInflater.from(parent.getContext()).inflate(R.layout.media_view_list,parent,false);
        else  v = LayoutInflater.from(parent.getContext()).inflate(R.layout.media_view_grid,parent,false);
        MediaViewHolder mediaViewHolder = new MediaViewHolder(v);
        return mediaViewHolder;
    }

    public void setOnRecyclerItemClickListener(OnRecyclerItemClickListener onRecyclerItemClickListener) {
        this.onRecyclerItemClickListener = onRecyclerItemClickListener;
    }

    public void disableSelection() {
        //isSelectable=false;
        selectedList.clear();
        onItemSelectedListener.onItemListChanged(selectedList);
        notifyDataSetChanged();
    }

    @Override
    public void onBindViewHolder(MediaViewHolder holder, int position) {
        if (onRecyclerItemClickListener != null) {
            holder.constraintLayout.setOnClickListener(view -> {
                int color = Color.TRANSPARENT;
                Drawable background = view.getBackground();
                if (background instanceof ColorDrawable)
                    color = ((ColorDrawable) background).getColor();

                if (color == selectedColor) {
                    //holder.constraintLayout.setRotation(0);
                    holder.constraintLayout.setBackgroundColor(Color.WHITE);
                    selectedList.remove(fileDirectoryList.get(position));
                    onItemSelectedListener.onItemListChanged(selectedList);
                    if(type== QuickAccessActivity.IMAGES) {
                        if (holder.bg_view.getVisibility() == View.VISIBLE) {;
                            holder.bg_view.setVisibility(View.GONE);
                        }
                    }
                } else if (selectedList.size() > 0) {
                    selectedList.add(fileDirectoryList.get(position));
                    //holder.constraintLayout.setRotation(SELECTED_ROTATION);
                    holder.constraintLayout.setBackgroundColor(selectedColor);
                    onItemSelectedListener.onItemListChanged(selectedList);
                    if(type== QuickAccessActivity.IMAGES) {
                        holder.bg_view.setVisibility(View.VISIBLE);
                    }
                } else
                    onRecyclerItemClickListener.onClick(view, position);

                /*if(holder.constraintLayout.getRotation()==SELECTED_ROTATION){
                    holder.constraintLayout.setRotation(0);
                    selectedList.remove(fileDirectoryList.get(position));
                    onItemSelectedListener.onItemListChanged(selectedList);
                }
                else if(selectedList.size()>0){
                    selectedList.add(fileDirectoryList.get(position));
                    holder.constraintLayout.setRotation(SELECTED_ROTATION);
                    onItemSelectedListener.onItemListChanged(selectedList);
                }
                else
                    onRecyclerItemClickListener.onClick(view,position);*/
            });
        }


        if (selectedList.size() > 0 && selectedList.contains(fileDirectoryList.get(position))) {
            //isSelectable=true;
            //holder.constraintLayout.setRotation(SELECTED_ROTATION);
            holder.constraintLayout.setBackgroundColor(selectedColor);


        } else {
            //isSelectable=false;
            //holder.constraintLayout.setRotation(0);
            holder.constraintLayout.setBackgroundColor(Color.WHITE);
        }

        holder.constraintLayout.setOnLongClickListener(view -> {
            if (!selectedList.contains(fileDirectoryList.get(position))) {
                //isSelectable=true;
                selectedList.add(fileDirectoryList.get(position));
                //holder.constraintLayout.setRotation(SELECTED_ROTATION);
                holder.constraintLayout.setBackgroundColor(selectedColor);
                onItemSelectedListener.onItemListChanged(selectedList);

            } else {
                onItemSelectedListener.onItemListChanged(selectedList);
            }
            return true;
        });


        int width = (int) context.getResources().getDimension(R.dimen.media_view_width);
        int height = (int) context.getResources().getDimension(R.dimen.media_view_width);

        if(laytype==1) {
            height = (int) context.getResources().getDimension(R.dimen.icon_size);
            width = (int) context.getResources().getDimension(R.dimen.icon_size);
        }
        else {
            height = (int) context.getResources().getDimension(R.dimen.media_view_width);
            width = (int) ViewGroup.LayoutParams.MATCH_PARENT;
        }

        try {
            //RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(width, height);
            //params.setMargins(10, 10, 10, 10);
            //params.addRule(Gravity.CENTER_HORIZONTAL);

            //RelativeLayout.LayoutParams nameParams = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            //nameParams.setMargins(6, 6, 6, 6);
            //nameParams.addRule(Gravity.CENTER_HORIZONTAL);

            /*
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(width, height);
            params.setMargins(10,10,10,10);
            params.gravity= Gravity.CENTER_VERTICAL|Gravity.CENTER_HORIZONTAL;

            LinearLayout.LayoutParams nameParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            nameParams.setMargins(6,6,6,6);
            nameParams.gravity=Gravity.CENTER_HORIZONTAL;*/

            Log.e("getApkIcon","type:"+type);
            switch (type) {
                case QuickAccessActivity.IMAGES:

                    glide.load(new File(fileDirectoryList.get(position).getPath()))
                            .apply(AppController.getRequestOptions())
                            .diskCacheStrategy(DiskCacheStrategy.ALL)
                            .transition(GenericTransitionOptions.with(R.anim.item_fall_down))
                            .into(holder.thumbnail);
                    holder.name.setVisibility(View.GONE);
                    holder.info.setVisibility(View.GONE);
                    holder.size.setVisibility(View.GONE);
                    //holder.info.setText(fileDirectoryList.get(position).getDate());
                    //holder.size.setText(fileDirectoryList.get(position).getSize());

                    break;

                case QuickAccessActivity.AUDIO:
                    holder.thumbnail.setImageResource(Util.getImageResIdFromExension(fileDirectoryList.get(position).getName()));
                    holder.name.setText(Util.getTrimmed(fileDirectoryList.get(position).getName()));
                    //holder.name.setTextSize(15);
                    //holder.thumbnail.setLayoutParams(params);
                    //if (!isImageSet(holder.thumbnail, R.drawable.file))
                    loadThumbnail(holder, position, Util.MUSIC_ART);
                    break;

                case QuickAccessActivity.VIDEO:
                    holder.name.setText(Util.getTrimmed(fileDirectoryList.get(position).getName()));
                    //holder.name.setTextSize(15);
                    //holder.thumbnail.setLayoutParams(params);
                    //if (!isImageSet(holder.thumbnail, R.drawable.file))
                    loadThumbnail(holder, position, Util.VIDEO_ART);
                    break;

                case QuickAccessActivity.DOCUMENTS:
                    holder.thumbnail.setImageResource(Util.getImageResIdFromExension(fileDirectoryList.get(position).getName()));
                    //holder.name.setTextSize(15);
                    holder.name.setText(Util.getTrimmed(fileDirectoryList.get(position).getName()));
                    //holder.thumbnail.setLayoutParams(params);
                    holder.info.setText(fileDirectoryList.get(position).getDate());
                    holder.size.setText(fileDirectoryList.get(position).getSize());

                    if(fileDirectoryList.get(position).getName().endsWith(".apk")){
                        Bitmap bitmap=Util.getApkIcon(context,fileDirectoryList.get(position).getPath());
                        holder.thumbnail.setImageBitmap(bitmap);
                    }
                    break;
                case QuickAccessActivity.APK:
                    holder.thumbnail.setImageResource(Util.getImageResIdFromExension(fileDirectoryList.get(position).getName()));
                    //holder.name.setTextSize(15);
                    holder.name.setText(Util.getTrimmed(fileDirectoryList.get(position).getName()));
                    holder.info.setText(fileDirectoryList.get(position).getDate());
                    holder.size.setText(fileDirectoryList.get(position).getSize());
                    //holder.thumbnail.setLayoutParams(params);
                    //loadThumbnail(holder, position, Util.APK_ART);

                    if(fileDirectoryList.get(position).getName().endsWith(".apk")){
                        Bitmap bitmap=Util.getApkIcon(context,fileDirectoryList.get(position).getPath());
                        holder.thumbnail.setImageBitmap(bitmap);
                    }
                    break;
                case QuickAccessActivity.ARCHIVE:
                    holder.thumbnail.setImageResource(Util.getImageResIdFromExension(fileDirectoryList.get(position).getName()));
                    //holder.name.setTextSize(15);
                    holder.name.setText(Util.getTrimmed(fileDirectoryList.get(position).getName()));
                    holder.info.setText(fileDirectoryList.get(position).getDate());
                    holder.size.setText(fileDirectoryList.get(position).getSize());
                    //holder.thumbnail.setLayoutParams(params);
                    break;
            }
            holder.name.setSelected(true);
        } catch (Exception e) {
            Log.e(TAG, "glide error: " + e.getMessage());
            //e.printStackTrace();

        }
    }


    boolean isImageSet(ImageView imageView, int resId) {
        Drawable.ConstantState current = imageView.getDrawable().getConstantState();
        Drawable.ConstantState toCheck;
        if (Build.VERSION.SDK_INT >= 21)
            toCheck = context.getResources().getDrawable(resId, null).getConstantState();
        else
            toCheck = context.getResources().getDrawable(resId).getConstantState();

        if (current == toCheck)
            return false;
        return true;
    }

    void loadThumbnail(MediaViewHolder holder, int position, int selection) {

        Util.loadAlbumArt(fileDirectoryList.get(position).getPath(), selection)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new FlowableSubscriber<Bitmap>() {
                    @Override
                    public void onSubscribe(Subscription s) {
                        subscription = s;
                        s.request(Long.MAX_VALUE);
                    }

                    @Override
                    public void onNext(Bitmap bitmap) {
                        if (bitmap != null) {
                            if (selection == Util.VIDEO_ART) {
                                glide.load(bitmap)
                                        .apply(AppController.getRequestOptions())
                                        .diskCacheStrategy(DiskCacheStrategy.ALL)
                                        .into(holder.thumbnail);
                            } else if (selection == Util.MUSIC_ART) {
                                glide.load(bitmap)
                                        .apply(AppController.getCircleRequestOptions())
                                        .diskCacheStrategy(DiskCacheStrategy.ALL)
                                        .into(holder.thumbnail);
                            }/*else if (selection == Util.APK_ART) {
                                glide.load(bitmap)
                                        .apply(AppController.getCircleRequestOptions())
                                        .diskCacheStrategy(DiskCacheStrategy.ALL)
                                        .into(holder.thumbnail);
                            }*/
                        } else {
                            if (selection == Util.VIDEO_ART) {
                                glide.load(R.drawable.ic_video)
                                        .apply(AppController.getRequestOptions())
                                        .diskCacheStrategy(DiskCacheStrategy.ALL)
                                        .into(holder.thumbnail);
                            } else if (selection == Util.MUSIC_ART) {
                                glide.load(R.drawable.ic_music)
                                        .apply(AppController.getCircleRequestOptions())
                                        .diskCacheStrategy(DiskCacheStrategy.ALL)
                                        .into(holder.thumbnail);
                            } /*else if (selection == Util.APK_ART) {
                                glide.load(R.drawable.ic_apk)
                                        .apply(AppController.getCircleRequestOptions())
                                        .diskCacheStrategy(DiskCacheStrategy.ALL)
                                        .into(holder.thumbnail);
                            }*/
                        }
                    }

                    @Override
                    public void onError(Throwable t) {
                        Log.e(TAG, "Error: " + t.getMessage());
                    }

                    @Override
                    public void onComplete() {

                    }
                });
    }

    @Override
    public int getItemCount() {
        return fileDirectoryList.size();
    }
}
