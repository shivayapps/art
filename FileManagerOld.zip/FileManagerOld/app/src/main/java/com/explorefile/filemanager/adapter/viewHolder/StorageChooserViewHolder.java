package com.explorefile.filemanager.adapter.viewHolder;

import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.explorefile.filemanager.R;


public class StorageChooserViewHolder extends RecyclerView.ViewHolder {

    public ImageView icon;
    public TextView title,path;
    public RelativeLayout constraintLayout;

    public StorageChooserViewHolder(View v){
        super(v);
        icon=v.findViewById(R.id.icon);
        title=v.findViewById(R.id.title);
        path=v.findViewById(R.id.path);
        constraintLayout=(RelativeLayout) v;
    }

}
