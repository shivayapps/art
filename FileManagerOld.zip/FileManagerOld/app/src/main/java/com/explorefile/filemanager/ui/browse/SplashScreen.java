package com.explorefile.filemanager.ui.browse;

import android.Manifest;
import android.animation.Animator;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.util.Log;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;


import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.explorefile.filemanager.MyPreferenceManager;
import com.explorefile.filemanager.R;
import com.explorefile.filemanager.Util;
import com.explorefile.filemanager.ads.AdsProviders.AdmobAdManager;
import com.explorefile.filemanager.ads.AdsProviders.FacebookAdsManager;
import com.explorefile.filemanager.ads.Events.AdEventListener;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAdListener;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.LoadAdError;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Arrays;

public class SplashScreen extends AppCompatActivity {

    SharedPreferences sharedPreferences;
    ImageView logo;
    TextView textView;
    ShortcutManager shortcutManager;
    MyPreferenceManager myPreferenceManager;
    RequestQueue queue;
    private static final String TAG = SplashScreen.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        setAdMobData();
        myPreferenceManager = MyPreferenceManager.getInstance();
        if (myPreferenceManager.getString(Util.LIVE_AD).equalsIgnoreCase("admob")) {
            AdmobAdManager admobAdManager = new AdmobAdManager(this);
            admobAdManager.loadInterstitialAd(this,myPreferenceManager.getString(Util.G_INTERSTITIAL_ID));
        } else {
            FacebookAdsManager facebookAdsManager = new FacebookAdsManager(this);
            facebookAdsManager.loadInterstitialAd(this,myPreferenceManager.getString(Util.F_INTERSTITIAL_ID));
        }

        setAppShortcuts();
        logo=findViewById(R.id.logo);
        textView=findViewById(R.id.text);

        sharedPreferences=getSharedPreferences(Util.DIR_DATA, Context.MODE_PRIVATE);
        logo.setAlpha(0.0f);
        textView.setAlpha(0.0f);
        logo.animate().alpha(1.0f).setDuration(1000);

        textView.animate().alpha(1.0f).setDuration(2000).setListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animator) { }

            @Override
            public void onAnimationEnd(Animator animator) {
                if(checkPermissions()) {
                    navigateToMain();
                } else {
                    requestPermission(READ_WRITE);
                }
            }
            @Override
            public void onAnimationCancel(Animator animator) { }

            @Override
            public void onAnimationRepeat(Animator animator) { }
        });
    }


    private void setAdMobData() {

        queue = Volley.newRequestQueue(this);
        StringRequest request = new StringRequest(Request.Method.GET, Util.AD_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //Log.e("setAdMobData","response:"+response);
                        //textView.setText(response.toString());
                        //Toast.makeText(MainActivity.this, response.toString(), Toast.LENGTH_LONG).show();
                        try {
                            JSONObject jsonObject=new JSONObject(response);
                            String liveAd=jsonObject.getString("live_ad");

                            myPreferenceManager.putString(Util.LIVE_AD,liveAd.trim());
                            //JSONArray jsonAdmob=jsonObject.getJSONArray("admob");
                            //JSONArray jsonFacebook=jsonObject.getJSONArray("facebook");

                            JSONObject jsonAdmob=jsonObject.getJSONObject("admob");
                            String g_AppId=jsonAdmob.getString("app_id");
                            String g_NativeId=jsonAdmob.getString("native_advance");
                            String g_InterstitialId=jsonAdmob.getString("interstitial");
                            String g_BannerId=jsonAdmob.getString("banner");
                            String g_AppOpen=jsonAdmob.getString("app_open");

                            Log.e("setAdMobData","g_AppId:"+g_AppId);
                            Log.e("setAdMobData","g_NativeId:"+g_NativeId);
                            Log.e("setAdMobData","g_InterstitialId:"+g_InterstitialId);
                            Log.e("setAdMobData","g_BannerId:"+g_BannerId);
                            Log.e("setAdMobData","g_AppOpen:"+g_AppOpen);

                            myPreferenceManager.putString(Util.G_APP_ID,g_AppId.trim());
                            myPreferenceManager.putString(Util.G_NATIVE_ID,g_NativeId.trim());
                            myPreferenceManager.putString(Util.G_INTERSTITIAL_ID,g_InterstitialId.trim());
                            myPreferenceManager.putString(Util.G_APPOPEN_ID,g_AppOpen.trim());
                            myPreferenceManager.putString(Util.G_BANNER_ID,g_BannerId.trim());

                            JSONObject jsonFacebook=jsonObject.getJSONObject("facebook");
                            String f_NativeId=jsonFacebook.getString("native_advance");
                            String f_InterstitialId=jsonFacebook.getString("interstitial");
                            String f_BannerId=jsonFacebook.getString("banner");
                            String f_NativeBannerId=jsonFacebook.getString("native_banner");

                            Log.e("setAdMobData","f_NativeId:"+f_NativeId);
                            Log.e("setAdMobData","f_InterstitialId:"+f_InterstitialId);
                            Log.e("setAdMobData","f_BannerId:"+f_BannerId);
                            Log.e("setAdMobData","f_NativeBannerId:"+f_NativeBannerId);

                            myPreferenceManager.putString(Util.F_NATIVE_ID,f_NativeId.trim());
                            myPreferenceManager.putString(Util.F_INTERSTITIAL_ID,f_InterstitialId.trim());
                            myPreferenceManager.putString(Util.F_NATIVE_ID,f_NativeBannerId.trim());
                            myPreferenceManager.putString(Util.F_BANNER_ID,f_BannerId.trim());

                            //preferenceManager.setITimeInterval("3");

                            if (myPreferenceManager.getString(Util.LIVE_AD).equalsIgnoreCase("admob")) {
                                setAppId(g_AppId);
                            }
                        } catch (JSONException e) {
                            Log.e("setAdMobData","JSONException:"+e);
                            e.printStackTrace();
                        }

                        if (myPreferenceManager.getString(Util.LIVE_AD).equalsIgnoreCase("admob")) {
                            AdmobAdManager admobAdManager = new AdmobAdManager(SplashScreen.this);
                            admobAdManager.loadInterstitialAd(SplashScreen.this,myPreferenceManager.getString(Util.G_INTERSTITIAL_ID));
                        } else {
                            FacebookAdsManager facebookAdsManager = new FacebookAdsManager(SplashScreen.this);
                            facebookAdsManager.loadInterstitialAd(SplashScreen.this,myPreferenceManager.getString(Util.F_INTERSTITIAL_ID));
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("setAdMobData","onErrorResponse:"+error.networkResponse.statusCode);
                        Log.e("setAdMobData","onErrorResponse:"+error.getMessage());

                    }
                });
        queue.add(request);
    }

    private void setAppId(String appId) {
        try {
            ApplicationInfo ai = getPackageManager().getApplicationInfo(getPackageName(), PackageManager.GET_META_DATA);
            Bundle bundle = ai.metaData;
            String myApiKey = bundle.getString("com.google.android.gms.ads.APPLICATION_ID");
            Log.d(TAG, "Name Found: " + myApiKey);
            ai.metaData.putString("com.google.android.gms.ads.APPLICATION_ID", appId);//you can replace your key APPLICATION_ID here
            String ApiKey = bundle.getString("com.google.android.gms.ads.APPLICATION_ID");
            Log.d(TAG, "ReNamed Found: " + ApiKey);
        } catch (PackageManager.NameNotFoundException e) {
            Log.e(TAG, "Failed to load meta-data, NameNotFound: " + e.getMessage());
        } catch (NullPointerException e) {
            Log.e(TAG, "Failed to load meta-data, NullPointer: " + e.getMessage());
        }
    }

    /*
    @Override
    protected void onResume() {
        super.onResume();
        if(checkPermissions()) {
            navigateToMain();
        } else {
            requestPermission(READ_WRITE);
        }
    }
    */

    public void navigateToMain() {

        if (Util.check_internet(SplashScreen.this)) {
            Intent intent=new Intent(SplashScreen.this, HomeActivity.class);
            if (myPreferenceManager.getString(Util.LIVE_AD).equalsIgnoreCase("admob")) {
                showGInterstitialAd(MyPreferenceManager.getInstance().getString(Util.G_INTERSTITIAL_ID),intent);
            } else {
                showFInterstitialAd(MyPreferenceManager.getInstance().getString(Util.F_INTERSTITIAL_ID),intent);
            }
        } else {
            Intent i=new Intent(SplashScreen.this, HomeActivity.class);
            startActivity(i);
            finish();
        }
    }

    static final int READ_WRITE = 22;
    public boolean checkPermissions() {
        boolean allow=true;
        if (Build.VERSION.SDK_INT < 23)
            allow=true;
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            allow = false;
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            allow = false;
        }
        return allow;
        /*if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {

            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    || ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.READ_EXTERNAL_STORAGE)) {
                allow=false
            } else {
                ActivityCompat.requestPermissions(this
                        , new String[] {
                                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                                Manifest.permission.READ_EXTERNAL_STORAGE},
                        READ_WRITE);

            }

        }*/
    }

    public void requestPermission(int reqcode) {

        ActivityCompat.requestPermissions(this
                , new String[] {
                        Manifest.permission.WRITE_EXTERNAL_STORAGE,
                        Manifest.permission.READ_EXTERNAL_STORAGE},
                reqcode);
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.e("onResume","onResume");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.e("onActivityResult","requestCode:"+requestCode);
        Log.e("onActivityResult","resultCode:"+resultCode);
        if(requestCode==555) {

            if(checkPermissions()) {
                navigateToMain();
            } else {
                requestPermission(READ_WRITE);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)){
            Log.e("denied", Manifest.permission.WRITE_EXTERNAL_STORAGE);
            requestPermission(READ_WRITE);
        } else {
            if(ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                    || ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED ){

                Log.e("allowed", "EXTERNAL_STORAGE");
                navigateToMain();
            } else {

                new AlertDialog.Builder(this)
                        .setCancelable(false).setTitle("Permission required")
                        .setMessage("Please grant necessary permission to continue")
                        .setPositiveButton("Ok", (dialogInterface, i) -> {
                            gotoSetting(SplashScreen.this);
                        })
                        .setNegativeButton("Exit", ((dialogInterface, i) -> {
                            finish();
                        })
                ).show();

                Log.e("set to never ask again", "EXTERNAL_STORAGE");
            }
        }

        /*if(grantResults.length>0) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                if(requestCode==READ_WRITE) {
                    navigateToMain();
                }
            }
        }*/
    }

    private void gotoSetting(Activity activity) {
        Intent i = new Intent();
        i.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        //i.addCategory(Intent.CATEGORY_DEFAULT);
        i.setData(Uri.parse("package:" + activity.getPackageName()));
        //i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        //i.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
        //i.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
        activity.startActivityForResult(i,555);
    }


    private void showFInterstitialAd(String adId,Intent intent) {
        final FacebookAdsManager facebookAdsManager = new FacebookAdsManager(this);
        if (facebookAdsManager.getInterstitialAd() != null) {
            facebookAdsManager.showProgress();
            facebookAdsManager.loadInterstitialAd(SplashScreen.this, adId, new AdEventListener() {

                @Override
                public void onAdLoaded() {
                    if (facebookAdsManager.getInterstitialAd().isAdLoaded()) {
                        MyPreferenceManager.getInstance().setShowedInterstitialTime();
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                facebookAdsManager.dismissProgress();
                                facebookAdsManager.getInterstitialAd().show();
                            }
                        }, 1000);
                        facebookAdsManager.dismissProgress();
                    }
                }

                @Override
                public void onAdClosed() {

                    facebookAdsManager.dismissProgress();
                    if(intent!=null) {
                        startActivity(intent);
                        finish();
                    }

                }

                @Override
                public void onLoadError(String errorCode) {
                    Log.e("AdsManager", "loadInterstitialAd:001");
                    facebookAdsManager.dismissProgress();
                    facebookAdsManager.loadInterstitialAd(SplashScreen.this,adId);
                    if (MyPreferenceManager.getInstance().getString(Util.LIVE_AD).equalsIgnoreCase("facebook")) {
                        showGInterstitialAd(MyPreferenceManager.getInstance().getString(Util.G_INTERSTITIAL_ID),intent);
                    } else {
                        if(intent!=null) {
                            startActivity(intent);
                            finish();
                        }
                    }
                }
            });

        } else {
            Log.e("AdsManager", "loadInterstitialAd:002");
            facebookAdsManager.dismissProgress();
            facebookAdsManager.loadInterstitialAd(SplashScreen.this, adId);
            if (MyPreferenceManager.getInstance().getString(Util.LIVE_AD).equalsIgnoreCase("facebook")) {
                showGInterstitialAd(MyPreferenceManager.getInstance().getString(Util.G_INTERSTITIAL_ID),intent);
            } else {
                if(intent!=null) {
                    startActivity(intent);
                    finish();
                }
            }
        }
    }

    private void showGInterstitialAd(String adId,Intent intent) {
        Log.e("AdsManager", "showInterstitialAd");
        try {

            AdmobAdManager admobAdManager = new AdmobAdManager(SplashScreen.this);
            if (admobAdManager.getInterstitialAd() != null) {
                if (admobAdManager.getInterstitialAd().isLoaded()) {

                    admobAdManager.showProgress();
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            MyPreferenceManager.getInstance().setShowedInterstitialTime();
                            admobAdManager.dismissProgress();
                            admobAdManager.getInterstitialAd().show();
                        }
                    }, 1000);

                    admobAdManager.getInterstitialAd().setAdListener(new AdListener() {
                        @Override
                        public void onAdClosed() {
                            super.onAdClosed();
                            admobAdManager.dismissProgress();
                            admobAdManager.loadInterstitialAd(SplashScreen.this,adId);

                            if(intent!=null) {
                                startActivity(intent);
                                finish();
                            }


                        }

                        @Override
                        public void onAdFailedToLoad(LoadAdError loadAdError) {
                            super.onAdFailedToLoad(loadAdError);
                            Log.e("AdsManager", "LoadAdError:"+loadAdError.getMessage());
                            admobAdManager.dismissProgress();
                            //start();
                            if (MyPreferenceManager.getInstance().getString(Util.LIVE_AD).equalsIgnoreCase("admob")) {
                                showFInterstitialAd(MyPreferenceManager.getInstance().getString(Util.F_INTERSTITIAL_ID),intent);
                            } else {
                                if(intent!=null) {
                                    startActivity(intent);
                                    finish();
                                }
                            }
                        }
                    });

                } else {

                    Log.e("AdsManager", "loadInterstitialAd:001");
                    admobAdManager.dismissProgress();
                    admobAdManager.loadInterstitialAd(SplashScreen.this,adId);
                    //start();
                    if (MyPreferenceManager.getInstance().getString(Util.LIVE_AD).equalsIgnoreCase("admob")) {
                        showFInterstitialAd(MyPreferenceManager.getInstance().getString(Util.F_INTERSTITIAL_ID),intent);
                    } else {
                        if(intent!=null) {
                            startActivity(intent);
                            finish();
                        }
                    }
                }

            } else {
                Log.e("AdsManager", "loadInterstitialAd:002");
                admobAdManager.dismissProgress();
                admobAdManager.loadInterstitialAd(SplashScreen.this,adId);
                //start();
                if (MyPreferenceManager.getInstance().getString(Util.LIVE_AD).equalsIgnoreCase("admob")) {
                    showFInterstitialAd(MyPreferenceManager.getInstance().getString(Util.F_INTERSTITIAL_ID),intent);
                } else {
                    if(intent!=null) {
                        startActivity(intent);
                        finish();
                    }
                }
            }
        } catch (Exception e) {
            Log.e("InterstitialAdException", "showNativeAd: " + e.toString());
            e.printStackTrace();
            //start();
            if (MyPreferenceManager.getInstance().getString(Util.LIVE_AD).equalsIgnoreCase("admob")) {
                showFInterstitialAd(MyPreferenceManager.getInstance().getString(Util.F_INTERSTITIAL_ID),intent);
            } else {
                if(intent!=null) {
                    startActivity(intent);
                    finish();
                }
            }
        }
    }


    void setAppShortcuts(){
        if(Build.VERSION.SDK_INT>=25) {
            shortcutManager = getSystemService(ShortcutManager.class);
            if (shortcutManager.getDynamicShortcuts().size() == 0) {
                Intent i = new Intent(SplashScreen.this, QuickAccessActivity.class);
                i.setAction(Intent.ACTION_MAIN);
                i.putExtra("select_data", QuickAccessActivity.IMAGES);
                ShortcutInfo imageShortcut = new ShortcutInfo.Builder(SplashScreen.this, "images")
                        .setShortLabel("Images")
                        .setLongLabel("Explore images")
                        .setIcon(Icon.createWithResource(SplashScreen.this, R.drawable.picture))
                        .setIntent(i)
                        .build();

                shortcutManager.setDynamicShortcuts(Arrays.asList(imageShortcut));

                i.putExtra("select_data", QuickAccessActivity.AUDIO);
                ShortcutInfo musicShortcut = new ShortcutInfo.Builder(SplashScreen.this, "music")
                        .setShortLabel("Music")
                        .setLongLabel("Explore music")
                        .setIcon(Icon.createWithResource(SplashScreen.this, R.drawable.music))
                        .setIntent(i)
                        .build();
                shortcutManager.addDynamicShortcuts(Arrays.asList(musicShortcut));

                i.putExtra("select_data", QuickAccessActivity.VIDEO);
                ShortcutInfo videoShortcut = new ShortcutInfo.Builder(SplashScreen.this, "video")
                        .setShortLabel("Videos")
                        .setLongLabel("Explore videos")
                        .setIcon(Icon.createWithResource(SplashScreen.this, R.drawable.video))
                        .setIntent(i)
                        .build();
                shortcutManager.addDynamicShortcuts(Arrays.asList(videoShortcut));

                i.putExtra("select_data", QuickAccessActivity.DOCUMENTS);
                ShortcutInfo documentShortcut = new ShortcutInfo.Builder(SplashScreen.this, "document")
                        .setShortLabel("Documents")
                        .setLongLabel("Explore documents")
                        .setIcon(Icon.createWithResource(SplashScreen.this, R.drawable.file))
                        .setIntent(i)
                        .build();
                shortcutManager.addDynamicShortcuts(Arrays.asList(documentShortcut));
            }
        }
    }
}
