package com.explorefile.filemanager.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.widget.Toolbar;

import com.explorefile.filemanager.R;
import com.explorefile.filemanager.Util;
import com.explorefile.filemanager.ui.browse.SwitchButton;

public class SettingActivity extends AppCompatActivity {

    RelativeLayout hidden_file;
    RelativeLayout rate,share,privacy;
    SwitchButton switch_hide_folder;
    boolean showHiddenFile=false;

    Toolbar toolbar;
    TextView title;
    ImageView icon;

    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        sharedPreferences = getSharedPreferences(Util.DIR_DATA, Context.MODE_PRIVATE);
        showHiddenFile= sharedPreferences.getBoolean(Util.SHOW_HIDDEN,false);

        title = findViewById(R.id.title);
        icon = findViewById(R.id.icon);
        rate=findViewById(R.id.rate);
        privacy=findViewById(R.id.privacy);
        share=findViewById(R.id.share);

        hidden_file=findViewById(R.id.hidden_file);
        switch_hide_folder=findViewById(R.id.switch_hide_folder);
        switch_hide_folder.setChecked(showHiddenFile);

        icon.setOnClickListener((View view) -> {
            onBackPressed();
        });
        switch_hide_folder.setOnCheckedChangeListener(new SwitchButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(SwitchButton view, boolean isChecked) {
                showHiddenFile=isChecked;
                sharedPreferences.edit().putBoolean(Util.SHOW_HIDDEN,showHiddenFile).apply();
            }
        });
        hidden_file.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(showHiddenFile) {
                    showHiddenFile=false;
                    switch_hide_folder.setChecked(false);
                } else {
                    showHiddenFile=true;
                    switch_hide_folder.setChecked(true);
                }
                sharedPreferences.edit().putBoolean(Util.SHOW_HIDDEN,showHiddenFile).apply();
            }
        });
        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Util.shareApp(SettingActivity.this);
            }
        });
        rate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Util.rateOnPlayStore(SettingActivity.this);
            }
        });
        privacy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(Util.PRIVACY_POLICY));
                startActivity(browserIntent);
            }
        });
    }

    @Override
    public void onBackPressed() {
        setResult(RESULT_OK);
        super.onBackPressed();
    }
}