package com.explorefile.filemanager.fileEx;

import android.content.Context;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.os.Build;
import android.os.Environment;

import java.io.File;
import java.io.InputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;


public class StorageType implements Serializable {

    public static final int INTERNAL_STORAGE = 1;
    public static final int SD_CARD = 2;
    public static final int USB_DRIVE = 3;

    public String name;
    public int type;
    public String path;


    public StorageType(String path, String name, int type) {
//        super(path);
        this.name = name;
        this.type = type;
        this.path = path;
    }


    public static Map<String, File> getStorages(Context context) {
        ArrayList<StorageType> storages = new ArrayList<>();
        Map<String, File> storageLocations = new HashMap<>(10);

        // Internal storage
        storages.add(new StorageType(Environment.getExternalStorageDirectory().getPath(),
                "Internal Storage", StorageType.INTERNAL_STORAGE));

        File internalStorage = Environment.getExternalStorageDirectory();
        storageLocations.put("Internal Storage",internalStorage);

        // SD Cards
        ArrayList<File> extStorages = new ArrayList<>();
        extStorages.addAll(Arrays.asList(context.getExternalFilesDirs(null)));
        extStorages.remove(0); // Remove internal storage
        String secondaryStoragePath = System.getenv("SECONDARY_STORAGE");
        for (int i = 0; i < extStorages.size(); i++) {
            String path = extStorages.get(i).getPath().split("/Android")[0];
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                if (Environment.isExternalStorageRemovable(extStorages.get(i)) || secondaryStoragePath != null && secondaryStoragePath.contains(path)) {
                    String name = "SD Card" + (i == 0 ? "" : " " + String.valueOf(i + 1));
                    storages.add(new StorageType(path, name, StorageType.SD_CARD));

                    File externalStorage = new File(path);
                    storageLocations.put("External Storage",externalStorage);
                }
            }
        }

        // USB Drives
        ArrayList<String> drives = new ArrayList<>();
        String reg = "(?i).*vold.*(vfat|ntfs|exfat|fat32|ext3|ext4).*rw.*";
        String s = "";
        try {
            final Process process = new ProcessBuilder().command("mount")
                    .redirectErrorStream(true).start();
            process.waitFor();
            final InputStream is = process.getInputStream();
            final byte[] buffer = new byte[1024];
            while (is.read(buffer) != -1) {
                s += new String(buffer);
            }
            is.close();
        } catch (final Exception e) {
            e.printStackTrace();
        }
        final String[] lines = s.split("\n");
        for (String line : lines) {
            if (!line.toLowerCase(Locale.US).contains("asec") && line.matches(reg)) {
                String[] parts = line.split(" ");
                for (String path : parts) {
                    if (path.startsWith(File.separator) && !path.toLowerCase(Locale.US).contains("vold")) {
                        drives.add(path);
                    }
                }
            }
        }

        // Remove SD Cards from found drives (already found)
        ArrayList<String> ids = new ArrayList<>();
        for (StorageType st : storages) {
            String[] parts = st.path.split(File.separator);
//            String[] parts = st.getPath().split(File.separator);
            ids.add(parts[parts.length - 1]);
        }
        for (int i = drives.size() - 1; i >= 0; i--) {
            String[] parts = drives.get(i).split(File.separator);
            String id = parts[parts.length - 1];
            if (ids.contains(id)) drives.remove(i);
        }

        // Get USB Drive name
        UsbManager usbManager = (UsbManager) context.getSystemService(Context.USB_SERVICE);
        Collection<UsbDevice> dList = usbManager.getDeviceList().values();
        ArrayList<UsbDevice> deviceList = new ArrayList<>();
        deviceList.addAll(dList);
        for (int i = 0; i < deviceList.size(); i++) {
            storages.add(new StorageType(drives.get(i), deviceList.get(i).getProductName(), StorageType.USB_DRIVE));
        }

        return storageLocations;
    }

    @Override
    public String toString() {
        return "Storage{" +
                "name='" + name + '\'' +
                ", type=" + type +
                ", path='" + path + '\'' +
                '}';
    }
}