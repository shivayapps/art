package com.explorefile.filemanager;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.media.MediaMetadataRetriever;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;

import androidx.documentfile.provider.DocumentFile;

import android.os.Build;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.webkit.MimeTypeMap;
import android.widget.Toast;

import com.annimon.stream.Stream;
import com.explorefile.filemanager.fileEx.model.FileDirectory;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.FlowableEmitter;
import io.reactivex.FlowableOnSubscribe;

public class Util {


    public static String AD_URL = "https://raw.githubusercontent.com/Mahendra-Gohil/api/main/ads.json";
    //public static String AD_URL = "https://raw.githubusercontent.com/Mahendra-Gohil/api/main/testAds.json";
    public static String LIVE_AD = "admob";
    public static String G_APP_ID = "g_app_id";
    public static String G_NATIVE_ID = "g_native_id";
    public static String G_INTERSTITIAL_ID = "g_interstitial_id";
    public static String G_BANNER_ID = "g_banner_id";
    public static String G_APPOPEN_ID = "g_appopen_id";

    public static String F_NATIVE_ID = "f_native_id";
    public static String F_INTERSTITIAL_ID = "f_interstitial_id";
    public static String F_BANNER_ID = "f_banner_id";
    public static String G_NATIVE_BANNER_ID = "g_nativebanner_id";

    public static volatile long position = 0L;
    public static final String PRIVACY_POLICY = "https://www.privacypolicies.com/live/a692d2e2-9d85-4d29-9822-01e15134fc3f";
    public static final String BASE_URI = "base_uri";
    public static final String DIR_DATA = "dir_data";
    public static final String SHOW_HIDDEN = "show_hidden";
    public static final String SORT_BY = "sort_by";
    public static final String SORT_ORDER = "sort_order";
    public static int click_count =1;
    private static SimpleDateFormat completeDateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss", Locale.US);
    private static SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.US);
    static final String TAG = Util.class.getSimpleName();
    static List<String> list = new ArrayList<>();
    public static final int MUSIC_ART = 1;
    public static final int VIDEO_ART = 2;
    public static final int APK_ART = 3;
    private static final String PDF = "pdf";
    private static final String MP3 = "mp3";
    private static final String MP4 = "mp4";
    private static final String FLV = "flv";
    private static final String _3GP = "3gp";
    private static final String acc = "acc";
    private static final String aax = "aax";
    private static final String m4a = "m4a";
    private static final String wav = "wav";
    private static final String webm = "webm";
    private static final String apk = "apk";
    private static final String ogg = "ogg";
    private static final String amr = "amr";
    private static final String ZIP = "zip";
    public static final String START_UP_FLAG = "flag";
    public static final int NAME = 0;
    public static final int SIZE = 1;
    public static final int DATE = 2;
    public static final int ASC = 0;
    public static final int DESC = 1;
    static Calendar calendar = Calendar.getInstance();

    public static Boolean check_internet(Context context) {
        if (context != null) {
            ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService("connectivity");
            NetworkInfo networkInfo = null;
            if (connectivityManager != null) {
                networkInfo = connectivityManager.getActiveNetworkInfo();
            }
            if (networkInfo != null && (networkInfo.getType() == 1 || networkInfo.getType() == 0)) {
                return Boolean.valueOf(true);
            }
        }
        return Boolean.valueOf(false);
    }

    public static void reportBug(Context context, String subject, String errorMessage, float ratingValue) {

        // Get App Version
        PackageInfo pInfo = null;
        try {
            pInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        String version = pInfo.versionName;

        // Device Name
        String deviceName = Build.MANUFACTURER + " " + Build.MODEL;

        // OS Version
        String osVersion = Build.VERSION.RELEASE;
        int osAPI = Build.VERSION.SDK_INT;

        // Get Country Name
        String country = "";
        try {
            TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
            String countryCode = "";
            if (tm != null) {
                countryCode = tm.getNetworkCountryIso();
            }
            Locale loc = new Locale("", countryCode);
            country = loc.getDisplayCountry();
        } catch (Exception e) {
            e.printStackTrace();
        }

        HashMap<String, Boolean> mapPermission = new HashMap<>();

        //Intent email = new Intent(Intent.ACTION_SENDTO, Uri.fromParts("mailto", "mahendra@jksol.com", null));
        //email.putExtra(Intent.EXTRA_SUBJECT, subject);

        Iterator<Map.Entry<String, Boolean>> mIterator = mapPermission.entrySet().iterator();
        String mExtraText = "";
        while (mIterator.hasNext()) {
            Map.Entry<String, Boolean> mEntry = mIterator.next();
            if (mEntry.getKey().trim().length() > 0) {
                mExtraText += (mEntry.getKey() + " : "
                        + (mEntry.getValue() ? "YES" : "NO") + "\n");
            }
        }
        String body="Your message: "+errorMessage+
                "\r\n"+
                "\r\nRating :"+ratingValue+
                "\r\nDevice Information - "+context.getResources().getString(R.string.app_name)+
                "\r\nVersion : "+version+
                "\r\nDevice Name : "+deviceName+
                "\r\nAndroid API : "+osAPI+
                "\r\nAndroid Version : "+osVersion+
                "\r\nCountry : "+country;
        //"\nExtraText : "+mExtraText;


        subject = subject+" "+context.getResources().getString(R.string.app_name);
        //StringBuilder builder = new StringBuilder("mailto:" + Uri.encode(context.getResources().getString(R.string.feedback)));

        /*if (!subject.isEmpty()) {
            builder.append("?subject="+Uri.encode(Uri.encode(subject)));
            builder.append("&body=" + Uri.encode(Uri.encode(body)));
        }*/

        //email.putExtra(Intent.EXTRA_TEXT, body);
        try {
            //context.startActivity(Intent.createChooser(email, context.getString(R.string.email_choose_from_client)));

            context.startActivity(
                    Intent.createChooser(
                            new Intent(
                                    Intent.ACTION_SENDTO,
                                    Uri.parse(
                                            "mailto:" + context.getResources().getString(R.string.email)
                                                    + "?cc=&subject=" + Uri.encode(subject).toString()
                                                    + "&body=" + Uri.encode(body)
                                    )
                            ), context.getString(R.string.email_choose_from_client)
                    )
            );

        } catch (ActivityNotFoundException ex) {

        }
    }

    public static void rateOnPlayStore(Context context)
    {
        Uri uri = Uri.parse("market://details?id=" + context.getPackageName());
        Intent myAppLinkToMarket = new Intent(Intent.ACTION_VIEW, uri);
        try {
            context.startActivity(myAppLinkToMarket);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(context, " Unable to find Play Store", Toast.LENGTH_LONG).show();
        }
    }

    public static void shareApp(Context context)
    {

        final String GP_DETAIL_PREFIX = "https://play.google.com/store/apps/details?id=";
        String shareText = context.getResources().getString(R.string.share_desc);
        Intent sendIntent = new Intent();
        sendIntent.setAction(Intent.ACTION_SEND);
        sendIntent.putExtra(Intent.EXTRA_TEXT, String.format(Locale.getDefault(), shareText, GP_DETAIL_PREFIX, BuildConfig.APPLICATION_ID));
        sendIntent.setType("text/plain");
        context.startActivity(sendIntent);
    }

    //  function to get trimmed String
    public static String getTrimmed(String name) {
        /*if(name.length()>16){
            return name.substring(0,15)+"...";
        }*/
        return name;
    }

    public static String getCompleteDate(String date) {
        String finalDate = "";
        try {
            Date d = completeDateFormat.parse(date);
            finalDate = completeDateFormat.format(d);
            //finalDate=calendar.get(Calendar.DAY_OF_MONTH)+" "+calendar.get(Calendar.)+" "+calendar.get(Calendar.YEAR);
        } catch (Exception e) {
            Log.e(TAG, "date error: " + e.getMessage());
            e.printStackTrace();
        }
        return finalDate;
    }

    public static Date getDateFromPath(String path) {
        try {
            String format = completeDateFormat.format(new File(path).lastModified());
            return completeDateFormat.parse(format);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // sorting function for file directory.
    public static List<FileDirectory> sortBy(List<FileDirectory> list, int selection, int order) {
        switch (selection) {

            case NAME:
                Collections.sort(list, (FileDirectory f1, FileDirectory f2) -> {

                            try {
                                if(f1==null || f2==null) {
                                    return 0;
                                }
                                String name1 = f1.getName().toLowerCase().trim();
                                String name2 = f2.getName().toLowerCase().trim();
                                Log.e("sort_getName","name1:"+name1);
                                Log.e("sort_getName","name2:"+name2);
                                if(name1.isEmpty()||name2.isEmpty()) {
                                    return 0;
                                } else {
                                    if(order==ASC) return name1.compareTo(name2);
                                    else return name2.compareTo(name1);
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                                return 0;
                            }
                        }
                );
                break;

            case SIZE:
                Collections.sort(list, (FileDirectory f1, FileDirectory f2) -> {
                            try {
                                if(f1==null || f2==null) {
                                    return 0;
                                }
                                String size1 = f1.getSize().toLowerCase();
                                String size2 = f2.getSize().toLowerCase();
                                Log.e("sort_getSize","size1:"+size1);
                                Log.e("sort_getSize","size2:"+size2);
                                if(size1.isEmpty()||size2.isEmpty()) {
                                    return 0;
                                } else {
                                    if(order==ASC) return size1.compareTo(size2);
                                    else return size2.compareTo(size1);
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                                return 0;
                            }
                        }
                );
                break;

            case DATE:

                Collections.sort(list, new Comparator<FileDirectory>() {
                            @Override
                            public int compare(FileDirectory f1, FileDirectory f2) {
                                try {
                                    if(f1==null || f2==null) {
                                        return 0;
                                    }

                                    Date d1 = simpleDateFormat.parse(f1.getDate());
                                    Date d2 = simpleDateFormat.parse(f2.getDate());
                                    if(d1==null||d2==null) {
                                        return 0;
                                    } else {
                                        if(order==ASC) return d1.compareTo(d2);
                                        else return d2.compareTo(d1);
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                return 0;
                            }
                        }
                );
                break;


        }
        return list;
    }


    public static int getImageResIdFromExension(String name) {
        String ext = MimeTypeMap.getFileExtensionFromUrl(name.replace(" ", ""));
        switch (ext.toLowerCase()) {
            case PDF:
                return R.drawable.pdf;

            case ZIP:
                return R.drawable.zip;

            case MP3:
            case acc:
            case aax:
            case m4a:
            case wav:
            case ogg:
            case amr:
            case webm:
                return R.drawable.ic_music;
            case apk:
                return R.drawable.ic_apk;

            case MP4:
            case FLV:
            case _3GP:
                return R.drawable.ic_video;

        }
        return R.drawable.file;
    }


    public static String getParentDirName(String path) {
        String[] dir = path.split("/");
        return dir[dir.length - 1];
    }


    public static Bitmap getApkIcon(Context context, String sourcePath) {
        Log.e("getApkIcon","path:"+sourcePath);
        //String sourcePath = file.getPath();
        if (sourcePath.endsWith(".apk")) {
            PackageInfo packageInfo = context.getPackageManager()
                    .getPackageArchiveInfo(sourcePath, PackageManager.GET_ACTIVITIES);
            if(packageInfo != null) {
                ApplicationInfo appInfo = packageInfo.applicationInfo;
                if (Build.VERSION.SDK_INT >= 8) {
                    appInfo.sourceDir = sourcePath;
                    appInfo.publicSourceDir = sourcePath;
                }
                Drawable icon = appInfo.loadIcon(context.getPackageManager());
                Bitmap bmpIcon = ((BitmapDrawable) icon).getBitmap();
                return bmpIcon;
            } else return BitmapFactory.decodeResource(context.getResources(), R.drawable.ic_apk);
        }
        return BitmapFactory.decodeResource(context.getResources(), R.drawable.ic_apk);
    }
    public static Bitmap getPackageIcon(Context context, String packageName) {
        PackageManager manager = context.getPackageManager();
        try {

            //return manager.getApplicationIcon(packageName);
            Drawable d = manager.getApplicationIcon(packageName);
            return ((BitmapDrawable)d).getBitmap();
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        //return context.getResources().getDrawable(R.drawable.ic_apk);
        return BitmapFactory.decodeResource(context.getResources(), R.drawable.ic_apk);
    }

    // Load albumArt.
    public static Flowable<Bitmap> loadAlbumArt(String path, int selection) {

        return Flowable.create(new FlowableOnSubscribe<Bitmap>() {
            @Override
            public void subscribe(FlowableEmitter<Bitmap> e) throws Exception {
                android.media.MediaMetadataRetriever mmr = new MediaMetadataRetriever();
                //Log.e(TAG,"Path: "+path);
                mmr.setDataSource(path);
                byte[] data = null;
                Bitmap bitmap = null;
                if (selection == MUSIC_ART) {
                    data = mmr.getEmbeddedPicture();
                    if (data != null) {
                        BitmapFactory.Options options = new BitmapFactory.Options();
                        options.inSampleSize = 8;
                        bitmap = BitmapFactory.decodeByteArray(data, 0, data.length, options);
                        e.onNext(bitmap);
                    }
                } else if (selection == VIDEO_ART) {
                    bitmap = mmr.getFrameAtTime();
                    e.onNext(bitmap);
                }

                e.onComplete();
            }
        }, BackpressureStrategy.BUFFER);

    }

    public static Map<String, List<FileDirectory>> listToMap(List<Map.Entry<String,
            List<FileDirectory>>> list) {
        Map<String, List<FileDirectory>> resultMap = new HashMap<>();
        for (Map.Entry<String, List<FileDirectory>> ls : list) {
            String key = (String) ls.getKey();
            resultMap.put(ls.getKey(), ls.getValue());
        }
        return resultMap;
    }

    public static Flowable<Map<String, List<FileDirectory>>> getRecentlyAddedFiles(final List<FileDirectory> recentList) {
        List<FileDirectory> resultList = new ArrayList<>();
        return Flowable.create(new FlowableOnSubscribe<Map<String, List<FileDirectory>>>() {
            @Override
            public void subscribe(FlowableEmitter<Map<String, List<FileDirectory>>> e) throws Exception {
                Collections.sort(recentList, (l1, l2) -> {
                    try {
                        Date d1 = simpleDateFormat.parse(l1.getDate());
                        Date d2 = simpleDateFormat.parse(l2.getDate());
                        return d2.compareTo(d1);
                    } catch (ParseException exp) {
                        exp.printStackTrace();
                        return 1;
                    }
                });
                // Collections.sort(recentList,Collections.reverseOrder());
                List<FileDirectory> recentListTmp = Util.timeRemovedList(recentList);
                List<Map.Entry<String, List<FileDirectory>>> finalList = Stream
                        .of(recentListTmp)
                        .groupBy(FileDirectory::getDate)
                        .toList();
                list.clear();
                list = Util.getSortedFileList(finalList);
                Map<String, List<FileDirectory>> resultMap = Util.listToMap(finalList);
                e.onNext(resultMap);
                e.onComplete();
            }
        }, BackpressureStrategy.BUFFER);
    }

    public static List<String> getRecentItemKeys() {
        return list;
    }

    public static List<String> getSortedFileList(List<Map.Entry<String,
            List<FileDirectory>>> list) {
        List<Date> dateList = new ArrayList<>();
        List<String> resultList = new ArrayList<>();
        try {
            //Date date = simpleDateFormat.parse("01/01/1980");
            for (Map.Entry<String, List<FileDirectory>> ls : list) {
                String key = (String) ls.getKey();
                dateList.add(simpleDateFormat.parse(key));
            }
            Collections.sort(dateList, Collections.reverseOrder());
            for (Date d : dateList) {
                resultList.add(simpleDateFormat.format(d));
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return resultList;
    }

    public static DocumentFile getDocumentFile(Context c, String path, String name, Uri baseTreeUri) {

        DocumentFile documentFile = DocumentFile.fromTreeUri(c, baseTreeUri);
        Log.e(TAG, "base tree uri: " + baseTreeUri.toString());
        if (path.equals(""))
            return documentFile;
        String[] dirs = path.split("/");
        for (String dir : dirs) {
            documentFile = documentFile.findFile(dir);
        }
        if (name == null)
            return documentFile;
        return documentFile.findFile(name);
    }

    /**
     * @param fileDirectoryList List to process
     * @return
     */
    public static List<FileDirectory> timeRemovedList(List<FileDirectory> fileDirectoryList) {
        for (int i = 0; i < fileDirectoryList.size(); i++) {
            FileDirectory fileDirectory = fileDirectoryList.get(i);
            fileDirectoryList.get(i).setDate(fileDirectory.getDate().split(" ")[0]);
        }
        return fileDirectoryList;
    }

    public static String getProcessedPath(String path) {
        StringBuilder processedPath = new StringBuilder("");
        String[] dirs = path.split("/");
        if (dirs.length <= 3) {
            return "";
        }
        for (int i = 0; i < dirs.length; i++) {
            if (i > 2) {
                processedPath.append(dirs[i] + "/");
            }
        }
        return processedPath.substring(0, processedPath.length() - 1);
    }

}
