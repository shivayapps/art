package com.explorefile.filemanager.adapter.viewHolder;

import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.explorefile.filemanager.R;


public class MediaViewHolder extends RecyclerView.ViewHolder {

    public ImageView thumbnail;
    public RelativeLayout constraintLayout;
    public View bg_view;
    public TextView name,size,info;

    public MediaViewHolder(View v){
        super(v);
        thumbnail=v.findViewById(R.id.thumbnail);
        name=v.findViewById(R.id.name);
        size=v.findViewById(R.id.size);
        info=v.findViewById(R.id.info);
        bg_view=v.findViewById(R.id.bg_view);
        constraintLayout=(RelativeLayout) v;

    }

}
