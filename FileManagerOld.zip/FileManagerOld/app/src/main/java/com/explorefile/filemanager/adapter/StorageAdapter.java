package com.explorefile.filemanager.adapter;

import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.explorefile.filemanager.OnRecyclerItemClickListener;
import com.explorefile.filemanager.R;
import com.explorefile.filemanager.adapter.viewHolder.StorageViewHolder;
import com.explorefile.filemanager.model.Storage;


import java.util.ArrayList;
import java.util.List;


public class StorageAdapter extends RecyclerView.Adapter<StorageViewHolder> {

    private List<Storage> storageList=new ArrayList<>();
    private OnRecyclerItemClickListener onRecyclerItemClickListener;
    int[] progressColor;
    int[] backgroundColor;

    public StorageAdapter(List<Storage> storageList, OnRecyclerItemClickListener onRecyclerItemClickListener,int[] progressColor,int[] backgroundColor){
        this.storageList=storageList;
        this.onRecyclerItemClickListener=onRecyclerItemClickListener;
        this.progressColor=progressColor;
        this.backgroundColor=backgroundColor;
    }

    @Override
    public StorageViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.storage_status_view,parent,false);
        return new StorageViewHolder(v);
    }

    public void setOnRecyclerItemClickListener(OnRecyclerItemClickListener onRecyclerItemClickListener){
        this.onRecyclerItemClickListener=onRecyclerItemClickListener;
    }

    @Override
    public void onBindViewHolder(StorageViewHolder holder, int position) {
        holder.label.setText(storageList.get(position).getTitle());
        holder.progressBar.setProgress(storageList.get(position).getPercentage());
        holder.progressBarPie.setProgress(storageList.get(position).getPercentage());

        holder.progressBarPie.setProgressColor(progressColor[position]);
        holder.progressBarPie.setBackgroundColor(backgroundColor[position]);

        //holder.progressBar.setProgress(20);
        //holder.progressBarPie.setProgress(20);

        holder.percentage.setText(storageList.get(position).getPercentage()+"%");
        //holder.percentage.setText("32%");

        holder.storageSpace.setText(storageList.get(position).getUsed()+"/"+storageList.get(position).getTotal());
        //holder.storageSpace.setText("Available "+storageList.get(position).getFree()+"/"+storageList.get(position).getTotal());
        //holder.storageSpace.setText("1gb/1gb");

        holder.free.setText("Free space:"+storageList.get(position).getFree());
        holder.total.setText("Total space:"+storageList.get(position).getTotal());
        holder.used.setText("Used space:"+storageList.get(position).getUsed());

        //holder.free.setText("getFree");
        //holder.total.setText("getTotal");
        //holder.used.setText("getUsed");

        holder.rootView.setOnClickListener(view -> {
            if(onRecyclerItemClickListener!=null)
                onRecyclerItemClickListener.onClick(view,position);
        });
    }

    @Override
    public int getItemCount() {
        return storageList.size();
    }
}
