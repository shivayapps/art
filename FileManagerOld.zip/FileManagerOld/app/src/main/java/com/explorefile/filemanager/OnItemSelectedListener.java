package com.explorefile.filemanager;

import com.explorefile.filemanager.fileEx.model.FileDirectory;

import java.util.List;


public interface OnItemSelectedListener {

    void onItemListChanged(List<FileDirectory> list);
}
