package com.explorefile.filemanager.http;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.os.*;

import androidx.annotation.RequiresApi;
import androidx.core.app.*;
import androidx.preference.*;

import java.io.*;
import java.net.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.explorefile.filemanager.R;
import com.explorefile.filemanager.ui.browse.HttpActivity;

import static androidx.core.app.NotificationCompat.PRIORITY_MIN;

public class MainService extends Service {
    private static ExecutorService mainThreadPool = Executors.newCachedThreadPool();
    public Handler handler = new Handler();
    private ServerSocket ss;
    private boolean running = false;
    private String errorstr = "";
    public boolean started = false;
    Thread mainThread = new Thread() {
        @Override
        public void run() {
            try {
                started = false;
                int port = Integer.parseInt(PreferenceManager.getDefaultSharedPreferences(getApplicationContext()).getString("serverPort", "-1"));
                ss = new ServerSocket(port);
            } catch (Exception e) {
                errorstr = e.toString();
                return;
            }
            while (running) {
                try {
                    Socket client = ss.accept();
                    mainThreadPool.submit(new HttpThread(client, MainService.this));
                } catch (IOException e) {
                }
            }
        }
    };

    public String getError() {
        String err = errorstr;
        errorstr = "";
        return err;
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    private static final String CHANNEL_ID = "178";
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        Intent notificationIntent = new Intent(this, HttpActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, 0);

        createNotificationChannel();
        String ip=Utils.getLocalIpAddress();
        String url="http://" + ip + ":" + PreferenceManager.getDefaultSharedPreferences(this.getApplicationContext()).getString("serverPort", "-1");
        if (ip.equals("0")) {
            url=getString(R.string.no_internet);
        }

        Notification notification =
                new NotificationCompat.Builder(this, CHANNEL_ID)
                        .setContentTitle(getString(R.string.ftp_notif_title))
                        .setContentText(url)
                        .setSmallIcon(R.mipmap.ic_launcher)
                        .setContentIntent(pendingIntent)
                        .setPriority(NotificationCompat.PRIORITY_MIN)
                        .setTicker("Software Update is running.")
                        .setWhen(System.currentTimeMillis())
                        .build();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            startForeground(5, notification);
        } else {
            startService(intent);
        }

       // startForeground(142, builder.build());
        running = true;
        //if(!started) mainThread.start();
        if (mainThread.getState() == Thread.State.NEW)
        {
            mainThread.start();
        }
        return super.onStartCommand(intent, flags, startId);
    }
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Software Update";
            String description = "Phone Usage Alert";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }
    @RequiresApi(Build.VERSION_CODES.O)
    private String createNotificationChannel(String channelId, String channelName) {
        NotificationChannel chan = new NotificationChannel(channelId, channelName, NotificationManager.IMPORTANCE_NONE);
        chan.setLightColor(Color.BLUE);
        //chan.lockscreenVisibility = Notification.VISIBILITY_PRIVATE;
        chan.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
        NotificationManager service = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        service.createNotificationChannel(chan);
        return channelId;
    }

    @Override
    public IBinder onBind(Intent p1) {
        return new mBinder();
    }

    @Override
    public void onDestroy() {
        running = false;
        new Thread() {
            @Override
            public void run() {
                try {
                    ss.close();
                } catch (Exception e) {
                }
            }
        }.start();
        super.onDestroy();
        Session.sessions.clear();
    }

    public class mBinder extends Binder {
        public MainService service = MainService.this;
    }
}
