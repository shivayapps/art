package com.explorefile.filemanager.adapter;

import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.explorefile.filemanager.R;
import com.explorefile.filemanager.OnRecyclerItemClickListener;

import com.explorefile.filemanager.adapter.viewHolder.StorageChooserViewHolder;
import com.explorefile.filemanager.model.StorageSelection;

import java.util.ArrayList;
import java.util.List;


public class StorageChooserAdapter extends RecyclerView.Adapter<StorageChooserViewHolder> {

    List<StorageSelection> storageSelectionList=new ArrayList<>();
    OnRecyclerItemClickListener onRecyclerItemClickListener;

    public StorageChooserAdapter(List<StorageSelection> storageSelectionList){
        this.storageSelectionList=storageSelectionList;
    }

    public void setOnRecyclerItemClickListener(OnRecyclerItemClickListener
                                               onRecyclerItemClickListener){
        this.onRecyclerItemClickListener=onRecyclerItemClickListener;
    }
    @Override
    public StorageChooserViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.storage_chooser_layout,parent,false);
        return new StorageChooserViewHolder(view);
    }

    @Override
    public void onBindViewHolder(StorageChooserViewHolder holder, int position) {
        holder.constraintLayout.setOnClickListener(view -> {
            if(onRecyclerItemClickListener!=null)
                onRecyclerItemClickListener.onClick(view,position);
        });
        holder.title.setText(storageSelectionList.get(position).getTitle());
        holder.path.setText("("+storageSelectionList.get(position).getPath()+")");

        if(storageSelectionList.get(position).getTitle().charAt(0)=='I'){
            holder.icon.setImageResource(R.drawable.smartphone);
        }else
            holder.icon.setImageResource(R.drawable.sd_card);
    }

    @Override
    public int getItemCount() {
        return storageSelectionList.size();
    }
}
