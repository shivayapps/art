package com.explorefile.filemanager.adapter.viewHolder;

import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.explorefile.filemanager.R;


public class RecentFileViewHolder extends RecyclerView.ViewHolder {

    public TextView name,size,folder,date;
    public ImageView marker,icon;
    public RelativeLayout main;
    public RecentFileViewHolder(View v){
        super(v);
        name=v.findViewById(R.id.name);
        size=v.findViewById(R.id.size);
        folder=v.findViewById(R.id.folder);
        date=v.findViewById(R.id.date);
        marker=v.findViewById(R.id.marker);
        icon=v.findViewById(R.id.icon);
        main=(RelativeLayout)v;
    }

}
