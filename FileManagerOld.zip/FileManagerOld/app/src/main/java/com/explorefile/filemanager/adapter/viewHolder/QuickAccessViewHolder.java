package com.explorefile.filemanager.adapter.viewHolder;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.explorefile.filemanager.R;

public class QuickAccessViewHolder extends RecyclerView.ViewHolder {

    public ImageView icon;
    public CardView iconCard;
    public TextView label;
    public LinearLayout constraintLayout;

    public QuickAccessViewHolder(View v){
        super(v);
        iconCard=v.findViewById(R.id.iconCard);
        icon=v.findViewById(R.id.icon);
        label=v.findViewById(R.id.label);
        constraintLayout=(LinearLayout) v;
    }

}
