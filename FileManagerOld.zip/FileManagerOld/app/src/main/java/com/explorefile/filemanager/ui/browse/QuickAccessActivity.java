package com.explorefile.filemanager.ui.browse;

import android.app.Activity;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;

import com.explorefile.filemanager.MyPreferenceManager;
import com.explorefile.filemanager.adapter.StorageChooserAdapter;
import com.explorefile.filemanager.ads.AdsProviders.AdmobAdManager;
import com.explorefile.filemanager.ads.AdsProviders.FacebookAdsManager;
import com.explorefile.filemanager.ads.Events.AdEventListener;
import com.explorefile.filemanager.fileEx.StorageType;
import com.explorefile.filemanager.model.StorageSelection;
//import com.google.android.material.appbar.MaterialToolbar;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import androidx.appcompat.widget.Toolbar;
import androidx.documentfile.provider.DocumentFile;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.explorefile.filemanager.fileEx.FileEx;
import com.explorefile.filemanager.fileEx.model.FileDirectory;
import com.explorefile.filemanager.OnItemSelectedListener;
import com.explorefile.filemanager.OnRecyclerItemClickListener;
import com.explorefile.filemanager.R;
import com.explorefile.filemanager.Util;
import com.explorefile.filemanager.adapter.MediaAdapter;

import org.reactivestreams.Subscriber;
import org.reactivestreams.Subscription;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.FlowableEmitter;
import io.reactivex.FlowableOnSubscribe;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

import static com.explorefile.filemanager.fileEx.FileEx.EXTERNAL;

public class QuickAccessActivity extends AppCompatActivity implements OnRecyclerItemClickListener, OnItemSelectedListener {

    public static final int IMAGES = 11;
    public static final int AUDIO = 12;
    public static final int VIDEO = 13;
    public static final int DOCUMENTS = 14;
    public static final int APK = 15;
    public static final int ARCHIVE = 17;

    private final static String TAG = QuickAccessActivity.class.getSimpleName();
    FileEx fileEx;
    List<FileDirectory> fileList = new ArrayList<>();
    RecyclerView mediaRV;
    //CollapsingToolbarLayout collapsingToolbarLayout;
    MediaAdapter mediaAdapter;
    //ImageView headImage;
    boolean operationFlag=false;
    boolean isCopied = false;
    boolean isMovable = false;

    ImageView sort, share, delete, detail,switch_view;

    public static int TARGET_DESTINATION = FileEx.INTERNAL;
    public static int SOURCE_DESTINATION = FileEx.INTERNAL;
    StorageChooserAdapter storageChooserAdapter;
    List<StorageSelection> storageSelectionList = new ArrayList<>();
    DocumentFile pickedDir;
    FrameLayout fl_adplaceholder;
    SharedPreferences sharedPreferences;
    MyPreferenceManager myPreferenceManager;
    public static int COPY = 11;
    public static int MOVE = 12;


    int layType =1;
    GridLayoutManager gridLayoutManager;
    ProgressBar progressBar;
    Subscription mediaSubscription, documentSubscription;
    List<FileDirectory> selectionList = new ArrayList<>();
    Toolbar toolbar;
    Toolbar action;

    TextView title;
    ImageView icon;
    int currentSortBy =0;
    int currentSortOrder = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quick_access);
        //setSupportActionBar(findViewById(R.id.toolbar));
        toolbar=findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        myPreferenceManager=MyPreferenceManager.getInstance();
        sharedPreferences = getSharedPreferences(Util.DIR_DATA, Context.MODE_PRIVATE);

        title = findViewById(R.id.title);
        icon = findViewById(R.id.icon);
        progressBar = findViewById(R.id.progress);

        //collapsingToolbarLayout = findViewById(R.id.collapsing_toolbar);
        fileEx = FileEx.newFileManager(Environment.getExternalStorageDirectory().toString(), this);
        mediaRV = findViewById(R.id.mediaRV);
        action = findViewById(R.id.action);
        switch_view = findViewById(R.id.switch_view);
        sort = findViewById(R.id.sort);
        share = findViewById(R.id.share);
        delete = findViewById(R.id.delete);
        detail = findViewById(R.id.detail);

        gridLayoutManager = new GridLayoutManager(this, layType);
        onNewIntent(getIntent());
        mediaRV.setLayoutManager(gridLayoutManager);
        mediaRV.setHasFixedSize(true);

        setClickListener();
        mountStorage();
        //handleIntent(getIntent());
        fl_adplaceholder=findViewById(R.id.fl_adplaceholder);

        if (myPreferenceManager.getString(Util.LIVE_AD).equalsIgnoreCase("admob")) {
            showGNativeAd(fl_adplaceholder, myPreferenceManager.getString(Util.G_NATIVE_ID));
        } else {
            showFNativeAd(fl_adplaceholder, myPreferenceManager.getString(Util.F_NATIVE_ID));
        }
    }

    private void showFNativeAd(final FrameLayout frameNativeAdContainer, String adId) {
        Log.e("showNativeAd", "showFNativeAd: OK");
        FacebookAdsManager facebookAdsManager = new FacebookAdsManager(this);
        facebookAdsManager.loadNativeAd(this, adId, frameNativeAdContainer, false, new AdEventListener() {
            @Override
            public void onAdLoaded() {
                Log.e("showNativeAd", "onAdLoaded");
                frameNativeAdContainer.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdClosed() {
                Log.e("showNativeAd", "onAdClosed");

            }

            @Override
            public void onLoadError(String errorCode) {
                Log.e("showNativeAd", "onLoadError: " + errorCode);
                frameNativeAdContainer.setVisibility(View.GONE);
                if (myPreferenceManager.getString(Util.LIVE_AD).equalsIgnoreCase("facebook")) {
                    showGNativeAd(frameNativeAdContainer,myPreferenceManager.getString(Util.G_NATIVE_ID));
                }
            }
        });
    }

    private void showGNativeAd(final FrameLayout frameNativeAdContainer, String adId) {
        Log.e("showNativeAd", "showNativeAd: OK");
        AdmobAdManager admobAdManager = new AdmobAdManager(this);
        admobAdManager.loadNativeAd(this, adId, frameNativeAdContainer, false, new AdEventListener() {
            @Override
            public void onAdLoaded() {
                Log.e("showNativeAd", "onAdLoaded");
                frameNativeAdContainer.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdClosed() {
                Log.e("showNativeAd", "onAdClosed");

            }

            @Override
            public void onLoadError(String errorCode) {
                Log.e("showNativeAd", "onLoadError: " + errorCode);
                frameNativeAdContainer.setVisibility(View.GONE);

                if (myPreferenceManager.getString(Util.LIVE_AD).equalsIgnoreCase("admob")) {
                    showFNativeAd(frameNativeAdContainer,myPreferenceManager.getString(Util.F_NATIVE_ID));
                }
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && requestCode == EXTERNAL) {
            Uri treeUri = data.getData();
            pickedDir = DocumentFile.fromTreeUri(this, treeUri);
            sharedPreferences.edit().putString(Util.BASE_URI, treeUri.toString()).apply();
            //grantUriPermission(getPackageName(), treeUri, Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            //getContentResolver().takePersistableUriPermission(treeUri, Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);

            Log.e(TAG, "External URI: " + treeUri.toString() + " extension" + MimeTypeMap.getFileExtensionFromUrl(treeUri.toString()));
        }
    }

    private void setMediaAdapter(int selectData) {
        mediaAdapter = new MediaAdapter(fileList, QuickAccessActivity.this, selectData, Glide.with(QuickAccessActivity.this),gridLayoutManager);
        mediaAdapter.setOnItemSelectedListener(QuickAccessActivity.this);
        mediaAdapter.setOnRecyclerItemClickListener(QuickAccessActivity.this);
        mediaRV.setAdapter(mediaAdapter);
        progressBar.setVisibility(View.GONE);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (documentSubscription != null)
            documentSubscription.cancel();
        if (mediaSubscription != null)
            mediaSubscription.cancel();
    }

    // listener for delete button.
    public void setClickListener() {

        icon.setOnClickListener((View view) -> {
            onBackPressed();
        });
        switch_view.setOnClickListener((View view) -> {
            if(gridLayoutManager.getSpanCount()==1) {
                //layType=2;
                gridLayoutManager.setSpanCount(3);
            } else {
                //layType=1;
                gridLayoutManager.setSpanCount(1);
            }
            mediaAdapter.refreshData();
        });
        sort.setOnClickListener((View view) -> {

            currentSortBy=sharedPreferences.getInt(Util.SORT_BY,currentSortBy);
            currentSortOrder=sharedPreferences.getInt(Util.SORT_ORDER,currentSortOrder);

            AlertDialog.Builder sortDialog=new AlertDialog.Builder(QuickAccessActivity.this);
            //Dialog sortDialog=new Dialog(QuickAccess.this);

            //sortDialog.getWindow().setBackgroundDrawableResource(R.drawable.curved_back);
            //sortDialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
            View v = LayoutInflater.from(QuickAccessActivity.this).inflate(R.layout.sort_dialog_view, null);
            sortDialog.setView(v);
            sortDialog.setCancelable(true);
            final Dialog dialog=sortDialog.create();
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

            RadioButton name = v.findViewById(R.id.name);
            RadioButton size = v.findViewById(R.id.size);
            RadioButton date = v.findViewById(R.id.date);

            RadioButton asc = v.findViewById(R.id.asc);
            RadioButton desc = v.findViewById(R.id.desc);

            switch (currentSortBy) {

                case Util.NAME:
                    name.setChecked(true);
                    break;
                case Util.SIZE:
                    size.setChecked(true);
                    break;
                case Util.DATE:
                    date.setChecked(true);
            }

            switch (currentSortOrder) {
                case Util.ASC:
                    asc.setChecked(true);
                    break;
                case Util.DESC:
                    desc.setChecked(true);
                    break;
            }

            RadioGroup group = v.findViewById(R.id.group);
            group.setOnCheckedChangeListener((radioGroup, i) -> {
                switch (radioGroup.getCheckedRadioButtonId()) {

                    case R.id.name:
                        //mediaAdapter.setFileDirectoryList(Util.sortBy(fileList, Util.NAME,Util.ASC));
                        currentSortBy=Util.NAME;
                        break;

                    case R.id.size:
                        //mediaAdapter.setFileDirectoryList(Util.sortBy(fileList, Util.SIZE,Util.ASC));
                        currentSortBy=Util.SIZE;
                        break;

                    case R.id.date:
                        //mediaAdapter.setFileDirectoryList(Util.sortBy(fileList, Util.DATE,Util.ASC));
                        currentSortBy=Util.DATE;
                        break;
                }
                //currentSortBy = group.getCheckedRadioButtonId();
                //sortDialog.dismiss();
            });
            RadioGroup order = v.findViewById(R.id.order);
            order.setOnCheckedChangeListener((radioGroup, i) -> {
                switch (radioGroup.getCheckedRadioButtonId()) {

                    case R.id.asc:
                        //mediaAdapter.setFileDirectoryList(Util.sortBy(fileList, Util.NAME,Util.ASC));
                        currentSortOrder=Util.ASC;
                        break;
                    case R.id.desc:
                        //mediaAdapter.setFileDirectoryList(Util.sortBy(fileList, Util.SIZE,Util.ASC));
                        currentSortOrder=Util.DESC;
                        break;
                }
                //currentSortOrder = order.getCheckedRadioButtonId();
                //sortDialog.dismiss();
            });
            TextView btnPositive = v.findViewById(R.id.btnPositive);
            btnPositive.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    mediaAdapter.setFileDirectoryList(Util.sortBy(fileList, currentSortBy,currentSortOrder));
                    dialog.dismiss();
                    sharedPreferences.edit().putInt(Util.SORT_BY,currentSortBy).apply();
                    sharedPreferences.edit().putInt(Util.SORT_ORDER,currentSortOrder).apply();
                }
            });
            dialog.show();
        });

        share.setOnClickListener(view -> {
            if (selectionList.size() > 0) {
                ArrayList<Uri> uris = new ArrayList<>();

                for (FileDirectory file : selectionList) {
                    uris.add(Uri.fromFile(new File(file.getPath())));
                }

                final Intent intent = new Intent(Intent.ACTION_SEND_MULTIPLE);
                intent.setType("*/*");
                intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
                startActivity(Intent.createChooser(intent, "Send"));
            }
        });

        detail.setOnClickListener(view -> {

            if (selectionList.size() == 1) {
                operationFlag=true;
                android.app.AlertDialog.Builder propertiesDialog=new android.app.AlertDialog.Builder(QuickAccessActivity.this);
                //Dialog sortDialog=new Dialog(QuickAccess.this);

                //sortDialog.getWindow().setBackgroundDrawableResource(R.drawable.curved_back);
                //sortDialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
                View v = LayoutInflater.from(QuickAccessActivity.this).inflate(R.layout.properties_dialog, null);
                propertiesDialog.setView(v);
                propertiesDialog.setCancelable(true);

                final Dialog dialog=propertiesDialog.create();
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

                //Dialog propertiesDialog = new Dialog(this);

                //propertiesDialog.setCancelable(true);
                //propertiesDialog.getWindow().setBackgroundDrawableResource(R.drawable.curved_back);
                //propertiesDialog.setContentView(R.layout.properties_dialog);

                TextView path = v.findViewById(R.id.path);
                TextView size = v.findViewById(R.id.size);
                TextView lastModified = v.findViewById(R.id.lastModified);
                TextView type = v.findViewById(R.id.type);

                // ok button listener
                TextView ok = v.findViewById(R.id.btnPositive);
                ok.setOnClickListener(view1 -> {
                    dialog.dismiss();
                });

                // setting data for properties
                path.setText(String.format(Locale.US, getResources()
                        .getString(R.string.path), selectionList.get(0).getPath()));
                size.setText(String.format(Locale.US, getResources()
                        .getString(R.string.size), selectionList.get(0).getSize()));

                if (selectionList.get(0).getFileOrDir() == FileDirectory.DIR) {
                    type.setText(String.format(Locale.US, getResources()
                            .getString(R.string.type), "Folder"));
                } else {
                    String ext = MimeTypeMap.getFileExtensionFromUrl(selectionList.get(0).getName().replace(" ", ""));
                    type.setText(String.format(Locale.US, getResources()
                            .getString(R.string.type), ext));
                }
                lastModified.setText(String.format(Locale.US, getResources()
                        .getString(R.string.lastModified), selectionList.get(0).getDate()));
                dialog.show();
            }

        });
        delete.setOnClickListener(view -> {
            new AlertDialog.Builder(this)
                    .setCancelable(false).setTitle("Delete")
                    .setMessage("Do you want to delete...?")
                    .setPositiveButton("Yes", (dialogInterface, i) -> {

                        for (FileDirectory fileDirectory : selectionList) {
                            fileEx.delete(fileDirectory.getPath());
                            fileList.remove(fileDirectory);
                        }

                        Toast.makeText(getApplicationContext(), "Files deleted.", Toast.LENGTH_SHORT).show();

                        mediaAdapter.disableSelection();
                        mediaAdapter.notifyDataSetChanged();

                    }).setNegativeButton("No", ((dialogInterface, i) -> {
            })).show();

        });
    }


    void mountStorage() {

        ArrayList<StorageType> device=new ArrayList<>();
        device=FileEx.getStorages(QuickAccessActivity.this);

        //mountedDevices = FileEx.getAllStorageLocations();
        //Iterator iterator = mountedDevices.keySet().iterator();

        String key = "";
        double total, used;
        for(StorageType storageType:device) {
            fileEx.changeRootDirectory(storageType.path);
            storageSelectionList.add(new StorageSelection(storageType.path, storageType.name));
        }

    }



    @Override
    public void onBackPressed() {
        if (selectionList.size() > 0) {
            mediaAdapter.disableSelection();
        } else {
            super.onBackPressed();
        }
    }

    private void handleIntent(Intent intent) {

        int selectData = intent.getExtras().getInt("select_data");
        Log.e(TAG, "selectData: " + selectData);
        if (selectData == QuickAccessActivity.DOCUMENTS) {
            loadDocuments();
        } else if (selectData == QuickAccessActivity.APK) {
            loadApk();
        } else if (selectData == QuickAccessActivity.ARCHIVE) {
            loadArchive();
        } else {
            loadMedia(selectData)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(new Subscriber<List<FileDirectory>>() {

                        @Override
                        public void onSubscribe(Subscription s) {
                            mediaSubscription = s;
                            s.request(Long.MAX_VALUE);
                        }

                        @Override
                        public void onNext(List<FileDirectory> fileDirectoryList) {

                        }

                        @Override
                        public void onError(Throwable t) {
                            Log.e(TAG, "onError: " + t.getMessage());
                        }

                        @Override
                        public void onComplete() {
                            if(fileList.size()!=0) {
                                fileList = Util.sortBy(fileList, Util.NAME,Util.ASC);
                            }
                            mediaAdapter = new MediaAdapter(fileList, QuickAccessActivity.this, selectData, Glide.with(QuickAccessActivity.this),gridLayoutManager);
                            mediaAdapter.setOnItemSelectedListener(QuickAccessActivity.this);
                            mediaAdapter.setOnRecyclerItemClickListener(QuickAccessActivity.this);
                            mediaRV.setAdapter(mediaAdapter);
                            progressBar.setVisibility(View.GONE);
                            sort.setVisibility(View.VISIBLE);
                        }
                    });
        }
    }

    Flowable<List<FileDirectory>> loadMedia(final int select) {
        return Flowable.create(new FlowableOnSubscribe<List<FileDirectory>>() {
            @Override
            public void subscribe(FlowableEmitter<List<FileDirectory>> e) {
                fileList = getAllMediaPath(QuickAccessActivity.this, e, select);
                e.onComplete();
            }

        }, BackpressureStrategy.BUFFER);
    }

    void loadDocuments() {
        fileEx.find(Environment.getExternalStorageDirectory().toString(), FileEx.DOC_SELECTOR)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<List<FileDirectory>>() {

                    @Override
                    public void onSubscribe(Subscription s) {
                        documentSubscription = s;
                        s.request(Long.MAX_VALUE);
                    }

                    @Override
                    public void onNext(List<FileDirectory> fileDirectories) {
                        fileList = fileDirectories;
                        //Toast.makeText(getApplicationContext(),"search list size: "+fileDirectories.size(),Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onError(Throwable t) {
                        Log.e("QuickAccess", "Error message01: " + t.getMessage());
                    }

                    @Override
                    public void onComplete() {
                        if(fileList.size()!=0) {
                            fileList = Util.sortBy(fileList, Util.NAME,Util.ASC);
                        }
                        mediaAdapter = new MediaAdapter(fileList, QuickAccessActivity.this, QuickAccessActivity.DOCUMENTS, Glide.with(QuickAccessActivity.this),gridLayoutManager);
                        mediaAdapter.setOnItemSelectedListener(QuickAccessActivity.this);
                        mediaAdapter.setOnRecyclerItemClickListener(QuickAccessActivity.this);
                        mediaRV.setAdapter(mediaAdapter);
                        progressBar.setVisibility(View.GONE);
                        sort.setVisibility(View.VISIBLE);
                    }
                });
    }
    void loadApk() {
        fileEx.findApk(Environment.getExternalStorageDirectory().toString(), FileEx.DOC_SELECTOR)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<List<FileDirectory>>() {

                    @Override
                    public void onSubscribe(Subscription s) {
                        documentSubscription = s;
                        s.request(Long.MAX_VALUE);
                    }

                    @Override
                    public void onNext(List<FileDirectory> fileDirectories) {
                        fileList = fileDirectories;
                        //Toast.makeText(getApplicationContext(),"search list size: "+fileDirectories.size(),Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onError(Throwable t) {
                        Log.e("QuickAccess", "Error message02: " + t.getMessage());
                    }

                    @Override
                    public void onComplete() {
                        if(fileList.size()!=0) {
                            fileList = Util.sortBy(fileList, Util.NAME,Util.ASC);
                        }
                        mediaAdapter = new MediaAdapter(fileList, QuickAccessActivity.this, QuickAccessActivity.DOCUMENTS, Glide.with(QuickAccessActivity.this),gridLayoutManager);
                        mediaAdapter.setOnItemSelectedListener(QuickAccessActivity.this);
                        mediaAdapter.setOnRecyclerItemClickListener(QuickAccessActivity.this);
                        mediaRV.setAdapter(mediaAdapter);
                        progressBar.setVisibility(View.GONE);
                        sort.setVisibility(View.VISIBLE);
                    }
                });
    }
    void loadArchive() {
        fileEx.findArchive(Environment.getExternalStorageDirectory().toString(), FileEx.DOC_SELECTOR)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<List<FileDirectory>>() {

                    @Override
                    public void onSubscribe(Subscription s) {
                        documentSubscription = s;
                        s.request(Long.MAX_VALUE);
                    }

                    @Override
                    public void onNext(List<FileDirectory> fileDirectories) {
                        fileList = fileDirectories;
                        //Toast.makeText(getApplicationContext(),"search list size: "+fileDirectories.size(),Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onError(Throwable t) {
                        Log.e("QuickAccess", "Error message03: " + t.getMessage());
                    }

                    @Override
                    public void onComplete() {
                        if(fileList.size()!=0) {
                            fileList = Util.sortBy(fileList, Util.NAME,Util.ASC);
                        }
                        mediaAdapter = new MediaAdapter(fileList, QuickAccessActivity.this, QuickAccessActivity.DOCUMENTS, Glide.with(QuickAccessActivity.this),gridLayoutManager);
                        mediaAdapter.setOnItemSelectedListener(QuickAccessActivity.this);
                        mediaAdapter.setOnRecyclerItemClickListener(QuickAccessActivity.this);
                        mediaRV.setAdapter(mediaAdapter);
                        progressBar.setVisibility(View.GONE);
                        sort.setVisibility(View.VISIBLE);
                    }
                });
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        //headImage = findViewById(R.id.image);
        int name = intent.getExtras().getInt("select_data");
        switch (name) {

            case IMAGES:
                title.setText("Images");
                layType=3;
                gridLayoutManager.setSpanCount(3);
                //headImage.setImageResource(R.drawable.picture);
                break;

            case AUDIO:
                title.setText("Music");
                layType=1;
                gridLayoutManager.setSpanCount(1);
                //headImage.setImageResource(R.drawable.music);
                break;
            case VIDEO:
                title.setText("Videos");
                layType=3;
                gridLayoutManager.setSpanCount(3);
                //headImage.setImageResource(R.drawable.video);
                break;
            case DOCUMENTS:
                title.setText("Documents");
                layType=1;
                gridLayoutManager.setSpanCount(1);
                //headImage.setImageResource(R.drawable.file);
                break;
            case APK:
                title.setText("Apk");
                layType=1;
                gridLayoutManager.setSpanCount(1);
                //headImage.setImageResource(R.drawable.file);
                break;
            case ARCHIVE:
                title.setText("Archive");
                layType=1;
                gridLayoutManager.setSpanCount(1);
                //headImage.setImageResource(R.drawable.file);
                break;

        }


        /*fileList= Home.fileList;
        Log.e(TAG, "onNewIntent: Home.fileList:" + Home.fileList.size());
        if(fileList.size()==0) {
            Log.e(TAG, "onNewIntent: fileList:" + fileList.size());
            handleIntent(intent);
        } else {
            Log.e(TAG, "onNewIntent: select_data:"+intent.getExtras().getInt("select_data"));
            Log.e(TAG, "onNewIntent: getData");
            Log.e(TAG, "onNewIntent: fileName:"+fileList.get(0).getName());
            Log.e(TAG, "onNewIntent: filePath:"+fileList.get(0).getPath());

            fileList = Util.sortBy(fileList, currentSortBy,currentSortOrder);
            mediaAdapter = new MediaAdapter(fileList, QuickAccess.this, QuickAccess.DOCUMENTS, Glide.with(QuickAccess.this));
            mediaAdapter.setOnItemSelectedListener(QuickAccess.this);
            mediaAdapter.setOnRecyclerItemClickListener(QuickAccess.this);
            mediaRV.setAdapter(mediaAdapter);
            progressBar.setVisibility(View.GONE);
            sort.setVisibility(View.VISIBLE);
        }*/

        handleIntent(intent);

    }


    private List<FileDirectory> getAllMediaPath(Activity activity, FlowableEmitter<List<FileDirectory>> e, int selection) {
        Uri uri = null;
        Cursor cursor;
        int column_index_data, column_index_folder_name;
        List<FileDirectory> list = new ArrayList<>();
        String absolutePathOfImage, fileName;
        String[] projection = {};
        if (selection == AUDIO) {
            uri = android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
            projection = new String[]{MediaStore.MediaColumns.DATA,
                    MediaStore.Audio.Media.DISPLAY_NAME};
            Log.e("Test", "Audio");
        } else if (selection == IMAGES) {
            uri = android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
            projection = new String[]{MediaStore.MediaColumns.DATA,
                    MediaStore.Images.Media.BUCKET_DISPLAY_NAME};
            Log.e("Test", "Images");
        } else if (selection == VIDEO) {
            uri = android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
            projection = new String[]{MediaStore.Video.VideoColumns.DATA,
                    MediaStore.Video.Media.DISPLAY_NAME};
            Log.e("Test", "Video");
        } else {
            uri= Uri.fromFile(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS));

            File file=Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            //list=find(file);
            for (File temp : file.listFiles()) {
                if (!file.isDirectory()) {
                    //find(temp, text);
                } else {
                    list.add(new FileDirectory(temp.getName(), FileDirectory.FILE,
                            fileEx.getAbsoluteFileSize(temp.getAbsolutePath()),
                            fileEx.getAbsoluteInfo(temp.getAbsolutePath()), temp.getAbsolutePath()));
                }
            }
            return list;
        }

        cursor = activity.getContentResolver().query(uri, projection, null,
                null, null);

        column_index_data = cursor.getColumnIndexOrThrow(projection[0]);
        column_index_folder_name = cursor.getColumnIndexOrThrow(projection[1]);
        cursor.moveToFirst();

        do {
            absolutePathOfImage = cursor.getString(column_index_data);
            fileName = cursor.getString(column_index_folder_name);
            if (!new File(absolutePathOfImage).exists())
                continue;
            list.add(new FileDirectory(fileName, FileDirectory.FILE,
                    fileEx.getAbsoluteFileSize(absolutePathOfImage),
                    fileEx.getAbsoluteInfo(absolutePathOfImage), absolutePathOfImage));

            e.onNext(list);
        } while (cursor.moveToNext());

        return list;
    }

    List<FileDirectory> listFile = new ArrayList<>();
    public List<FileDirectory> find(File file) {
        if (!file.isDirectory())
            return null;
        for (File temp : file.listFiles()) {
            if (file.isDirectory()) {
                find(temp);
            } else {
                listFile.add(new FileDirectory(temp.getName(), FileDirectory.FILE,
                        fileEx.getAbsoluteFileSize(temp.getAbsolutePath()),
                        fileEx.getAbsoluteInfo(temp.getAbsolutePath()), temp.getAbsolutePath()));
            }
        }
        return listFile;
    }

    @Override
    public void onClick(View view, int position) {
        Intent i = fileEx.getAbsoluteOpenableIntent(fileList.get(position).getPath());
        startActivity(i);
    }

    @Override
    public void onLongClick(View view, int position) {

    }

    Dialog actionDialog;
    public void showActionDialog(){
        AlertDialog.Builder menuDialog=new AlertDialog.Builder(QuickAccessActivity.this);

        View v = LayoutInflater.from(QuickAccessActivity.this).inflate(R.layout.options_layout, null);
        menuDialog.setView(v);
        menuDialog.setCancelable(true);

        actionDialog=menuDialog.create();
        actionDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        TextView open=v.findViewById(R.id.open);
        TextView share=v.findViewById(R.id.share);
        TextView delete=v.findViewById(R.id.delete);

        if (selectionList.size() == 1) {
            open.setVisibility(View.VISIBLE);
        } else {
            open.setVisibility(View.GONE);
        }

        open.setOnClickListener(view1 -> {
            String parent_dir=new File(selectionList.get(0).getPath()).getParent();
            Intent i=new Intent(QuickAccessActivity.this, BrowseActivity.class);
            //  Log.e(TAG,"parent dir: "+parent_dir);
            i.putExtra(getResources().getString(R.string.dir_reference),parent_dir);
            actionDialog.dismiss();
            startActivity(i);
        });

        delete.setOnClickListener(view1 -> {
            new AlertDialog.Builder(this)
                    .setCancelable(false).setTitle("Delete")
                    .setMessage("Do you want to delete...?")
                    .setPositiveButton("Yes", (dialogInterface, i) -> {

                        for (FileDirectory fileDirectory : selectionList) {
                            fileEx.delete(fileDirectory.getPath());
                            fileList.remove(fileDirectory);
                        }

                        Toast.makeText(getApplicationContext(), "Files deleted.", Toast.LENGTH_SHORT).show();

                        mediaAdapter.disableSelection();
                        mediaAdapter.notifyDataSetChanged();

                    }).setNegativeButton("No", ((dialogInterface, i) -> {
            })).show();
        });

        share.setOnClickListener(view1 -> {
            if (selectionList.size() > 0) {
                ArrayList<Uri> uris = new ArrayList<>();

                for (FileDirectory file : selectionList) {
                    uris.add(Uri.fromFile(new File(file.getPath())));
                }

                final Intent intent = new Intent(Intent.ACTION_SEND_MULTIPLE);
                intent.setType("*/*");
                intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
                startActivity(Intent.createChooser(intent, "Send"));
            }

        });
        actionDialog.show();
    }

    @Override
    public void onItemListChanged(List<FileDirectory> list) {
        selectionList = list;
        if (selectionList.size() > 0) {
            action.setVisibility(View.VISIBLE);
            if (selectionList.size() ==1) {
                detail.setVisibility(View.VISIBLE);
            } else {
                detail.setVisibility(View.GONE);
            }
            //showActionDialog();
        } else {
            detail.setVisibility(View.GONE);
            action.setVisibility(View.GONE);

            //if(actionDialog!=null && actionDialog.isShowing()) actionDialog.dismiss();
        }
    }
}
