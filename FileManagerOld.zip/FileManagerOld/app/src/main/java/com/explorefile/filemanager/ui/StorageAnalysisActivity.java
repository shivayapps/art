package com.explorefile.filemanager.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.ObjectAnimator;
import android.os.Bundle;

import com.explorefile.filemanager.R;

public class StorageAnalysisActivity extends AppCompatActivity {

    private long
            totalImagesLength = 0,
            totalVideosLength = 0,
            totalApkLength = 0,
            totalAudiosLength = 0,
            totalDocumentsLength = 0,
            totalOtherFilesLength = 0;

    private int scrollRange = -1;
    private boolean
            isTotalImagesGet = false,
            isTotalVideosGet = false,
            isTotalApkGet = false,
            isTotalAudiosGet = false,
            isTotalDocumentsGet = false;

    private ObjectAnimator progressAnimator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_storage_analysis);

    }
}